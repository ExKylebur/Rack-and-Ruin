# Rack & Ruin (Refactored)

The game is now split into maintainable files instead of a single HTML document.

## Entry Point
- `PLAY ME.html`
- No build step required for local/offline play.

## Source Layout
- `src/main.js` - Core game logic, physics, turn flow, card effects, UI wiring.
- `src/render/hd-renderer.js` - High-fidelity rendering for table, balls, and spin dial.
- `src/styles/main.css` - Global styles and upgraded card UI styling.
- `server/multiplayer_server.py` - Optional online multiplayer room/state server (2-player turn sync).

## Run
1. Local/offline:
   - Open `PLAY ME.html` in your browser.
2. Online multiplayer:
   - Run `python3 server/multiplayer_server.py --port 8000`
   - Optional for internet invites: add `--public-base-url https://your-domain-or-tunnel`
   - If `--public-base-url` is not set, the server will auto-infer a public base from request headers when possible.
   - One-command public tunnel option (no extra install if `ssh` exists):
     - `python3 server/multiplayer_server.py --port 8000 --auto-public-tunnel`
     - The server will print `Public invite URL: ...` once localhost.run assigns one.
   - In-app auto attempt:
     - On `CREATE ROOM`, the client will call `/api/start-tunnel` and wait for a public URL when needed.
   - Async-friendly defaults are enabled:
     - Room state is persisted to disk (`server/state/rooms.json`)
     - Room TTL defaults to 30 days (`--room-ttl-hours` to change)
     - Players can reclaim their seat by rejoining with the same player name
   - Open `http://localhost:8000/PLAY%20ME.html` on both devices.
   - In Setup, switch to `ONLINE`, then `CREATE ROOM` on one client and `JOIN ROOM` on the other.
   - Extra clients can still `JOIN ROOM` and will connect as spectators automatically.

## New Options
- Game variants:
  - `8-BALL` (2 players): classic solids/stripes + 8-ball win condition.
  - `9-BALL` (2 players): balls 1-9 only, must hit the lowest-numbered ball first, legal 9-ball pocket wins.
  - `CUTTHROAT` (local only): 3-player mode with fixed groups (`1-5`, `6-10`, `11-15`), last player with group balls remaining wins.
  - `DOUBLES` (local only): 4-player team mode (`P1+P3` vs `P2+P4`) with team solids/stripes and rotating partner shots.
- `Mouse` vs `Phone` control mode:
  - `Mouse`: hold/release on table to shoot (existing behavior).
  - `Phone`: drag on table to aim, hold/release side shot button to set power and fire.
- Debug card picker:
  - Enable `DEBUG: FULL CARD PICK AFTER MY SHOTS` to select draw cards from the full available card list after your turns.
- Online reconnect/resume:
  - Session token is saved locally; click `RESUME` after refresh/crash to reconnect to your previous room.
- Online real-time shot playback:
  - During a shot, the active shooter streams frequent state updates so other clients see live ball motion.
- Online asynchronous turn handoff:
  - Each shot state is saved server-side and kept until the opponent takes their turn.
  - A final keepalive update is sent when a tab is hidden/closed to reduce lost-turn risk.

## Legacy File
- `Rack&Ruin.html` remains in the repo as the original single-file implementation.
