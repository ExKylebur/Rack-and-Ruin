const hdRenderer = window.HDRenderer || {};
const drawPoolBallHD = typeof hdRenderer.drawPoolBall === 'function' ? hdRenderer.drawPoolBall : null;
const drawSpinDialHD = typeof hdRenderer.drawSpinDial === 'function' ? hdRenderer.drawSpinDial : null;
const drawTableSurfaceHD = typeof hdRenderer.drawTableSurface === 'function' ? hdRenderer.drawTableSurface : null;
const audioFx = window.RRAudio || null;
function audioCall(method, ...args) {
  try {
    if (!audioFx || typeof audioFx[method] !== 'function') return;
    audioFx[method](...args);
  } catch (_) {
    // Never let audio errors interrupt gameplay flow.
  }
}
if (!drawPoolBallHD || !drawSpinDialHD || !drawTableSurfaceHD) {
  console.warn('HD renderer unavailable; using built-in fallback renderer.');
}

// ── Constants ────────────────────────────────────────────────
const TABLE_SCALE = 1.15;
const TW = Math.round(700 * TABLE_SCALE), TH = Math.round(350 * TABLE_SCALE);
const RAIL = 26 * TABLE_SCALE;
const POCKET_R = 16 * TABLE_SCALE;
const BR = 10 * TABLE_SCALE;
const WALL_DAMP   = 0.72;
const MIN_V       = 0.04;
const SLIDE_MU    = 0.10;
const ROLL_MU     = 0.012;
const SPIN_DECAY  = 0.94;
const MAX_BALL_SPEED = 42;

// ── Active effect state — declared here so physics/drawing can reference it ──
let activeEffects = {
  fogOfWar: false, heavyweight: null, lightweight: null,
  confusion: false, confusionMap: null, confusionStripeMap: null, cloaked: null,
  sticky: false, drunk: false, shortsighted: false,
  roidRage: false, coolHands: false, bigBall: false, smallBall: false,
  bumper: null, mudPatch: null, pocketShrink: null,
  wind: 0,
  bounceHouseRail: [], deadRail: [], bearTrap: [],
  bearTrapZone: null,
  bearTrapRevealUntil: 0,
  portals: null, icePatch: null, blockedPockets: [],
  bouncer: null, oilCue: false, reverseSpin: false, mirror: false,
  magnet: false, turbo: false, movedPockets: {},
  warpCorners: null,
  warpMids: null,
};

// ── Card/interaction state — declared early to avoid hoisting errors ──
let drunkenTimer    = null;
let roidRageTimer   = null;
let drunkOffset     = 0;
let pendingBallInHand  = false;
let ballPickerStep     = null;
let ballPickerPreviewNum = null;
let pocketPickerStep   = null;
let pocketPickerHover  = null;
let railPickerStep     = null;
let railPickerHover    = null;
let tablePlacerActive  = false;
let tablePlacerStep    = null;
let portalPlaceState   = 0;
let portalEntry        = null;
let interactionQueue   = [];
let warpPocketResizeStep = null;
let skipSelectionConfirm = false;
let confirmAction = null;
let confirmCancelAction = null;

// Pocket holes sit at the inner rail edge so balls can reach them from the felt.
// Corner pockets are at the rail corner intersections.
// Side pockets are centred horizontally, flush with the inner rail face.
const POCKETS = [
  {x:RAIL,    y:RAIL,    type:'corner', jx: 1, jy: 1},
  {x:TW/2,    y:RAIL,    type:'side',   jx: 0, jy: 1},
  {x:TW-RAIL, y:RAIL,    type:'corner', jx:-1, jy: 1},
  {x:RAIL,    y:TH-RAIL, type:'corner', jx: 1, jy:-1},
  {x:TW/2,    y:TH-RAIL, type:'side',   jx: 0, jy:-1},
  {x:TW-RAIL, y:TH-RAIL, type:'corner', jx:-1, jy:-1},
];

const DEFS = {
  1:{c:'#e8bc18',s:false}, 2:{c:'#1838cf',s:false},
  3:{c:'#d63a1a',s:false}, 4:{c:'#6b1fa0',s:false},
  5:{c:'#e07820',s:false}, 6:{c:'#1a7a40',s:false},
  7:{c:'#8b1a1a',s:false}, 8:{c:'#111111',s:false},
  9:{c:'#e8bc18',s:true},  10:{c:'#1838cf',s:true},
  11:{c:'#d63a1a',s:true}, 12:{c:'#6b1fa0',s:true},
  13:{c:'#e07820',s:true}, 14:{c:'#1a7a40',s:true},
  15:{c:'#8b1a1a',s:true},
};
const CUTTHROAT_GROUPS = ['low', 'mid', 'high'];
const CUTTHROAT_GROUP_NUMS = {
  low:  [1, 2, 3, 4, 5],
  mid:  [6, 7, 8, 9, 10],
  high: [11, 12, 13, 14, 15],
};
const CUTTHROAT_GROUP_LABELS = {
  low: '1-5',
  mid: '6-10',
  high: '11-15',
};

function getTriangleRackPositions() {
  const cx = TW * 0.72, cy = TH / 2;
  const gap = BR * 2.12;
  const rowDX = gap * Math.cos(Math.PI / 6);
  const pos = [];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col <= row; col++) {
      pos.push({
        x: cx + row * rowDX,
        y: cy + (col - row / 2) * gap,
      });
    }
  }
  return pos;
}

function getDiamondRackPositions() {
  const cx = TW * 0.72, cy = TH / 2;
  const gap = BR * 2.12;
  const rowDX = gap * Math.cos(Math.PI / 6);
  const rows = [1, 2, 3, 2, 1];
  const pos = [];
  rows.forEach((count, row) => {
    const x = cx + row * rowDX;
    for (let i = 0; i < count; i++) {
      pos.push({
        x,
        y: cy + (i - (count - 1) / 2) * gap,
      });
    }
  });
  return pos;
}

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}

function getEightBallRackNumbers() {
  const numbers = new Array(15);
  numbers[0] = 1; // Apex ball at the foot spot.
  numbers[4] = 8; // 8-ball centered.

  const solids = shuffleArray([2, 3, 4, 5, 6, 7]);
  const stripes = shuffleArray([9, 10, 11, 12, 13, 14, 15]);
  const solidOnLeftCorner = Math.random() < 0.5;
  numbers[10] = solidOnLeftCorner ? solids.pop() : stripes.pop(); // Back-left corner.
  numbers[14] = solidOnLeftCorner ? stripes.pop() : solids.pop(); // Back-right corner.

  const remaining = shuffleArray(solids.concat(stripes));
  let idx = 0;
  for (let i = 0; i < numbers.length; i++) {
    if (numbers[i] != null) continue;
    numbers[i] = remaining[idx++];
  }
  return numbers;
}

function getCutthroatGroupForBall(num) {
  if (num >= 1 && num <= 5) return 'low';
  if (num >= 6 && num <= 10) return 'mid';
  if (num >= 11 && num <= 15) return 'high';
  return null;
}

function getRackLayoutForVariant(variant) {
  if (variant === 'nine') {
    const randomCore = shuffleArray([2, 3, 4, 5, 6, 7, 8]);
    const numbers = [1, randomCore[0], randomCore[1], randomCore[2], 9, randomCore[3], randomCore[4], randomCore[5], randomCore[6]];
    return { numbers, positions: getDiamondRackPositions() };
  }
  if (variant === 'cutthroat') {
    const numbers = new Array(15);
    numbers[0] = 1;    // apex
    numbers[10] = 6;   // rear left corner
    numbers[14] = 11;  // rear right corner
    const fillOrder = shuffleArray([2, 3, 4, 5, 7, 8, 9, 10, 12, 13, 14, 15]);
    let fillIdx = 0;
    for (let i = 0; i < numbers.length; i++) {
      if (numbers[i] != null) continue;
      numbers[i] = fillOrder[fillIdx++];
    }
    return { numbers, positions: getTriangleRackPositions() };
  }
  return { numbers: getEightBallRackNumbers(), positions: getTriangleRackPositions() };
}

function defaultWarpCorners() {
  return {
    tl: { x: RAIL, y: RAIL },
    tr: { x: TW - RAIL, y: RAIL },
    br: { x: TW - RAIL, y: TH - RAIL },
    bl: { x: RAIL, y: TH - RAIL },
  };
}

function defaultWarpMids() {
  return {
    top: { x: TW / 2, y: RAIL },
    bottom: { x: TW / 2, y: TH - RAIL },
  };
}

function getWarpCorners() {
  const d = defaultWarpCorners();
  const c = activeEffects.warpCorners;
  if (!c) return d;
  return {
    tl: { x: c.tl?.x ?? d.tl.x, y: c.tl?.y ?? d.tl.y },
    tr: { x: c.tr?.x ?? d.tr.x, y: c.tr?.y ?? d.tr.y },
    br: { x: c.br?.x ?? d.br.x, y: c.br?.y ?? d.br.y },
    bl: { x: c.bl?.x ?? d.bl.x, y: c.bl?.y ?? d.bl.y },
  };
}

function getWarpMids() {
  const d = defaultWarpMids();
  const m = activeEffects.warpMids;
  if (!m) return d;
  return {
    top: { x: m.top?.x ?? d.top.x, y: m.top?.y ?? d.top.y },
    bottom: { x: m.bottom?.x ?? d.bottom.x, y: m.bottom?.y ?? d.bottom.y },
  };
}

function getWarpPolygonPoints() {
  const c = getWarpCorners();
  const m = getWarpMids();
  return [
    { x: c.tl.x, y: c.tl.y },
    { x: m.top.x, y: m.top.y },
    { x: c.tr.x, y: c.tr.y },
    { x: c.br.x, y: c.br.y },
    { x: m.bottom.x, y: m.bottom.y },
    { x: c.bl.x, y: c.bl.y },
  ];
}

function hasWarpShape() {
  const d = defaultWarpCorners();
  const md = defaultWarpMids();
  const c = getWarpCorners();
  const m = getWarpMids();
  return (
    c.tl.x !== d.tl.x || c.tl.y !== d.tl.y ||
    c.tr.x !== d.tr.x || c.tr.y !== d.tr.y ||
    c.br.x !== d.br.x || c.br.y !== d.br.y ||
    c.bl.x !== d.bl.x || c.bl.y !== d.bl.y ||
    m.top.x !== md.top.x || m.top.y !== md.top.y ||
    m.bottom.x !== md.bottom.x || m.bottom.y !== md.bottom.y
  );
}

function getWarpEdges() {
  const p = getWarpPolygonPoints();
  return [
    { wall: 'top', a: p[0], b: p[1] },
    { wall: 'top', a: p[1], b: p[2] },
    { wall: 'right', a: p[2], b: p[3] },
    { wall: 'bottom', a: p[3], b: p[4] },
    { wall: 'bottom', a: p[4], b: p[5] },
    { wall: 'left', a: p[5], b: p[0] },
  ];
}

function getInnerBounds(ballRadius = 0) {
  const p = getWarpPolygonPoints();
  const xs = p.map(v => v.x);
  const ys = p.map(v => v.y);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);
  return {
    left: minX + ballRadius,
    right: maxX - ballRadius,
    top: minY + ballRadius,
    bottom: maxY - ballRadius,
  };
}

function pointInsideWarpShape(x, y, margin = 0) {
  const poly = getWarpPolygonPoints();
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x, yi = poly[i].y;
    const xj = poly[j].x, yj = poly[j].y;
    const crosses = ((yi > y) !== (yj > y)) &&
      (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-6) + xi);
    if (crosses) inside = !inside;
  }
  if (!inside) return false;
  if (margin <= 0) return true;

  let minDist = Infinity;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const ex = b.x - a.x;
    const ey = b.y - a.y;
    const lenSq = ex * ex + ey * ey || 1;
    const t = Math.max(0, Math.min(1, ((x - a.x) * ex + (y - a.y) * ey) / lenSq));
    const cx = a.x + ex * t;
    const cy = a.y + ey * t;
    const d = Math.hypot(x - cx, y - cy);
    if (d < minDist) minDist = d;
  }
  return minDist >= margin;
}

function getWarpCentroid() {
  const poly = getWarpPolygonPoints();
  let cx = 0, cy = 0;
  for (let i = 0; i < poly.length; i++) {
    cx += poly[i].x;
    cy += poly[i].y;
  }
  return { x: cx / poly.length, y: cy / poly.length };
}

function getClosestPointOnWarpBoundary(x, y) {
  const poly = getWarpPolygonPoints();
  let best = { x, y, dist: Infinity };
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const ex = b.x - a.x;
    const ey = b.y - a.y;
    const lenSq = ex * ex + ey * ey || 1;
    const t = Math.max(0, Math.min(1, ((x - a.x) * ex + (y - a.y) * ey) / lenSq));
    const cx = a.x + ex * t;
    const cy = a.y + ey * t;
    const d = Math.hypot(x - cx, y - cy);
    if (d < best.dist) best = { x: cx, y: cy, dist: d };
  }
  return best;
}

function shiftPointInsideWarp(x, y, margin = 0) {
  if (pointInsideWarpShape(x, y, margin)) return { x, y };
  const centroid = getWarpCentroid();
  let px = x, py = y;
  for (let i = 0; i < 8; i++) {
    if (pointInsideWarpShape(px, py, margin)) break;
    const cp = getClosestPointOnWarpBoundary(px, py);
    let dx = centroid.x - cp.x;
    let dy = centroid.y - cp.y;
    let len = Math.hypot(dx, dy);
    if (len < 1e-6) {
      dx = centroid.x - px;
      dy = centroid.y - py;
      len = Math.hypot(dx, dy) || 1;
    }
    const push = margin + 1.4;
    px = cp.x + dx / len * push;
    py = cp.y + dy / len * push;
    if (!pointInsideWarpShape(px, py, margin)) {
      px = px * 0.7 + centroid.x * 0.3;
      py = py * 0.7 + centroid.y * 0.3;
    }
  }
  return { x: px, y: py };
}

function getMirroredBallRenderPoint(ball, margin = 0) {
  const centroid = getWarpCentroid();
  const mx = centroid.x * 2 - ball.x;
  const my = ball.y;
  if (!hasWarpShape()) return { x: mx, y: my };
  return shiftPointInsideWarp(mx, my, margin);
}

function shiftAllBallsInsideWarp() {
  const all = [cue].concat(balls).filter(Boolean);
  all.forEach(b => {
    if (b.pocketed) return;
    const r = (b.num === 0) ? (b._r || BR) : BR;
    if (pointInsideWarpShape(b.x, b.y, r + 0.8)) return;
    const p = shiftPointInsideWarp(b.x, b.y, r + 0.8);
    b.x = p.x;
    b.y = p.y;
  });
}

function clampPortalPointInsideWarp(x, y, margin = 16) {
  const p = shiftPointInsideWarp(x, y, margin);
  return { x: p.x, y: p.y };
}

function separatePortalPoints(entry, exit, minDist = 32) {
  if (!entry || !exit) return exit;
  let dx = exit.x - entry.x;
  let dy = exit.y - entry.y;
  let d = Math.hypot(dx, dy);
  if (d >= minDist) return exit;
  if (d < 1e-4) {
    dx = 1;
    dy = 0;
    d = 1;
  }
  const ux = dx / d;
  const uy = dy / d;
  return { x: entry.x + ux * minDist, y: entry.y + uy * minDist };
}

function normalizePortalsToWarp() {
  if (!activeEffects.portals || !Array.isArray(activeEffects.portals) || activeEffects.portals.length < 2) return;
  let entry = clampPortalPointInsideWarp(activeEffects.portals[0].x, activeEffects.portals[0].y, 16);
  let exit = clampPortalPointInsideWarp(activeEffects.portals[1].x, activeEffects.portals[1].y, 16);
  exit = separatePortalPoints(entry, exit, 32);
  exit = clampPortalPointInsideWarp(exit.x, exit.y, 16);
  activeEffects.portals = [entry, exit];
}

// ── Canvases ────────────────────────────────────────────────
const tc = document.getElementById('tableCanvas');
const tx = tc.getContext('2d');
tc.width = TW; tc.height = TH;

const sc = document.getElementById('spinCanvas');
const sx = sc.getContext('2d');

// ── State ────────────────────────────────────────────────────
let players = [];
let numP = 2;
let current = 0;
let balls = [];
let cue = null;
let started = false;
let inMotion = false;
let canShoot = false;
let power = 0;
let charging = false;
let chargeTimer = null;
let spinX = 0, spinY = 0;
let aimAngle = Math.PI;
let mouseOnTable = false;
let mouseTableX = TW * 0.25, mouseTableY = TH / 2;
let turnPocketed = [];
let cueScratch = false;
let onBreak = true;
let rackShotTaken = false;
let gameOver = false;
let ballInHand = false; // true when player must place cue ball
let gameOverTitle = '';
let gameOverSub = '';
let controlMode = 'mouse'; // 'mouse' | 'phone'
let gameMode = 'local';    // 'local' | 'online'
let gameVariant = 'eight'; // 'eight' | 'nine' | 'cutthroat' | 'doubles'
let debugCardPickEnabled = false;
let phoneAimDragging = false;
let syncingRemoteSnapshot = false;
let onlinePollBusy = false;
let onlinePollTimer = null;
let onlineSyncTimer = null;
let onlinePendingReason = null;
let lastServerInfoBase = '';
let ensuringPublicInviteUrl = false;
let shotFirstContactBall = null;
let shotLowestAtStart = null;
let doublesNextShooterByTeam = { 0: 0, 1: 1 };
let cardPhaseActive = false;
let cardPhaseForPlayer = -1;
let cardPhaseMode = 'idle'; // 'draw' | 'play'
let phaseOfferCards = [];
let phaseOfferSelected = new Set();
let phaseHandSelected = new Set();
let phaseAutoDrawnCards = [];
let phaseDrawAnimTimer = null;
let phaseDrawAnimDone = false;

const onlineSession = {
  connected: false,
  serverUrl: '',
  roomCode: '',
  token: '',
  playerIndex: -1,
  role: 'player', // 'player' | 'spectator'
  lastVersion: 0,
};
const ONLINE_SESSION_KEY = 'rackruin_online_session_v1';

// ── Setup UI ─────────────────────────────────────────────────
const npRow = document.getElementById('npRow');
const numPlayerButtons = {};
[2, 3, 4].forEach(n => {
  const b = document.createElement('button');
  b.className = 'np-btn' + (n === 2 ? ' sel' : '');
  b.textContent = n + 'P';
  b.onclick = () => setNumPlayers(n);
  numPlayerButtons[n] = b;
  npRow.appendChild(b);
});

const modeLocalBtn = document.getElementById('modeLocalBtn');
const modeOnlineBtn = document.getElementById('modeOnlineBtn');
const controlMouseBtn = document.getElementById('controlMouseBtn');
const controlPhoneBtn = document.getElementById('controlPhoneBtn');
const variantEightBtn = document.getElementById('variantEightBtn');
const variantNineBtn = document.getElementById('variantNineBtn');
const variantCutthroatBtn = document.getElementById('variantCutthroatBtn');
const variantDoublesBtn = document.getElementById('variantDoublesBtn');
const debugCardsToggle = document.getElementById('debugCardsToggle');
const onlineSetup = document.getElementById('onlineSetup');
const onlineServerInput = document.getElementById('onlineServerInput');
const onlinePublicUrlInput = document.getElementById('onlinePublicUrlInput');
const onlineCodeInput = document.getElementById('onlineCodeInput');
const onlineCreateBtn = document.getElementById('onlineCreateBtn');
const onlineJoinBtn = document.getElementById('onlineJoinBtn');
const onlineResumeBtn = document.getElementById('onlineResumeBtn');
const onlineLeaveBtn = document.getElementById('onlineLeaveBtn');
const onlineStatus = document.getElementById('onlineStatus');
const roomInfoBox = document.getElementById('roomInfoBox');
const roomInfoCode = document.getElementById('roomInfoCode');
const roomInfoRole = document.getElementById('roomInfoRole');
const roomInfoLink = document.getElementById('roomInfoLink');
const copyRoomCodeBtn = document.getElementById('copyRoomCodeBtn');
const copyInviteBtn = document.getElementById('copyInviteBtn');
const phoneShootButtons = Array.from(document.querySelectorAll('.phone-shoot-btn'));
const pwrHint = document.getElementById('pwrHint');
const controlsText = document.getElementById('controlsText');
const guideCopy = document.querySelector('.guide-copy');
const setupOverlay = document.getElementById('setupOverlay');
const selectionConfirmOverlay = document.getElementById('selectionConfirmOverlay');
const selectionConfirmTitle = document.getElementById('selectionConfirmTitle');
const selectionConfirmBody = document.getElementById('selectionConfirmBody');
const selectionConfirmSkip = document.getElementById('selectionConfirmSkip');
const selectionConfirmYes = document.getElementById('selectionConfirmYes');
const selectionConfirmNo = document.getElementById('selectionConfirmNo');
const ONLINE_DISCOVERY_PORTS = [8000, 8013, 8012];

function closeSelectionConfirm() {
  if (!selectionConfirmOverlay) return;
  selectionConfirmOverlay.classList.remove('show');
  confirmAction = null;
  confirmCancelAction = null;
}

function requestSelectionConfirm({ title, message, onConfirm, onCancel } = {}) {
  if (skipSelectionConfirm || !selectionConfirmOverlay) {
    if (typeof onConfirm === 'function') onConfirm();
    return;
  }
  confirmAction = typeof onConfirm === 'function' ? onConfirm : null;
  confirmCancelAction = typeof onCancel === 'function' ? onCancel : null;
  if (selectionConfirmTitle) selectionConfirmTitle.textContent = title || 'CONFIRM';
  if (selectionConfirmBody) selectionConfirmBody.textContent = message || 'Apply this selection?';
  if (selectionConfirmSkip) selectionConfirmSkip.checked = false;
  selectionConfirmOverlay.classList.add('show');
}

if (selectionConfirmYes) {
  selectionConfirmYes.addEventListener('click', () => {
    if (selectionConfirmSkip && selectionConfirmSkip.checked) skipSelectionConfirm = true;
    const act = confirmAction;
    closeSelectionConfirm();
    if (typeof act === 'function') act();
  });
}
if (selectionConfirmNo) {
  selectionConfirmNo.addEventListener('click', () => {
    const cancel = confirmCancelAction;
    closeSelectionConfirm();
    if (typeof cancel === 'function') cancel();
  });
}

function setVisible(el, show, displayValue = 'block') {
  if (!el) return;
  el.style.display = show ? displayValue : 'none';
  el.classList.toggle('is-visible', !!show);
}

function setSetupOverlayVisible(show) {
  if (!setupOverlay) return;
  setupOverlay.classList.toggle('show', !!show);
}

function getGameVariantLabel(variant = gameVariant) {
  if (variant === 'nine') return '9-BALL';
  if (variant === 'cutthroat') return 'CUTTHROAT';
  if (variant === 'doubles') return 'DOUBLES';
  return '8-BALL';
}

function getGuideTextForVariant(variant = gameVariant) {
  if (variant === 'nine') {
    return [
      '9-BALL: You must hit the lowest-numbered object ball first on every legal shot.',
      'Legally pocket the 9-ball to win the rack.',
      'Your turn continues while you make legal shots. Misses and scratches end your turn.',
      'Card phase starts after your turn ends: auto-draw 3 cards (at least 1 ball + 1 rail), hold up to 7, and optionally play up to 2.',
    ];
  }
  if (variant === 'cutthroat') {
    return [
      'CUTTHROAT (3P): Players own groups 1-5, 6-10, and 11-15.',
      'You attack opponents by pocketing their balls and protect your own group. Last player with at least one of their balls left wins.',
      'Your turn continues while you make legal shots. Misses and scratches end your turn.',
      'Card phase starts after your turn ends: auto-draw 3 cards (at least 1 ball + 1 rail), hold up to 7, and optionally play up to 2.',
    ];
  }
  if (variant === 'doubles') {
    return [
      'DOUBLES (2v2): Teammates share one side (solids or stripes) and one win condition.',
      'Clear your team side, then legally pocket the 8-ball to win for your team.',
      'Your team keeps shooting while legal shots are made. Misses and scratches end the team turn.',
      'Card phase starts after your turn ends: auto-draw 3 cards (at least 1 ball + 1 rail), hold up to 7, and optionally play up to 2.',
    ];
  }
  return [
    '8-BALL: After the first called legal pocket, sides are assigned (solids or stripes).',
    'Clear your side, then legally pocket the 8-ball to win.',
    'Your turn continues while you make legal shots. Misses and scratches end your turn.',
    'Card phase starts after your turn ends: auto-draw 3 cards (at least 1 ball + 1 rail), hold up to 7, and optionally play up to 2.',
  ];
}

function updateGuideCopy() {
  if (!guideCopy) return;
  const lines = getGuideTextForVariant(gameVariant);
  guideCopy.innerHTML = '';
  lines.forEach(line => {
    const p = document.createElement('p');
    p.textContent = line;
    guideCopy.appendChild(p);
  });
}

function isPlayerCountAllowed(n) {
  if (gameMode === 'online') return n === 2;
  if (gameVariant === 'cutthroat') return n === 3;
  if (gameVariant === 'doubles') return n === 4;
  if (gameVariant === 'nine') return n === 2;
  return n === 2;
}

function getPreferredPlayerCount() {
  if (gameMode === 'online') return 2;
  if (gameVariant === 'cutthroat') return 3;
  if (gameVariant === 'doubles') return 4;
  if (gameVariant === 'nine') return 2;
  return 2;
}

function syncPlayerButtons() {
  const preferred = getPreferredPlayerCount();
  if (!isPlayerCountAllowed(numP)) numP = preferred;
  Object.keys(numPlayerButtons).forEach(k => {
    const btn = numPlayerButtons[k];
    if (!btn) return;
    const n = Number(k);
    btn.classList.toggle('sel', n === numP);
    btn.disabled = !isPlayerCountAllowed(n);
  });
}

function updateVariantUI() {
  if (variantEightBtn) variantEightBtn.classList.toggle('sel', gameVariant === 'eight');
  if (variantNineBtn) variantNineBtn.classList.toggle('sel', gameVariant === 'nine');
  if (variantCutthroatBtn) {
    variantCutthroatBtn.classList.toggle('sel', gameVariant === 'cutthroat');
    variantCutthroatBtn.disabled = gameMode === 'online';
  }
  if (variantDoublesBtn) {
    variantDoublesBtn.classList.toggle('sel', gameVariant === 'doubles');
    variantDoublesBtn.disabled = gameMode === 'online';
  }
}

function setNumPlayers(n, force = false) {
  if (!force && !isPlayerCountAllowed(n)) return;
  numP = n;
  syncPlayerButtons();
  buildNames();
}

function buildNames() {
  const existing = Array.from(document.querySelectorAll('.name-inp')).map(inp => inp.value);
  const c = document.getElementById('nameInputs');
  c.innerHTML = '';
  for (let i = 0; i < numP; i++) {
    const inp = document.createElement('input');
    inp.className = 'name-inp';
    inp.placeholder = 'Player ' + (i + 1);
    inp.value = existing[i] || ((players[i] && players[i].name) ? players[i].name : 'Player ' + (i + 1));
    c.appendChild(inp);
  }
}

function updateControlModeUI() {
  controlMouseBtn.classList.toggle('sel', controlMode === 'mouse');
  controlPhoneBtn.classList.toggle('sel', controlMode === 'phone');
  phoneShootButtons.forEach(btn => setVisible(btn, controlMode === 'phone'));
  if (controlMode === 'phone') {
    pwrHint.innerHTML = 'DRAG ON TABLE<br>TO AIM<br>HOLD SIDE BUTTON<br>TO CHARGE<br>RELEASE TO SHOOT';
    controlsText.innerHTML =
      '1. DRAG ON TABLE<br>&nbsp;&nbsp;&nbsp;TO AIM<br>2. SET SPIN<br>&nbsp;&nbsp;&nbsp;POINT<br>3. HOLD SIDE<br>&nbsp;&nbsp;&nbsp;SHOT BUTTON';
  } else {
    pwrHint.innerHTML = 'HOLD MOUSE<br>ON TABLE<br>TO CHARGE<br>RELEASE TO<br>SHOOT';
    controlsText.innerHTML =
      '1. MOVE MOUSE<br>&nbsp;&nbsp;&nbsp;TO AIM<br>2. SET SPIN<br>&nbsp;&nbsp;&nbsp;POINT<br>3. HOLD &amp; RELEASE<br>&nbsp;&nbsp;&nbsp;ON TABLE';
  }
}

function setGameMode(mode) {
  gameMode = mode === 'online' ? 'online' : 'local';
  modeLocalBtn.classList.toggle('sel', gameMode === 'local');
  modeOnlineBtn.classList.toggle('sel', gameMode === 'online');
  if (gameMode === 'online' && (gameVariant === 'cutthroat' || gameVariant === 'doubles')) gameVariant = 'eight';
  updateVariantUI();
  updateGuideCopy();
  setVisible(onlineSetup, gameMode === 'online');
  syncPlayerButtons();
  buildNames();
  updateRoomInfoUI();
  if (gameMode === 'online') {
    setTimeout(refreshServerInfoPublicUrl, 0);
    setTimeout(() => { ensurePublicInviteUrl(false); }, 50);
  }
}

function setGameVariant(variant, force = false) {
  let next = variant;
  if (next !== 'nine' && next !== 'cutthroat' && next !== 'doubles') next = 'eight';
  if (started && !gameOver && rackShotTaken && !force) {
    setStatus('Finish this rack before switching game mode.', true);
    return;
  }
  if (gameMode === 'online' && (next === 'cutthroat' || next === 'doubles') && !force) {
    updateOnlineStatus('This mode is local-only. Switch to LOCAL first.', true);
    return;
  }
  if (gameMode === 'online' && (next === 'cutthroat' || next === 'doubles')) next = 'eight';
  gameVariant = next;
  updateVariantUI();
  updateGuideCopy();
  syncPlayerButtons();
  buildNames();
  if (started && !gameOver && !rackShotTaken && !force) {
    setStatus('Mode changed. Press RACK UP to re-rack with this setup.', true);
  }
}

function setControlMode(mode) {
  controlMode = mode === 'phone' ? 'phone' : 'mouse';
  updateControlModeUI();
}

function updateOnlineStatus(msg, foul = false) {
  if (!onlineStatus) return;
  onlineStatus.textContent = 'ONLINE: ' + msg;
  onlineStatus.style.color = foul ? '#ff8f77' : '';
}

function getRoleLabel() {
  if (gameMode !== 'online') return '-';
  if (!isOnlineActive()) return 'UNJOINED';
  if (onlineSession.role === 'spectator') return 'SPECTATOR';
  if (onlineSession.playerIndex === 0) return 'HOST';
  if (onlineSession.playerIndex === 1) return 'GUEST';
  return 'PLAYER';
}

function buildInviteLinkFromBase(rawBase, code) {
  const cleanedBase = sanitizeServerUrl(rawBase);
  if (!cleanedBase || !code) return '';
  const fallbackOrigin = (window.location.origin && window.location.origin !== 'null')
    ? window.location.origin
    : 'http://localhost:8000';
  let url;
  try {
    url = new URL(cleanedBase, fallbackOrigin);
  } catch (_) {
    return '';
  }

  const currentPath = (window.location.pathname || '').trim();
  const hasHtmlPath = /\.html?$/i.test(url.pathname || '');
  if (!hasHtmlPath) {
    if (/\.html?$/i.test(currentPath)) {
      url.pathname = currentPath;
    } else if (!url.pathname || url.pathname === '/') {
      url.pathname = '/PLAY ME.html';
    } else if (url.pathname.endsWith('/')) {
      url.pathname += 'PLAY ME.html';
    } else {
      url.pathname += '/PLAY ME.html';
    }
  }

  const params = new URLSearchParams(url.search || '');
  params.set('room', code);

  const apiBase = sanitizeServerUrl(onlineSession.serverUrl || onlineServerInput.value || '');
  let apiOrigin = '';
  if (apiBase) {
    try { apiOrigin = new URL(apiBase).origin; } catch (_) { apiOrigin = ''; }
  }
  if (apiBase && apiOrigin && apiOrigin !== url.origin) params.set('server', apiBase);
  else params.delete('server');

  const nextSearch = params.toString();
  url.search = nextSearch ? ('?' + nextSearch) : '';
  url.hash = '';
  return url.toString();
}

function getInviteLink() {
  const code = onlineSession.roomCode || (onlineCodeInput.value || '').trim().toUpperCase();
  if (!code) return '';
  const publicLink = buildInviteLinkFromBase(onlinePublicUrlInput ? onlinePublicUrlInput.value : '', code);
  if (publicLink) return publicLink;
  const fallbackBase = (onlineSession.connected && onlineSession.serverUrl)
    ? onlineSession.serverUrl
    : normalizeServerUrl(onlineServerInput.value);
  const origin = (window.location.origin && window.location.origin !== 'null')
    ? window.location.origin
    : '';
  return buildInviteLinkFromBase(fallbackBase || origin || 'http://localhost:8000', code);
}

function updateRoomInfoUI() {
  if (!roomInfoBox) return;
  if (gameMode !== 'online') {
    setVisible(roomInfoBox, false);
    roomInfoCode.textContent = '-';
    roomInfoRole.textContent = '-';
    roomInfoLink.textContent = '-';
    return;
  }
  setVisible(roomInfoBox, true);
  const code = (onlineSession.roomCode || onlineCodeInput.value || '').trim().toUpperCase();
  roomInfoCode.textContent = code || '-';
  roomInfoRole.textContent = getRoleLabel();
  const link = getInviteLink() || '-';
  roomInfoLink.innerHTML = '';
  if (link === '-') {
    roomInfoLink.textContent = '-';
  } else {
    const a = document.createElement('a');
    a.href = link;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.textContent = link;
    roomInfoLink.appendChild(a);
    roomInfoLink.title = link;
  }
  const canCopyCode = !!code;
  const canCopyLink = link !== '-';
  if (copyRoomCodeBtn) copyRoomCodeBtn.disabled = !canCopyCode;
  if (copyInviteBtn) copyInviteBtn.disabled = !canCopyLink;
}

async function copyTextToClipboard(text) {
  if (!text) return false;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (_) { /* fallback below */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return !!ok;
  } catch (_) {
    return false;
  }
}

function saveOnlineSession() {
  if (!onlineSession.connected || !onlineSession.roomCode || !onlineSession.token) return;
  const payload = {
    serverUrl: onlineSession.serverUrl,
    publicUrl: onlinePublicUrlInput ? sanitizeServerUrl(onlinePublicUrlInput.value) : '',
    roomCode: onlineSession.roomCode,
    token: onlineSession.token,
    playerIndex: onlineSession.playerIndex,
    role: onlineSession.role,
  };
  try {
    localStorage.setItem(ONLINE_SESSION_KEY, JSON.stringify(payload));
  } catch (_) { /* ignore */ }
}

function clearSavedOnlineSession() {
  try { localStorage.removeItem(ONLINE_SESSION_KEY); } catch (_) { /* ignore */ }
}

function loadSavedOnlineSession() {
  try {
    const raw = localStorage.getItem(ONLINE_SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.roomCode || !parsed.token) return null;
    return parsed;
  } catch (_) {
    return null;
  }
}

function uniqStrings(items) {
  return Array.from(new Set((items || []).filter(Boolean)));
}

function sanitizeServerUrl(raw) {
  const trimmed = (raw || '').trim();
  if (!trimmed) return '';
  const hasScheme = /^[a-z][a-z\d+\-.]*:\/\//i.test(trimmed);
  const baseRaw = hasScheme ? trimmed : ('http://' + trimmed);
  const fallbackOrigin = (window.location.origin && window.location.origin !== 'null')
    ? window.location.origin
    : 'http://localhost:8000';
  try {
    const parsed = new URL(baseRaw, fallbackOrigin);
    const proto = (parsed.protocol || '').toLowerCase();
    if (proto !== 'http:' && proto !== 'https:') return '';
    parsed.hash = '';
    parsed.search = '';
    const joined = parsed.origin + parsed.pathname;
    return joined.replace(/\/+$/, '');
  } catch (_) {
    return '';
  }
}

function isLoopbackUrl(raw) {
  const parsed = sanitizeServerUrl(raw);
  if (!parsed) return true;
  try {
    const u = new URL(parsed);
    const h = (u.hostname || '').toLowerCase();
    return h === 'localhost' || h === '127.0.0.1' || h === '::1' || h.startsWith('127.');
  } catch (_) {
    return true;
  }
}

function maybeAutofillPublicInviteUrl(serverProvided, fallbackBase, allowLoopbackFallback = false) {
  if (!onlinePublicUrlInput) return;
  const current = sanitizeServerUrl(onlinePublicUrlInput.value || '');
  const preferred = sanitizeServerUrl(serverProvided);
  if (preferred && (!current || (isLoopbackUrl(current) && !isLoopbackUrl(preferred)))) {
    onlinePublicUrlInput.value = preferred;
    return;
  }
  if (current) return;
  const fallback = sanitizeServerUrl(fallbackBase);
  if (fallback && (allowLoopbackFallback || !isLoopbackUrl(fallback))) {
    onlinePublicUrlInput.value = fallback;
  }
}

function waitMs(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function ensurePublicInviteUrl(autoStartTunnel = false) {
  if (gameMode !== 'online' || !onlinePublicUrlInput) return false;
  const existing = sanitizeServerUrl(onlinePublicUrlInput.value || '');
  if (existing && !isLoopbackUrl(existing)) return true;
  if (ensuringPublicInviteUrl) return false;
  ensuringPublicInviteUrl = true;
  try {
    const info = await onlineApi('/api/server-info', null, 'GET');
    maybeAutofillPublicInviteUrl(info.data.publicBaseUrl, info.base, true);
    const afterInfo = sanitizeServerUrl(onlinePublicUrlInput.value || '');
    if (afterInfo && !isLoopbackUrl(afterInfo)) {
      updateRoomInfoUI();
      if (isOnlineActive()) saveOnlineSession();
      return true;
    }
    if (!autoStartTunnel) {
      updateRoomInfoUI();
      return false;
    }
    updateOnlineStatus('Starting public tunnel for shareable invite link...');
    await onlineApi('/api/start-tunnel', {}, 'POST');
    for (let i = 0; i < 20; i++) {
      const polled = await onlineApi('/api/server-info', null, 'GET');
      maybeAutofillPublicInviteUrl(polled.data.publicBaseUrl, polled.base, true);
      const now = sanitizeServerUrl(onlinePublicUrlInput.value || '');
      if (now && !isLoopbackUrl(now)) {
        updateRoomInfoUI();
        if (isOnlineActive()) saveOnlineSession();
        updateOnlineStatus('Public invite URL ready.');
        return true;
      }
      await waitMs(350);
    }
    updateRoomInfoUI();
    updateOnlineStatus('Tunnel not ready yet. Keep server running; retry Create Room in a few seconds.', true);
    return false;
  } catch (err) {
    updateOnlineStatus('Public URL setup failed: ' + err.message, true);
    return false;
  } finally {
    ensuringPublicInviteUrl = false;
  }
}

function normalizeServerUrl(raw) {
  const detected = (window.location.origin && window.location.origin !== 'null')
    ? window.location.origin
    : 'http://localhost:8000';
  return sanitizeServerUrl(raw) || sanitizeServerUrl(detected) || 'http://localhost:8000';
}

function shouldAutoDiscoverServer() {
  if (onlineSession.connected && onlineSession.serverUrl) return false;
  return !(onlineServerInput.value || '').trim();
}

function getOnlineServerCandidates() {
  if (onlineSession.connected && onlineSession.serverUrl) {
    return [normalizeServerUrl(onlineSession.serverUrl)];
  }
  const explicit = sanitizeServerUrl(onlineServerInput.value);
  const detected = (window.location.origin && window.location.origin !== 'null')
    ? sanitizeServerUrl(window.location.origin)
    : '';
  const localCandidates = ONLINE_DISCOVERY_PORTS.flatMap(port => ([
    'http://localhost:' + port,
    'http://127.0.0.1:' + port,
  ]));
  if (explicit) {
    // If user points at localhost that isn't the multiplayer API, still probe known local ports.
    if (isLoopbackUrl(explicit)) return uniqStrings([explicit, detected, ...localCandidates]);
    return [explicit];
  }
  return uniqStrings([detected, ...localCandidates]);
}

function isNetworkishError(err) {
  const msg = String((err && err.message) || '');
  return err && (
    err.name === 'TypeError' ||
    /failed to fetch|networkerror|load failed|network request failed/i.test(msg)
  );
}

function formatServerDiscoveryError(path, candidates) {
  const fileHint = (window.location.protocol === 'file:')
    ? ' Open the game from the server URL (for example, http://localhost:8013/PLAY%20ME.html), not via file://.'
    : '';
  const hint =
    'Start one with `python3 server/multiplayer_server.py --port 8000` or set SERVER URL to that multiplayer server. If another static server is on 8013/8012, it will not provide /api endpoints.' + fileHint;
  if (!candidates || !candidates.length) {
    return 'No online server URL available for ' + path + '. ' + hint;
  }
  return 'No online server responded for ' + path + '. Tried: ' + candidates.join(', ') + '. ' + hint;
}

function isOnlineActive() {
  return gameMode === 'online' && onlineSession.connected;
}

function isLocalSeatTurn() {
  if (!isOnlineActive()) return true;
  if (onlineSession.role !== 'player') return false;
  return current === onlineSession.playerIndex;
}

function isLocalCardInteractionWindow() {
  if (!isOnlineActive()) return false;
  if (onlineSession.role !== 'player') return false;
  const interactionActive =
    cardPhaseActive ||
    !!ballPickerStep ||
    !!pocketPickerStep ||
    !!railPickerStep ||
    tablePlacerActive ||
    portalPlaceState > 0 ||
    !!warpPocketResizeStep;
  return interactionActive && cardPhaseForPlayer === onlineSession.playerIndex;
}

function onlineInputLocked() {
  if (isLocalCardInteractionWindow()) return false;
  return isOnlineActive() && !isLocalSeatTurn();
}

function resetOnlineSession(statusMsg) {
  if (onlinePollTimer) { clearTimeout(onlinePollTimer); onlinePollTimer = null; }
  if (onlineSyncTimer) { clearTimeout(onlineSyncTimer); onlineSyncTimer = null; }
  onlinePendingReason = null;
  onlineSession.connected = false;
  onlineSession.serverUrl = '';
  onlineSession.roomCode = '';
  onlineSession.token = '';
  onlineSession.playerIndex = -1;
  onlineSession.role = 'player';
  onlineSession.lastVersion = 0;
  clearSavedOnlineSession();
  updateRoomInfoUI();
  if (statusMsg) updateOnlineStatus(statusMsg, true);
}

function applyOnlinePlayerNames(playerNames) {
  if (!Array.isArray(playerNames) || !playerNames.length) return;
  const inps = document.querySelectorAll('.name-inp');
  for (let i = 0; i < inps.length; i++) {
    if (playerNames[i]) inps[i].value = playerNames[i];
  }
}

function connectOnlineSession(base, data) {
  onlineSession.connected = true;
  onlineSession.serverUrl = base;
  onlineSession.roomCode = data.code;
  onlineSession.token = data.token;
  onlineSession.playerIndex = (typeof data.seat === 'number') ? data.seat : -1;
  onlineSession.role = data.role === 'spectator' ? 'spectator' : 'player';
  onlineSession.lastVersion = data.version || 0;
  onlineCodeInput.value = data.code || '';
  if (base) onlineServerInput.value = base;
  maybeAutofillPublicInviteUrl(data.publicBaseUrl, base, true);
  setGameMode('online');
  setNumPlayers(2, true);
  if (data.players) applyOnlinePlayerNames(data.players.map(p => p.name));
  saveOnlineSession();
  updateRoomInfoUI();
  setTimeout(() => { ensurePublicInviteUrl(false); }, 80);
}

async function onlineApi(path, payload, method = 'POST') {
  const candidates = getOnlineServerCandidates();
  const autoDiscover = shouldAutoDiscoverServer();
  let lastErr = null;
  for (const base of candidates) {
    try {
      const res = await fetch(base + path, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: payload ? JSON.stringify(payload) : undefined,
      });
      const data = await res.json().catch(() => ({}));
      const apiOk = !!(data && data.ok === true);
      if (!res.ok || !apiOk) {
        const err = new Error(data.error || ('HTTP ' + res.status));
        const wrongServerLike =
          res.status === 404 ||
          res.status === 405 ||
          (res.ok && !apiOk);
        if (wrongServerLike && (autoDiscover || candidates.length > 1)) {
          lastErr = err;
          continue;
        }
        throw err;
      }
      return { base, data };
    } catch (err) {
      if ((autoDiscover || candidates.length > 1) && isNetworkishError(err)) {
        lastErr = err;
        continue;
      }
      throw err;
    }
  }
  throw new Error(formatServerDiscoveryError(path, candidates) + (lastErr ? (' Last error: ' + lastErr.message) : ''));
}

async function refreshServerInfoPublicUrl() {
  if (gameMode !== 'online') return;
  try {
    const { base, data } = await onlineApi('/api/server-info', null, 'GET');
    if (base === lastServerInfoBase && onlinePublicUrlInput && onlinePublicUrlInput.value) return;
    maybeAutofillPublicInviteUrl(data.publicBaseUrl, base, true);
    lastServerInfoBase = base;
    updateRoomInfoUI();
    if (isOnlineActive()) saveOnlineSession();
  } catch (_) { /* ignore */ }
}

function scheduleOnlinePoll(delayMs = 0) {
  if (!isOnlineActive()) return;
  if (onlinePollTimer) clearTimeout(onlinePollTimer);
  onlinePollTimer = setTimeout(pollOnlineState, delayMs);
}

async function pollOnlineState() {
  if (!isOnlineActive() || onlinePollBusy) return;
  onlinePollBusy = true;
  let nextDelay = 0;
  try {
    const q = new URLSearchParams({
      code: onlineSession.roomCode,
      token: onlineSession.token,
      since: String(onlineSession.lastVersion || 0),
    });
    const res = await fetch(onlineSession.serverUrl + '/api/state?' + q.toString());
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status));
    const beforePublic = onlinePublicUrlInput ? onlinePublicUrlInput.value : '';
    maybeAutofillPublicInviteUrl(data.publicBaseUrl, onlineSession.serverUrl, false);
    if (onlinePublicUrlInput && onlinePublicUrlInput.value !== beforePublic) {
      updateRoomInfoUI();
      saveOnlineSession();
    }
    if (data.role) onlineSession.role = data.role === 'spectator' ? 'spectator' : 'player';
    if (typeof data.seat === 'number') onlineSession.playerIndex = data.seat;
    saveOnlineSession();
    updateRoomInfoUI();
    if (Array.isArray(data.players)) applyOnlinePlayerNames(data.players.map(p => p.name));
    if (typeof data.spectatorCount === 'number') {
      const countLabel = data.spectatorCount ? (' · spectators ' + data.spectatorCount) : '';
      if (onlineSession.role === 'spectator') updateOnlineStatus('Spectating room ' + onlineSession.roomCode + countLabel);
    }
    if (typeof data.version === 'number' && data.version > onlineSession.lastVersion) {
      onlineSession.lastVersion = data.version;
      const fromSelf = (
        onlineSession.role === 'player' &&
        typeof data.updatedBy === 'number' &&
        data.updatedBy === onlineSession.playerIndex
      );
      if (data.snapshot && (!fromSelf || !started)) {
        applyGameSnapshot(data.snapshot, true);
      }
    }
  } catch (err) {
    updateOnlineStatus('Sync error: ' + err.message, true);
    nextDelay = 700;
  } finally {
    onlinePollBusy = false;
    scheduleOnlinePoll(nextDelay);
  }
}

function queueOnlineSync(reason) {
  if (!isOnlineActive() || syncingRemoteSnapshot) return;
  if (onlineSession.role !== 'player') return;
  onlinePendingReason = reason || onlinePendingReason || 'update';
  if (onlineSyncTimer) return;
  const delay = (onlinePendingReason === 'shot_tick') ? 55 : 30;
  onlineSyncTimer = setTimeout(async () => {
    onlineSyncTimer = null;
    const nextReason = onlinePendingReason || 'update';
    onlinePendingReason = null;
    await pushOnlineSnapshot(nextReason);
    if (onlinePendingReason) queueOnlineSync(onlinePendingReason);
  }, delay);
}

function buildOnlineUpdatePayload(reason) {
  return {
    code: onlineSession.roomCode,
    token: onlineSession.token,
    snapshot: serializeGameSnapshot(reason || 'update'),
    reason: reason || 'update',
  };
}

async function pushOnlineSnapshot(reason) {
  if (!isOnlineActive() || syncingRemoteSnapshot) return;
  try {
    const { data } = await onlineApi('/api/update-state', buildOnlineUpdatePayload(reason));
    if (typeof data.version === 'number') onlineSession.lastVersion = Math.max(onlineSession.lastVersion, data.version);
  } catch (err) {
    updateOnlineStatus('Push failed: ' + err.message, true);
  }
}

function flushOnlineSnapshotBeacon(reason = 'background') {
  if (!isOnlineActive() || syncingRemoteSnapshot) return;
  if (onlineSession.role !== 'player') return;
  try {
    const payload = JSON.stringify(buildOnlineUpdatePayload(reason));
    const url = onlineSession.serverUrl + '/api/update-state';
    if (navigator.sendBeacon) {
      const blob = new Blob([payload], { type: 'application/json' });
      navigator.sendBeacon(url, blob);
      return;
    }
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      keepalive: true,
    }).catch(() => {});
  } catch (_) { /* no-op */ }
}

async function createOnlineRoom() {
  try {
    const inps = document.querySelectorAll('.name-inp');
    const myName = (inps[0] && inps[0].value.trim()) || 'Player 1';
    const preferredCode = (onlineCodeInput.value || '').trim().toUpperCase();
    const { base, data } = await onlineApi('/api/create-room', {
      name: myName,
      code: preferredCode || undefined,
    });
    connectOnlineSession(base, data);
    maybeAutofillPublicInviteUrl(data.publicBaseUrl, base, true);
    await ensurePublicInviteUrl(true);
    updateRoomInfoUI();
    saveOnlineSession();
    const inviteBase = sanitizeServerUrl(onlinePublicUrlInput ? onlinePublicUrlInput.value : '');
    const hasPublic = !!inviteBase && !isLoopbackUrl(inviteBase);
    const msg = hasPublic
      ? ('Room ' + data.code + ' created. Waiting for opponent...')
      : ('Room ' + data.code + ' created. Invite URL set, but it is local-only. Set PUBLIC INVITE URL for off-device players.');
    updateOnlineStatus(msg);
    scheduleOnlinePoll(10);
  } catch (err) {
    updateOnlineStatus('Create failed: ' + err.message, true);
  }
}

async function joinOnlineRoom() {
  try {
    const code = onlineCodeInput.value.trim().toUpperCase();
    if (!code) throw new Error('Enter a room code');
    const inps = document.querySelectorAll('.name-inp');
    const myName = (inps[0] && inps[0].value.trim()) || 'Player';
    const { base, data } = await onlineApi('/api/join-room', { code, name: myName });
    connectOnlineSession(base, data);
    const roleMsg = onlineSession.role === 'spectator'
      ? 'Joined as spectator'
      : (data.reclaimed ? 'Reclaimed player seat' : 'Joined room');
    updateOnlineStatus(roleMsg + ' ' + data.code + '. Waiting for host rack...');
    if (onlineSession.role === 'spectator') setStatus('Spectating room ' + data.code, true);
    if (data.snapshot) applyGameSnapshot(data.snapshot, true);
    scheduleOnlinePoll(10);
  } catch (err) {
    updateOnlineStatus('Join failed: ' + err.message, true);
  }
}

async function resumeOnlineRoom() {
  try {
    const saved = loadSavedOnlineSession();
    if (!saved) throw new Error('No saved session');
    onlineServerInput.value = saved.serverUrl || onlineServerInput.value;
    if (onlinePublicUrlInput && saved.publicUrl) onlinePublicUrlInput.value = saved.publicUrl;
    onlineCodeInput.value = saved.roomCode || onlineCodeInput.value;
    const { base, data } = await onlineApi('/api/reconnect', {
      code: saved.roomCode,
      token: saved.token,
    });
    connectOnlineSession(base, data);
    const who = onlineSession.role === 'spectator'
      ? 'spectator'
      : (onlineSession.playerIndex === 0 ? 'host' : 'guest');
    updateOnlineStatus('Resumed as ' + who + ' in room ' + data.code);
    if (onlineSession.role === 'spectator') setStatus('Spectating room ' + data.code, true);
    if (data.snapshot) applyGameSnapshot(data.snapshot, true);
    scheduleOnlinePoll(10);
  } catch (err) {
    clearSavedOnlineSession();
    updateOnlineStatus('Resume failed: ' + err.message, true);
  }
}

modeLocalBtn.addEventListener('click', () => {
  if (isOnlineActive() || loadSavedOnlineSession()) resetOnlineSession('Disconnected');
  setGameMode('local');
});
modeOnlineBtn.addEventListener('click', () => setGameMode('online'));
controlMouseBtn.addEventListener('click', () => setControlMode('mouse'));
controlPhoneBtn.addEventListener('click', () => setControlMode('phone'));
variantEightBtn.addEventListener('click', () => setGameVariant('eight'));
variantNineBtn.addEventListener('click', () => setGameVariant('nine'));
variantCutthroatBtn.addEventListener('click', () => setGameVariant('cutthroat'));
variantDoublesBtn.addEventListener('click', () => setGameVariant('doubles'));
debugCardsToggle.addEventListener('change', () => { debugCardPickEnabled = !!debugCardsToggle.checked; });
onlineCreateBtn.addEventListener('click', createOnlineRoom);
onlineJoinBtn.addEventListener('click', joinOnlineRoom);
onlineResumeBtn.addEventListener('click', resumeOnlineRoom);
onlineLeaveBtn.addEventListener('click', () => {
  resetOnlineSession('Disconnected');
  setGameMode('local');
});
onlineServerInput.addEventListener('input', () => {
  updateRoomInfoUI();
  if (gameMode === 'online') {
    setTimeout(refreshServerInfoPublicUrl, 0);
    setTimeout(() => { ensurePublicInviteUrl(false); }, 50);
  }
});
if (onlinePublicUrlInput) onlinePublicUrlInput.addEventListener('input', () => {
  updateRoomInfoUI();
  if (isOnlineActive()) saveOnlineSession();
});
onlineCodeInput.addEventListener('input', updateRoomInfoUI);
window.addEventListener('pagehide', () => flushOnlineSnapshotBeacon('page_hide'));
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') flushOnlineSnapshotBeacon('tab_hidden');
});
copyRoomCodeBtn.addEventListener('click', async () => {
  const code = onlineSession.roomCode || (onlineCodeInput.value || '').trim().toUpperCase();
  const ok = await copyTextToClipboard(code);
  updateOnlineStatus(ok ? ('Copied room code ' + code) : 'Failed to copy room code', !ok);
});
copyInviteBtn.addEventListener('click', async () => {
  const link = getInviteLink();
  const ok = await copyTextToClipboard(link);
  updateOnlineStatus(ok ? 'Copied invite link' : 'Failed to copy invite link', !ok);
});

buildNames();
setGameVariant('eight', true);
setGameMode('local');
setControlMode('mouse');
const qp = new URLSearchParams(window.location.search);
const roomFromUrl = (qp.get('room') || '').trim().toUpperCase();
const serverFromUrl = (qp.get('server') || '').trim();
const savedSession = loadSavedOnlineSession();
if (serverFromUrl) onlineServerInput.value = serverFromUrl;
if (savedSession && savedSession.publicUrl && onlinePublicUrlInput) onlinePublicUrlInput.value = savedSession.publicUrl;
if (roomFromUrl) {
  onlineCodeInput.value = roomFromUrl;
  setGameMode('online');
  updateOnlineStatus('Room code prefilled from invite link');
}
if (!roomFromUrl && savedSession) {
  setGameMode('online');
  updateOnlineStatus('Saved session found. Click RESUME.');
}

document.getElementById('rackBtn').onclick = () => {
  if (gameMode === 'online') {
    if (!isOnlineActive()) {
      setStatus('Connect to an online room first', true);
      return;
    }
    if (onlineSession.role !== 'player' || onlineSession.playerIndex !== 0) {
      setStatus('Host player must rack up', true);
      return;
    }
  }
  const inps = document.querySelectorAll('.name-inp');
  players = Array.from(inps).map((el, i) => ({
    name: el.value.trim() || 'Player ' + (i + 1),
    score: 0,
    type: null,
    group: null,
    team: null,
    hand: [],
  }));
  startGame();
  setSetupOverlayVisible(false);
  queueOnlineSync('rack_up');
};

document.getElementById('msgBtn').onclick = () => {
  if (isOnlineActive() && (onlineSession.role !== 'player' || onlineSession.playerIndex !== 0)) {
    setStatus('Host player must rack up a new game', true);
    return;
  }
  document.getElementById('overlay').classList.remove('show');
  setSetupOverlayVisible(true);
  setStatus('Configure setup, then press RACK UP.', true);
};

// ── Game Init ─────────────────────────────────────────────────
function startGame() {
  gameOver = false;
  gameOverTitle = '';
  gameOverSub = '';
  document.getElementById('overlay').classList.remove('show');
  setSetupOverlayVisible(false);
  current = 0;
  onBreak = true;
  rackShotTaken = false;
  turnPocketed = [];
  cueScratch = false;
  shotFirstContactBall = null;
  shotLowestAtStart = null;
  inMotion = false;
  canShoot = true;
  power = 0;
  players.forEach(p => { p.type = null; p.group = null; p.team = null; p.score = 0; p.hand = []; });
  if (gameVariant === 'cutthroat') {
    players.forEach((p, i) => { p.group = CUTTHROAT_GROUPS[i] || CUTTHROAT_GROUPS[i % CUTTHROAT_GROUPS.length]; });
  }
  if (gameVariant === 'doubles') {
    players.forEach((p, i) => { p.team = i % 2; });
    doublesNextShooterByTeam = { 0: 0, 1: 1 };
  } else {
    doublesNextShooterByTeam = { 0: 0, 1: 1 };
  }
  // Reset all card effects
  // Reset all card effects to defaults
  Object.assign(activeEffects, {
    fogOfWar:false, heavyweight:null, lightweight:null,
    confusion:false, confusionMap:null, confusionStripeMap:null, cloaked:null,
    sticky:false, drunk:false, shortsighted:false,
    roidRage:false, coolHands:false, bigBall:false, smallBall:false,
    oilCue:false, reverseSpin:false, mirror:false, magnet:false,
    turbo:false,
    bounceHouseRail:[], deadRail:[], bearTrap:[],
    bearTrapZone:null, bearTrapRevealUntil:0,
    portals:null, icePatch:null, blockedPockets:[],
    bouncer:null, mudPatch:null, wind:0,
    pocketShrink:null, movedPockets:{},
    warpCorners:null,
    warpMids:null,
  });
  stopDrunkTimer();
  stopRoidRageTimer();
  tablePlacerActive = false; tablePlacerStep = null;
  portalPlaceState = 0; portalEntry = null;
  warpPocketResizeStep = null;
  interactionQueue = []; pendingBallInHand = false;
  ballPickerStep = null; ballPickerPreviewNum = null;
  pocketPickerStep = null; pocketPickerHover = null;
  railPickerStep = null; railPickerHover = null;
  hideBallPickerHint(); hidePocketPickerHint(); hideRailPickerHint();
  closeSelectionConfirm();
  updateEffectsPanel();
  placeBalls();
  refreshCutthroatScores();
  refreshDoublesScores();
  started = true;
  updatePowerUI();
  setStatus(players[0].name + '  —  ' + getGameVariantLabel() + ' Break Shot');
  updateHeader();
  updateDots();
}

function placeBalls() {
  const layout = getRackLayoutForVariant(gameVariant);
  balls = layout.numbers.map((num, i) => ({
    num, x: layout.positions[i].x, y: layout.positions[i].y,
    vx: 0, vy: 0, wx: 0, wy: 0, sx: 0, sy: 0, roll: 0,
    pocketed: false,
    c: DEFS[num].c,
    stripe: DEFS[num].s,
  }));
  cue = {
    num: 0, x: TW * 0.25, y: TH / 2,
    vx: 0, vy: 0, wx: 0, wy: 0, sx: 0, sy: 0, roll: 0,
    pocketed: false, c: '#f0f0f0', stripe: false,
  };
}

function getLowestObjectBallOnTable() {
  let low = null;
  for (let i = 0; i < balls.length; i++) {
    const b = balls[i];
    if (b.pocketed) continue;
    if (low === null || b.num < low) low = b.num;
  }
  return low;
}

function isSpotClear(x, y, excludeNum = null) {
  if (!pointInsideWarpShape(x, y, BR + 1)) return false;
  const objs = [cue].concat(balls);
  for (let i = 0; i < objs.length; i++) {
    const b = objs[i];
    if (!b || b.pocketed) continue;
    if (excludeNum != null && b.num === excludeNum) continue;
    const r = b.num === 0 ? (b._r || BR) : BR;
    const dx = b.x - x;
    const dy = b.y - y;
    if (dx * dx + dy * dy < (r + BR + 1) * (r + BR + 1)) return false;
  }
  return true;
}

function spotBall(num) {
  const target = balls.find(b => b.num === num);
  if (!target) return;
  const baseX = TW * 0.72;
  const baseY = TH / 2;
  const offsets = [
    [0, 0], [-22, 0], [22, 0], [0, -22], [0, 22], [-22, -22], [22, 22], [-22, 22], [22, -22],
  ];
  let placed = false;
  for (let i = 0; i < offsets.length; i++) {
    const x = baseX + offsets[i][0];
    const y = baseY + offsets[i][1];
    if (!isSpotClear(x, y, num)) continue;
    target.x = x;
    target.y = y;
    placed = true;
    break;
  }
  if (!placed) {
    target.x = baseX;
    target.y = baseY;
  }
  target.pocketed = false;
  target.vx = target.vy = target.wx = target.wy = target.sx = target.sy = 0;
  target.roll = 0;
}

function getCutthroatRemaining(group) {
  if (!group || !CUTTHROAT_GROUP_NUMS[group]) return 0;
  return balls.reduce((acc, b) => {
    if (b.pocketed) return acc;
    return CUTTHROAT_GROUP_NUMS[group].includes(b.num) ? (acc + 1) : acc;
  }, 0);
}

function refreshCutthroatScores() {
  if (gameVariant !== 'cutthroat') return;
  players.forEach(p => {
    p.score = getCutthroatRemaining(p.group);
  });
}

function isCutthroatEliminated(idx) {
  if (gameVariant !== 'cutthroat') return false;
  const p = players[idx];
  if (!p) return false;
  return getCutthroatRemaining(p.group) <= 0;
}

function getCutthroatWinnerIndex() {
  if (gameVariant !== 'cutthroat') return -1;
  const alive = [];
  for (let i = 0; i < players.length; i++) {
    if (!isCutthroatEliminated(i)) alive.push(i);
  }
  if (alive.length === 0) return -2;
  return alive.length === 1 ? alive[0] : -1;
}

function getNextPlayerIndex(fromIdx = current) {
  if (!players.length) return 0;
  for (let step = 1; step <= players.length; step++) {
    const idx = (fromIdx + step) % players.length;
    if (gameVariant === 'cutthroat' && isCutthroatEliminated(idx)) continue;
    return idx;
  }
  return fromIdx;
}

function isBallOwnedByCutthroatPlayer(player, ballNum) {
  if (!player || !player.group) return false;
  const nums = CUTTHROAT_GROUP_NUMS[player.group] || [];
  return nums.includes(ballNum);
}

function getCutthroatGroupTag(group) {
  return CUTTHROAT_GROUP_LABELS[group] || '?';
}

function getDoublesTeamForPlayer(idx) {
  return idx % 2;
}

function getDoublesTeammate(idx) {
  return (idx + 2) % 4;
}

function getDoublesTeamName(team) {
  const members = players
    .map((p, i) => ({ p, i }))
    .filter(entry => (entry.p.team ?? getDoublesTeamForPlayer(entry.i)) === team)
    .map(entry => entry.p.name);
  if (!members.length) return team === 0 ? 'Team A' : 'Team B';
  return members.join(' & ');
}

function getDoublesTeamType(team) {
  for (let i = 0; i < players.length; i++) {
    const p = players[i];
    const t = (typeof p.team === 'number') ? p.team : getDoublesTeamForPlayer(i);
    if (t === team && p.type) return p.type;
  }
  return null;
}

function setDoublesTeamType(team, type) {
  players.forEach((p, i) => {
    const t = (typeof p.team === 'number') ? p.team : getDoublesTeamForPlayer(i);
    if (t === team) p.type = type;
  });
}

function areDoublesTeamBallsCleared(team) {
  const teamType = getDoublesTeamType(team);
  if (!teamType) return false;
  return balls.every(b => {
    if (b.num === 8) return true;
    if (teamType === 'stripe') return !b.stripe || b.pocketed;
    return b.stripe || b.pocketed;
  });
}

function getDoublesTeamScore(team) {
  const teamType = getDoublesTeamType(team);
  if (!teamType) return 0;
  return balls.reduce((acc, b) => {
    if (b.num === 8 || !b.pocketed) return acc;
    if ((teamType === 'stripe' && b.stripe) || (teamType === 'solid' && !b.stripe)) return acc + 1;
    return acc;
  }, 0);
}

function refreshDoublesScores() {
  if (gameVariant !== 'doubles') return;
  players.forEach((p, i) => {
    const t = (typeof p.team === 'number') ? p.team : getDoublesTeamForPlayer(i);
    p.score = getDoublesTeamScore(t);
  });
}

// ── Physics ───────────────────────────────────────────────────
// Proper rolling model with sliding/rolling transition.
// Each ball tracks:
//   vx/vy  — linear velocity
//   wx/wy  — spin surface velocity (what the ball "wants" to roll at)
//   sx/sy  — side-spin (english), bleeds into vx/vy over time
//   roll   — cumulative rotation angle for visual rendering

function physicsStep() {
  if (!inMotion) return;
  if (isOnlineActive() && !isLocalSeatTurn()) return;

  const alive = [cue].concat(balls).filter(b => !b.pocketed);
  let anyMoving = false;

  for (let i = 0; i < alive.length; i++) {
    const b = alive[i];

    const spd = Math.hypot(b.vx, b.vy);
    if (spd < MIN_V && Math.hypot(b.sx, b.sy) < 0.01) {
      b.vx = b.vy = b.wx = b.wy = b.sx = b.sy = 0;
      continue;
    }

    anyMoving = true;

    // Side-spin (english) bleeds into linear vel
    b.vx += b.sx * 0.018;
    b.vy += b.sy * 0.018;
    b.sx *= SPIN_DECAY;
    b.sy *= SPIN_DECAY;

    // Slip velocity: difference between linear motion and rolling surface vel
    const slipX = b.vx - b.wx;
    const slipY = b.vy - b.wy;
    const slipSpd = Math.hypot(slipX, slipY);

    if (slipSpd > 0.25) {
      // Sliding phase — kinetic friction decelerates linear vel toward spin vel
      const fric = SLIDE_MU;
      b.vx -= slipX * fric;
      b.vy -= slipY * fric;
      // Spin picks up from the surface (traction)
      b.wx += slipX * fric * 0.35;
      b.wy += slipY * fric * 0.35;
    } else {
      // Rolling phase — unify linear & spin, apply gentle rolling friction
      const avg = 0.5;
      b.vx = (b.vx * avg + b.wx * (1 - avg));
      b.vy = (b.vy * avg + b.wy * (1 - avg));
      const spd2 = Math.hypot(b.vx, b.vy);
      if (spd2 > 1e-6) {
        const decel = Math.max(0, spd2 - ROLL_MU) / spd2;
        b.vx *= decel;
        b.vy *= decel;
      } else {
        b.vx = 0;
        b.vy = 0;
      }
      b.wx = b.vx;
      b.wy = b.vy;
    }

    b.x += b.vx;
    b.y += b.vy;

    // Table effects (bumpers, mud, ice, wind, magnet)
    applyTableEffects(b);

    // Accumulate roll angle for visual spin rendering
    b.roll = ((b.roll || 0) + Math.hypot(b.vx, b.vy) / BR) % (Math.PI * 2);

    // Walls (supports warped quadrilateral table shape)
    const _br = b.num === 0 ? (b._r || BR) : BR;
    resolveWarpWallCollision(b, _br);
    clampBallSpeed(b);
  }

  // Ball-ball collisions (elastic, equal mass, restitution 0.97)
  for (let i = 0; i < alive.length; i++) {
    for (let j = i + 1; j < alive.length; j++) {
      const a = alive[i], b = alive[j];
      const dx = b.x - a.x, dy = b.y - a.y;
      const distSq = dx * dx + dy * dy;
      const ra = a.num===0 ? (a._r||BR) : BR;
      const rb = b.num===0 ? (b._r||BR) : BR;
      const minD = ra + rb;
      if (distSq < minD * minD && distSq > 0.0001) {
        const dist = Math.sqrt(distSq);
        const nx = dx / dist, ny = dy / dist;
        // Separate overlapping balls
        const overlap = (minD - dist) * 0.51;
        a.x -= nx * overlap; a.y -= ny * overlap;
        b.x += nx * overlap; b.y += ny * overlap;
        // Impulse along normal
        const dvx = a.vx - b.vx, dvy = a.vy - b.vy;
        const dot = dvx * nx + dvy * ny;
        if (dot > 0) {
          // Mass ratio for heavyweight/lightweight cards
          const getMass = (ball) => {
            if (ball.num !== 0 && activeEffects.heavyweight === ball.num) return 4.0;
            if (ball.num !== 0 && activeEffects.lightweight === ball.num) return 0.25;
            if (ball.num === 0 && activeEffects.bigBall)   return 1.6;
            if (ball.num === 0 && activeEffects.smallBall) return 0.4;
            return 1.0;
          };
          const ma = getMass(a), mb = getMass(b);
          const totalM = ma + mb;
          const impA = dot * (2 * mb / totalM) * 0.97;
          const impB = dot * (2 * ma / totalM) * 0.97;
          a.vx -= impA * nx; a.vy -= impA * ny;
          b.vx += impB * nx; b.vy += impB * ny;
          a.wx = a.vx; a.wy = a.vy;
          b.wx = b.vx; b.wy = b.vy;
          audioCall('ballHit', Math.max(0.08, Math.min(1, dot / 10)));
          clampBallSpeed(a);
          clampBallSpeed(b);
          anyMoving = true;
          if (shotFirstContactBall === null) {
            if (a.num === 0 && b.num > 0) shotFirstContactBall = b.num;
            else if (b.num === 0 && a.num > 0) shotFirstContactBall = a.num;
          }
          // Sticky: cue ball locks to first object ball briefly
          if (activeEffects.sticky && !cue._stuck) {
            if (a.num === 0 || b.num === 0) {
              cue._stuck = true;
              const obj = a.num === 0 ? b : a;
              // Transfer some velocity: cue drags along
              const drag = 0.35;
              cue.vx = cue.vx*(1-drag) + obj.vx*drag;
              cue.vy = cue.vy*(1-drag) + obj.vy*drag;
            }
          }
        }
      }
    }
  }

  // Pocket check
  for (let i = 0; i < alive.length; i++) {
    const b = alive[i];
    for (let p = 0; p < POCKETS.length; p++) {
      const pk = getPocketPos(p);
      const dx = b.x - pk.x, dy = b.y - pk.y;
      // Blocked pocket — bounce instead of pocket
      if (activeEffects.blockedPockets.includes(p)) {
        const dist = Math.hypot(dx,dy);
        if (dist < POCKET_R+BR && dist>0.01) {
          const nx=dx/dist, ny=dy/dist;
          b.x=pk.x+nx*(POCKET_R+BR); b.y=pk.y+ny*(POCKET_R+BR);
          const dot=b.vx*nx+b.vy*ny;
          if(dot<0){
            b.vx-=2*dot*nx*0.7; b.vy-=2*dot*ny*0.7;
            audioCall('railHit', Math.max(0.08, Math.min(1, (-dot) / 10)), 'rail');
          }
        }
        continue;
      }
      const effectivePR = getPocketR(p);
      const ballR = b.num === 0 ? (b._r || BR) : BR;
      const sinkR = effectivePR + ballR * 0.6;
      if (dx * dx + dy * dy < sinkR * sinkR) {
        b.pocketed = true;
        b.vx = 0; b.vy = 0; b.wx = 0; b.wy = 0; b.sx = 0; b.sy = 0;
        audioCall('pocket', b.num === 0 ? 'cue' : 'object');
        if (b.num === 0) cueScratch = true;
        else turnPocketed.push(b.num);
        break;
      }
    }
  }

  if (isOnlineActive() && isLocalSeatTurn()) queueOnlineSync('shot_tick');

  if (!anyMoving) {
    inMotion = false;
    endTurn();
  }
}

// ── Turn End Logic ────────────────────────────────────────────
function evaluateEightBallTurn(shooterIdx) {
  const p = players[shooterIdx];
  const scratch = cueScratch;
  cueScratch = false;
  if (turnPocketed.includes(8)) {
    if (scratch) {
      const nextIdx = getNextPlayerIndex(shooterIdx);
      finishGame(players[nextIdx].name.toUpperCase() + ' WINS!', p.name + ' scratched on the 8-ball.');
    } else if (p.type !== null) {
      const myNums = balls.filter(b => {
        if (b.num === 8) return false;
        return p.type === 'stripe' ? b.stripe : !b.stripe;
      });
      const allCleared = myNums.every(b => b.pocketed);
      if (allCleared) finishGame(p.name.toUpperCase() + ' WINS!', '8-ball legally pocketed!');
      else {
        const nextIdx = getNextPlayerIndex(shooterIdx);
        finishGame(players[nextIdx].name.toUpperCase() + ' WINS!', p.name + ' sunk the 8-ball early!');
      }
    } else {
      const nextIdx = getNextPlayerIndex(shooterIdx);
      finishGame(players[nextIdx].name.toUpperCase() + ' WINS!', p.name + ' sunk the 8-ball on break!');
    }
    return { ended: true };
  }

  let madeLegal = false;
  if (!onBreak && turnPocketed.length > 0 && p.type === null) {
    const firstNum = turnPocketed.find(n => n !== 8);
    if (firstNum !== undefined) {
      const goStripe = DEFS[firstNum].s;
      if (players.length === 2) {
        players.forEach((pl, idx) => {
          if (idx === shooterIdx) pl.type = goStripe ? 'stripe' : 'solid';
          else if (pl.type === null) pl.type = goStripe ? 'solid' : 'stripe';
        });
      } else {
        p.type = goStripe ? 'stripe' : 'solid';
      }
    }
  }
  if (!onBreak) {
    turnPocketed.forEach(n => {
      if (n === 8) return;
      const def = DEFS[n];
      if (p.type === null) return;
      if ((p.type === 'stripe' && def.s) || (p.type === 'solid' && !def.s)) {
        madeLegal = true;
        p.score++;
      }
    });
  }
  return { ended: false, madeLegal, foul: scratch };
}

function evaluateNineBallTurn(shooterIdx) {
  const p = players[shooterIdx];
  const scratch = cueScratch;
  cueScratch = false;
  const firstHit = shotFirstContactBall;
  const lowest = shotLowestAtStart != null ? shotLowestAtStart : getLowestObjectBallOnTable();
  const wrongFirst = lowest != null && firstHit !== lowest;
  const noHit = firstHit === null;
  const foul = scratch || wrongFirst || noHit;
  const pocketedNine = turnPocketed.includes(9);

  if (pocketedNine && foul) {
    spotBall(9);
    turnPocketed = turnPocketed.filter(n => n !== 9);
  }
  if (pocketedNine && !foul) {
    finishGame(p.name.toUpperCase() + ' WINS!', '9-ball legally pocketed.');
    return { ended: true };
  }

  const madeLegal = !foul && turnPocketed.length > 0;
  if (!foul && turnPocketed.length > 0) p.score += turnPocketed.length;
  return { ended: false, madeLegal, foul };
}

function evaluateCutthroatTurn(shooterIdx) {
  const shooter = players[shooterIdx];
  const scratch = cueScratch;
  cueScratch = false;
  const pocketedOpponentBall = turnPocketed.some(n => !isBallOwnedByCutthroatPlayer(shooter, n));
  refreshCutthroatScores();

  const winnerIdx = getCutthroatWinnerIndex();
  if (winnerIdx === -2) {
    finishGame('DRAW', 'All groups were cleared in the same shot.');
    return { ended: true };
  }
  if (winnerIdx >= 0) {
    finishGame(players[winnerIdx].name.toUpperCase() + ' WINS!', 'Last player with any group ball still on the table.');
    return { ended: true };
  }

  const shooterEliminated = isCutthroatEliminated(shooterIdx);
  const madeLegal = !scratch && pocketedOpponentBall && !shooterEliminated;
  return { ended: false, madeLegal, foul: scratch };
}

function evaluateDoublesTurn(shooterIdx) {
  const shooter = players[shooterIdx];
  const team = (typeof shooter.team === 'number') ? shooter.team : getDoublesTeamForPlayer(shooterIdx);
  const oppTeam = 1 - team;
  const scratch = cueScratch;
  cueScratch = false;

  // Scotch-doubles rotation: each shot flips to the teammate for that team.
  doublesNextShooterByTeam[team] = getDoublesTeammate(shooterIdx);

  if (turnPocketed.includes(8)) {
    const legal = !scratch && getDoublesTeamType(team) && areDoublesTeamBallsCleared(team);
    const winnerTeam = legal ? team : oppTeam;
    const winnerName = getDoublesTeamName(winnerTeam);
    const reason = legal
      ? '8-ball legally pocketed by team.'
      : (scratch ? 'Scratch on the 8-ball.' : '8-ball pocketed early.');
    finishGame(winnerName.toUpperCase() + ' WIN!', reason);
    return { ended: true };
  }

  let madeLegal = false;
  if (!onBreak && turnPocketed.length > 0 && !getDoublesTeamType(team)) {
    const firstNum = turnPocketed.find(n => n !== 8);
    if (firstNum !== undefined) {
      const myType = DEFS[firstNum].s ? 'stripe' : 'solid';
      setDoublesTeamType(team, myType);
      setDoublesTeamType(oppTeam, myType === 'stripe' ? 'solid' : 'stripe');
    }
  }

  if (!onBreak) {
    const myType = getDoublesTeamType(team);
    turnPocketed.forEach(n => {
      if (n === 8 || !myType) return;
      const def = DEFS[n];
      if ((myType === 'stripe' && def.s) || (myType === 'solid' && !def.s)) madeLegal = true;
    });
  }

  refreshDoublesScores();
  return { ended: false, madeLegal, foul: scratch, team };
}

function resolveTurnFlow(shooterIdx, madeLegal, foul) {
  const turnLost = !!(foul || !madeLegal);
  onBreak = false;
  turnPocketed = [];
  refreshCutthroatScores();
  refreshDoublesScores();
  updateDots();
  if (gameVariant === 'doubles') {
    const shooterTeam = getDoublesTeamForPlayer(shooterIdx);
    const nextTeam = foul || !madeLegal ? (1 - shooterTeam) : shooterTeam;
    const nextIdx = Number(doublesNextShooterByTeam[nextTeam]);
    current = Number.isFinite(nextIdx) ? nextIdx : getNextPlayerIndex(current);
  } else if (foul || !madeLegal) {
    current = getNextPlayerIndex(current);
  }
  updateHeader();
  shotFirstContactBall = null;
  shotLowestAtStart = null;
  power = 0;
  updatePowerUI();
  queueOnlineSync('turn_end');

  pendingBallInHand = false;
  if (players.length >= 2 && turnLost) {
    canShoot = false;
    pendingBallInHand = !!foul;
    setStatus(players[shooterIdx].name + ' — card phase...');
    setTimeout(() => showCardPhase(shooterIdx), 320);
    return;
  }

  if (foul) {
    enterBallInHand();
    queueOnlineSync('scratch_ball_in_hand');
    return;
  }
  canShoot = true;
  setStatus(players[current].name + "'s Turn");
  queueOnlineSync('turn_ready');
}

function endTurn() {
  if (gameOver) return;
  clearBallEffects();
  const shooterIdx = current;
  let result = null;
  if (gameVariant === 'nine') result = evaluateNineBallTurn(shooterIdx);
  else if (gameVariant === 'cutthroat') result = evaluateCutthroatTurn(shooterIdx);
  else if (gameVariant === 'doubles') result = evaluateDoublesTurn(shooterIdx);
  else result = evaluateEightBallTurn(shooterIdx);
  if (!result || result.ended || gameOver) {
    turnPocketed = [];
    shotFirstContactBall = null;
    shotLowestAtStart = null;
    updateDots();
    updateHeader();
    return;
  }
  resolveTurnFlow(shooterIdx, !!result.madeLegal, !!result.foul);
}

function enterBallInHand() {
  ballInHand = true;
  canShoot = false;
  cue.pocketed = false;
  cue.x = mouseTableX;
  cue.y = mouseTableY;
  cue.vx = 0; cue.vy = 0; cue.sx = 0; cue.sy = 0;
  setStatus(players[current].name + ' — Place Cue Ball (click to confirm)', true);
  updateHeader();
  queueOnlineSync('ball_in_hand');
}

function isValidPlacement(x, y) {
  // Must be inside play area with margin
  if (!pointInsideWarpShape(x, y, BR + 2)) return false;
  // Must not overlap any ball
  for (let i = 0; i < balls.length; i++) {
    const b = balls[i];
    if (b.pocketed) continue;
    const dx = b.x - x, dy = b.y - y;
    if (dx * dx + dy * dy < (BR * 2 + 2) * (BR * 2 + 2)) return false;
  }
  return true;
}

function finishGame(title, sub) {
  gameOver = true;
  gameOverTitle = title;
  gameOverSub = sub;
  started = false;
  document.getElementById('msgTitle').textContent = title;
  document.getElementById('msgSub').textContent = sub;
  document.getElementById('msgBtn').textContent = 'NEW GAME';
  document.getElementById('overlay').classList.add('show');
  queueOnlineSync('game_over');
}

// ── Power / Shoot ─────────────────────────────────────────────
// Aim is locked the instant the player presses mousedown on the table.
// Holding charges power. Releasing fires the shot.

function updatePowerUI() {
  const fill = document.getElementById('pwrFill');
  const val  = document.getElementById('pwrVal');
  fill.style.height = power + '%';
  const r = Math.min(255, Math.round(power * 2.8));
  const g = Math.min(200, Math.round((100 - power) * 1.8));
  fill.style.background = 'rgb(' + r + ',' + g + ',15)';
  val.textContent = Math.round(power) + '%';
}

function getShotPowerBounds() {
  let min = 0;
  let max = 100;
  if (activeEffects.roidRage) min = 75;
  if (activeEffects.coolHands) max = Math.min(max, 25);
  if (max < min) max = min;
  return { min, max };
}

function clampShotPower(v) {
  const lim = getShotPowerBounds();
  return Math.max(lim.min, Math.min(lim.max, v));
}

function getTablePos(e) {
  const rect = tc.getBoundingClientRect();
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const clientY = e.touches ? e.touches[0].clientY : e.clientY;
  return {
    x: (clientX - rect.left) * (TW / rect.width),
    y: (clientY - rect.top)  * (TH / rect.height),
  };
}

function canStartShotInput() {
  return canShoot && !inMotion && !gameOver && started && !!cue && !cue.pocketed;
}

function updateAimFromPos(pos) {
  if (!cue) return;
  aimAngle = Math.atan2(pos.y - cue.y, pos.x - cue.x);
}

function beginCharge() {
  if (charging || !canStartShotInput() || onlineInputLocked()) return;
  charging = true;
  clearInterval(chargeTimer);
  chargeTimer = setInterval(() => {
    power = clampShotPower(power + 1.6);
    updatePowerUI();
  }, 25);
}

function releaseCharge() {
  if (!charging) return;
  charging = false;
  clearInterval(chargeTimer);
  chargeTimer = null;
  power = clampShotPower(power);
  if (power > 1 && canStartShotInput()) {
    fireShot();
  } else {
    power = 0;
    updatePowerUI();
  }
}

function onTableMouseDown(e) {
  e.preventDefault();
  if (onlineInputLocked()) return;
  audioCall('unlockFromGesture');
  const pos = getTablePos(e);

  // Ball picker — click directly on a ball on the live table
  if (ballPickerStep) { handleBallPickerClick(pos.x, pos.y); return; }
  // Pocket picker — click pocket directly on live table
  if (pocketPickerStep) { handlePocketPickerClick(pos.x, pos.y); return; }
  // Rail picker — click a rail on the live table
  if (railPickerStep) { handleRailPickerClick(pos.x, pos.y); return; }
  // Table placer interaction (e.g. bouncer placement, mud patch, ice patch)
  if (tablePlacerActive) { handleTablePlacerClick(pos.x, pos.y); return; }
  // Portal placement
  if (portalPlaceState > 0) { handlePortalClick(pos.x, pos.y); return; }
  // Warp pocket resize placement
  if (warpPocketResizeStep) { handleWarpPocketResizeClick(pos.x, pos.y); return; }

  // Ball-in-hand: click to confirm placement
  if (ballInHand) {
    if (isValidPlacement(pos.x, pos.y)) {
      cue.x = pos.x;
      cue.y = pos.y;
      ballInHand = false;
      canShoot = true;
      setStatus(players[current].name + "'s Turn");
      queueOnlineSync('ball_in_hand_placed');
    }
    return;
  }

  if (!canStartShotInput()) return;
  updateAimFromPos(pos);
  if (controlMode === 'phone') {
    phoneAimDragging = true;
    return;
  }
  beginCharge();
}

function onTableMouseUp(e) {
  phoneAimDragging = false;
  if (controlMode === 'phone') {
    releaseCharge();
    return;
  }
  releaseCharge();
}

function fireShot() {
  if (onlineInputLocked()) return;
  rackShotTaken = true;
  shotFirstContactBall = null;
  shotLowestAtStart = getLowestObjectBallOnTable();
  const shotPower = clampShotPower(power);
  power = shotPower;
  let spd = (power / 100) * 21;
  // Drunk: offset the actual fire angle
  const fireAngle = activeEffects.drunk ? aimAngle + drunkOffset : aimAngle;
  // Big ball hits harder (more mass), small ball hits softer
  if (activeEffects.bigBall)   spd *= 1.3;
  if (activeEffects.smallBall) spd *= 0.6;
  if (activeEffects.turbo)     spd *= 1.6;
  cue.vx = Math.cos(fireAngle) * spd;
  cue.vy = Math.sin(fireAngle) * spd;
  // wx/wy: top/backspin shifts initial spin surface vel
  // spinY<0 = topspin (wx/wy ahead of vel), spinY>0 = backspin (behind)
  const spinFwd = -spinY; // positive = topspin
  cue.wx = cue.vx * (1 + spinFwd * 0.8);
  cue.wy = cue.vy * (1 + spinFwd * 0.8);
  // Side english
  const effectiveSpin = activeEffects.reverseSpin ? -spinX : spinX;
  cue.sx = effectiveSpin * spd * 0.35;
  cue.sy = 0;
  // Reset sticky flag (will re-arm on next collision)
  cue._stuck = false;
  audioCall('shot', shotPower);
  power = 0;
  updatePowerUI();
  canShoot = false;
  inMotion = true;
  queueOnlineSync('shot_start');
}

tc.addEventListener('mousedown',  onTableMouseDown);
tc.addEventListener('touchstart', onTableMouseDown, { passive: false });
document.addEventListener('mouseup',  onTableMouseUp);
document.addEventListener('touchend', onTableMouseUp);

// ── Aiming ────────────────────────────────────────────────────
function onTablePointerMove(e) {
  if (!started || !cue) return;
  if (onlineInputLocked()) return;
  mouseOnTable = true;
  const pos = getTablePos(e);
  mouseTableX = pos.x;
  mouseTableY = pos.y;
  if (railPickerStep) handleRailPickerMove(pos.x, pos.y);
  if (pocketPickerStep) handlePocketPickerMove(pos.x, pos.y);

  if (ballInHand) {
    // Snap cue ball to mouse, clamped inside table
    const b = getInnerBounds(BR + 2);
    const cx = Math.max(b.left, Math.min(b.right, pos.x));
    const cy = Math.max(b.top, Math.min(b.bottom, pos.y));
    cue.x = cx;
    cue.y = cy;
    return;
  }

  if (!inMotion && canShoot && !charging && !cue.pocketed) {
    if (controlMode === 'mouse') updateAimFromPos(pos);
    else if (phoneAimDragging) updateAimFromPos(pos);
  }
}

tc.addEventListener('mousemove', onTablePointerMove);
tc.addEventListener('touchmove', e => {
  if (controlMode === 'phone') e.preventDefault();
  onTablePointerMove(e);
}, { passive: false });
tc.addEventListener('mouseleave', () => { mouseOnTable = false; });

phoneShootButtons.forEach(btn => {
  btn.addEventListener('mousedown', e => {
    e.preventDefault();
    if (controlMode !== 'phone') return;
    audioCall('unlockFromGesture');
    beginCharge();
  });
  btn.addEventListener('touchstart', e => {
    e.preventDefault();
    if (controlMode !== 'phone') return;
    audioCall('unlockFromGesture');
    beginCharge();
  }, { passive: false });
  ['mouseup','mouseleave','touchend','touchcancel'].forEach(evt => {
    btn.addEventListener(evt, e => {
      if (evt.startsWith('touch')) e.preventDefault();
      if (controlMode !== 'phone') return;
      releaseCharge();
    });
  });
});

// ── Spin Picker ───────────────────────────────────────────────
function redrawSpin() {
  if (drawSpinDialHD) {
    drawSpinDialHD(sx, sc, spinX, spinY);
    return;
  }
  const w = sc.width, h = sc.height, cx = w / 2, cy = h / 2, r = w / 2 - 5;
  sx.clearRect(0, 0, w, h);
  const g = sx.createRadialGradient(cx - 8, cy - 8, 3, cx, cy, r);
  g.addColorStop(0, '#e8e0d0'); g.addColorStop(1, '#999');
  sx.beginPath(); sx.arc(cx, cy, r, 0, Math.PI * 2);
  sx.fillStyle = g; sx.fill();
  sx.strokeStyle = 'rgba(0,0,0,.15)'; sx.lineWidth = 1;
  sx.beginPath();
  sx.moveTo(cx, cy - r); sx.lineTo(cx, cy + r);
  sx.moveTo(cx - r, cy); sx.lineTo(cx + r, cy);
  sx.stroke();
  sx.fillStyle = 'rgba(0,0,0,.38)'; sx.font = '8px Space Mono'; sx.textAlign = 'center';
  sx.fillText('TOP', cx, cy - r + 11);
  sx.fillText('BTM', cx, cy + r - 3);
  sx.textAlign = 'left'; sx.fillText('L', cx - r + 3, cy + 3);
  sx.textAlign = 'right'; sx.fillText('R', cx + r - 3, cy + 3);
  const ddx = spinX * r * 0.78, ddy = spinY * r * 0.78;
  sx.beginPath(); sx.arc(cx + ddx, cy + ddy, 8, 0, Math.PI * 2);
  sx.fillStyle = '#c0392b'; sx.fill();
  sx.beginPath(); sx.arc(cx + ddx - 2, cy + ddy - 2, 3, 0, Math.PI * 2);
  sx.fillStyle = 'rgba(255,255,255,.7)'; sx.fill();
}

function applySpinClick(e) {
  const rect = sc.getBoundingClientRect();
  const r = sc.width / 2 - 5;
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const clientY = e.touches ? e.touches[0].clientY : e.clientY;
  const mx = clientX - rect.left - sc.width / 2;
  const my = clientY - rect.top - sc.height / 2;
  const len = Math.sqrt(mx * mx + my * my);
  const clamp = Math.min(1, len / r);
  spinX = len > 0 ? (mx / len) * clamp : 0;
  spinY = len > 0 ? (my / len) * clamp : 0;
  redrawSpin();
}

sc.addEventListener('mousedown', applySpinClick);
sc.addEventListener('mousemove', e => { if (e.buttons > 0) applySpinClick(e); });
sc.addEventListener('touchstart', e => { e.preventDefault(); applySpinClick(e); });
sc.addEventListener('touchmove', e => { e.preventDefault(); applySpinClick(e); });

// ── Drawing ───────────────────────────────────────────────────
function drawTable() {
  if (drawTableSurfaceHD && !hasWarpShape()) {
    drawTableSurfaceHD(tx, {
      width: TW,
      height: TH,
      rail: RAIL,
      pocketRadius: POCKET_R,
    });
    return;
  }

  tx.clearRect(0, 0, TW, TH);
  tx.fillStyle = '#2d1a08';
  tx.fillRect(0, 0, TW, TH);
  const poly = getWarpPolygonPoints();
  const felt = tx.createRadialGradient(TW * 0.5, TH * 0.5, 24, TW * 0.5, TH * 0.5, TW * 0.6);
  felt.addColorStop(0, '#2a7a35');
  felt.addColorStop(1, '#1a5422');
  tx.fillStyle = felt;
  tx.beginPath();
  tx.moveTo(poly[0].x, poly[0].y);
  for (let i = 1; i < poly.length; i++) tx.lineTo(poly[i].x, poly[i].y);
  tx.closePath();
  tx.fill();
  tx.strokeStyle = 'rgba(150,255,100,0.15)';
  tx.lineWidth = 2;
  tx.stroke();
  POCKETS.forEach((_, i) => {
    const p = getPocketPos(i);
    tx.beginPath(); tx.arc(p.x, p.y, POCKET_R, 0, Math.PI * 2);
    tx.fillStyle = '#000'; tx.fill();
  });
}


function drawRailOverlay(rail, color, alpha) {
  const edges = getWarpEdges().filter(e => e.wall === rail);
  if (!edges.length) return;
  tx.save();
  tx.globalAlpha = alpha;
  tx.strokeStyle = color;
  tx.lineWidth = Math.max(8, RAIL * 0.7);
  tx.lineCap = 'round';
  edges.forEach(edge => {
    tx.beginPath();
    tx.moveTo(edge.a.x, edge.a.y);
    tx.lineTo(edge.b.x, edge.b.y);
    tx.stroke();
  });
  tx.restore();
}

function drawBearTrapSymbol(x, y, alpha = 1) {
  tx.save();
  tx.globalAlpha = alpha;
  tx.beginPath();
  tx.arc(x, y, 10, 0, Math.PI * 2);
  tx.fillStyle = 'rgba(60,66,74,0.92)';
  tx.fill();
  tx.beginPath();
  tx.arc(x, y, 6.4, 0, Math.PI * 2);
  tx.fillStyle = 'rgba(15,18,22,0.95)';
  tx.fill();
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI;
    const x1 = x + Math.cos(a) * 6.8;
    const y1 = y + Math.sin(a) * 6.8;
    const x2 = x + Math.cos(a) * 10.5;
    const y2 = y + Math.sin(a) * 10.5;
    tx.beginPath();
    tx.moveTo(x1, y1);
    tx.lineTo(x2, y2);
    tx.strokeStyle = 'rgba(207,215,226,0.95)';
    tx.lineWidth = 1.3;
    tx.stroke();
  }
  tx.restore();
}

function drawPocketHoleAt(x, y, r) {
  tx.beginPath();
  tx.arc(x, y, r, 0, Math.PI * 2);
  tx.fillStyle = '#000';
  tx.fill();
  tx.strokeStyle = '#1a0800';
  tx.lineWidth = Math.max(1.4, r * 0.16);
  tx.stroke();

  const depth = tx.createRadialGradient(x, y, 1, x, y, r);
  depth.addColorStop(0, 'rgba(0,0,0,0)');
  depth.addColorStop(0.5, 'rgba(0,0,0,0.5)');
  depth.addColorStop(1, 'rgba(0,0,0,0.95)');
  tx.beginPath();
  tx.arc(x, y, r, 0, Math.PI * 2);
  tx.fillStyle = depth;
  tx.fill();
}

function drawTableEffects() {
  const ae = activeEffects;
  const warped = hasWarpShape();

  if (warped) {
    const poly = getWarpPolygonPoints();
    tx.save();
    tx.beginPath();
    tx.moveTo(poly[0].x, poly[0].y);
    for (let i = 1; i < poly.length; i++) tx.lineTo(poly[i].x, poly[i].y);
    tx.closePath();
    tx.fillStyle = 'rgba(86,184,255,0.14)';
    tx.fill();
    tx.setLineDash([7, 5]);
    tx.strokeStyle = 'rgba(86,184,255,0.85)';
    tx.lineWidth = 2;
    tx.stroke();
    tx.setLineDash([]);
    tx.restore();
  }

  // Rail effects
  ae.bounceHouseRail.forEach(r => drawRailOverlay(r, '#ff0',    0.30));
  ae.deadRail.forEach(r        => drawRailOverlay(r, '#964B00', 0.35));

  // Mud patch
  if (ae.mudPatch) {
    const m=ae.mudPatch;
    tx.beginPath(); tx.arc(m.x,m.y,m.r,0,Math.PI*2);
    tx.fillStyle='rgba(100,60,20,0.38)'; tx.fill();
    tx.strokeStyle='rgba(150,100,40,0.55)'; tx.lineWidth=1.5; tx.stroke();
    tx.fillStyle='rgba(180,120,50,0.55)'; tx.font='8px Space Mono'; tx.textAlign='center'; tx.textBaseline='middle';
    tx.fillText('MUD',m.x,m.y);
  }

  // Ice patch
  if (ae.icePatch) {
    const ic=ae.icePatch;
    tx.beginPath(); tx.arc(ic.x,ic.y,ic.r,0,Math.PI*2);
    tx.fillStyle='rgba(140,220,255,0.18)'; tx.fill();
    tx.strokeStyle='rgba(180,240,255,0.4)'; tx.lineWidth=1.5; tx.stroke();
    tx.fillStyle='rgba(200,240,255,0.5)'; tx.font='7px Space Mono'; tx.textAlign='center'; tx.textBaseline='middle';
    tx.fillText('ICE',ic.x,ic.y);
  }

  // Bouncer (player-placed)
  if (ae.bouncer) {
    const bmp=ae.bouncer;
    // Collision handled here each frame
    const alive=[cue].concat(balls).filter(b=>!b.pocketed);
    alive.forEach(b=>{
      const dx=b.x-bmp.x,dy=b.y-bmp.y,dist=Math.hypot(dx,dy),minD=bmp.r+BR;
      if(dist<minD&&dist>0.01){
        const nx=dx/dist,ny=dy/dist;
        b.x=bmp.x+nx*minD; b.y=bmp.y+ny*minD;
        const dot=b.vx*nx+b.vy*ny;
        if(dot<0){b.vx-=2*dot*nx*0.85; b.vy-=2*dot*ny*0.85;}
      }
    });
    tx.beginPath(); tx.arc(bmp.x,bmp.y,bmp.r,0,Math.PI*2);
    const grad=tx.createRadialGradient(bmp.x-2,bmp.y-2,1,bmp.x,bmp.y,bmp.r);
    grad.addColorStop(0,'#ff6b5b'); grad.addColorStop(1,'#c0392b');
    tx.fillStyle=grad; tx.fill();
    tx.strokeStyle='rgba(255,150,130,0.7)'; tx.lineWidth=2; tx.stroke();
    // Pulsing ring
    const pulse=(Date.now()%1000)/1000;
    tx.beginPath(); tx.arc(bmp.x,bmp.y,bmp.r+4+pulse*6,0,Math.PI*2);
    tx.strokeStyle=`rgba(255,100,80,${0.4*(1-pulse)})`; tx.lineWidth=1.5; tx.stroke();
  }

  // Bear trap reveal: briefly show location/icon before trap cloaks.
  if (ae.bearTrapZone && ae.bearTrapRevealUntil && Date.now() < ae.bearTrapRevealUntil) {
    const left = Math.max(1, ae.bearTrapRevealUntil - Date.now());
    const alpha = Math.min(1, left / 900);
    drawBearTrapSymbol(ae.bearTrapZone.x, ae.bearTrapZone.y, alpha);
  }

  // Portals
  if (ae.portals) {
    const [ent,ext]=ae.portals;
    const t=Date.now()/600;
    [[ent,'#8855ff','#aa77ff'],[ext,'#00ccaa','#44eebb']].forEach(([p,c1,c2])=>{
      for(let ring=0;ring<3;ring++){
        const phase=(t+ring*0.33)%1;
        tx.beginPath(); tx.arc(p.x,p.y,14+phase*10,0,Math.PI*2);
        tx.strokeStyle=c1; tx.globalAlpha=0.6*(1-phase); tx.lineWidth=2; tx.stroke(); tx.globalAlpha=1;
      }
      tx.beginPath(); tx.arc(p.x,p.y,14,0,Math.PI*2);
      tx.fillStyle=c2+'44'; tx.fill();
      tx.strokeStyle=c2; tx.lineWidth=2; tx.stroke();
    });
    // Labels
    tx.fillStyle='rgba(255,255,255,0.5)'; tx.font='7px Space Mono'; tx.textAlign='center'; tx.textBaseline='middle';
    tx.fillText('IN',ent.x,ent.y); tx.fillText('OUT',ext.x,ext.y);
  }

  // Pocket modifiers
  POCKETS.forEach((_,i)=>{
    const pp = getPocketPos(i);
    const moved = !!(ae.movedPockets && ae.movedPockets[i]);
    const blocked = ae.blockedPockets.includes(i);
    const effectiveR = getPocketR(i);
    if (moved) {
      // Cover original hole with felt colour
      const op = getBasePocketPos(i);
      tx.beginPath(); tx.arc(op.x,op.y,POCKET_R+4,0,Math.PI*2);
      tx.fillStyle='#1d7f49'; tx.fill();
    }

    if (blocked) {
      tx.beginPath(); tx.arc(pp.x,pp.y,POCKET_R,0,Math.PI*2);
      tx.fillStyle='rgba(231,76,60,0.55)'; tx.fill();
      tx.strokeStyle='#e74c3c'; tx.lineWidth=2; tx.stroke();
      tx.fillStyle='#fff'; tx.font='bold 9px Space Mono'; tx.textAlign='center'; tx.textBaseline='middle';
      tx.fillText('X',pp.x,pp.y);
      return;
    }

    if (effectiveR < POCKET_R - 0.2) {
      // Fill existing hole and redraw a smaller opening instead of a ring overlay.
      tx.beginPath();
      tx.arc(pp.x, pp.y, POCKET_R + 2.4, 0, Math.PI * 2);
      tx.fillStyle = '#1d7f49';
      tx.fill();
    }

    if (moved || effectiveR < POCKET_R - 0.2) {
      drawPocketHoleAt(pp.x, pp.y, effectiveR);
    }

    if (moved) {
      tx.beginPath(); tx.arc(pp.x,pp.y,effectiveR+3,0,Math.PI*2);
      tx.strokeStyle='rgba(201,168,76,0.7)';
      tx.lineWidth=2;
      tx.stroke();
    }
  });
}

function drawBallPickerHighlights() {
  // Pulse ring on each selectable ball so player knows what to click
  const t = Date.now() / 500;
  const pulse = 0.5 + 0.5 * Math.sin(t * Math.PI * 2);
  balls.filter(b => !b.pocketed && b.num !== 0 && b.num !== 8).forEach(b => {
    const selected = b.num === ballPickerPreviewNum;
    tx.beginPath();
    tx.arc(b.x, b.y, BR + 3 + pulse * 4 + (selected ? 2 : 0), 0, Math.PI * 2);
    tx.strokeStyle = selected ? 'rgba(86,184,255,0.95)' : `rgba(255,210,50,${0.5 + 0.5*pulse})`;
    tx.lineWidth = selected ? 3 : 2;
    tx.stroke();
  });
  // Label over table
  tx.fillStyle = 'rgba(255,210,50,0.88)';
  tx.font = 'bold 11px Space Mono,monospace';
  tx.textAlign = 'center';
  tx.textBaseline = 'top';
  const msg = ballPickerPreviewNum == null
    ? '▼ CLICK A BALL TO SELECT'
    : ('BALL #' + ballPickerPreviewNum + ' SELECTED — CONFIRM OR PICK AGAIN');
  tx.fillText(msg, TW/2, RAIL + 4);
}

function drawBall(b) {
  if (drawPoolBallHD) {
    drawPoolBallHD(tx, b, {
      activeEffects,
      baseRadius: BR,
      minVelocity: MIN_V,
      tableWidth: TW,
      mirrorPositionForBall: getMirroredBallRenderPoint,
    });
    return;
  }
  if (b.pocketed || activeEffects.cloaked === b.num) return;
  const shownNum = (activeEffects.confusion && activeEffects.confusionMap && b.num !== 0 && b.num !== 8)
    ? (activeEffects.confusionMap[b.num] || b.num)
    : b.num;
  const shownStripe = (activeEffects.confusion && activeEffects.confusionStripeMap && b.num !== 0 && b.num !== 8 && activeEffects.confusionStripeMap[b.num] !== undefined)
    ? activeEffects.confusionStripeMap[b.num]
    : b.stripe;
  const r = b.num === 0 ? (b._r || BR) : BR;
  let x = b.x;
  let y = b.y;
  if (activeEffects.mirror && b.num !== 0) {
    const mp = getMirroredBallRenderPoint(b, r + 0.6);
    x = mp.x;
    y = mp.y;
  }
  tx.beginPath(); tx.ellipse(x + 2, y + r * 0.82, r * 0.62, r * 0.17, 0, 0, Math.PI * 2);
  tx.fillStyle = 'rgba(0,0,0,.26)'; tx.fill();
  tx.beginPath(); tx.arc(x, y, r, 0, Math.PI * 2);
  tx.fillStyle = shownNum === 0 ? '#f0f0f0' : b.c;
  tx.fill();
  if (shownStripe && shownNum !== 0) {
    tx.save();
    tx.beginPath(); tx.arc(x, y, r, 0, Math.PI * 2); tx.clip();
    tx.fillStyle = '#f5f4ee';
    tx.fillRect(x - r, y - r, r * 2, r * 0.45);
    tx.fillRect(x - r, y + r * 0.55, r * 2, r * 0.45);
    tx.restore();
  }
  if (shownNum > 0) {
    tx.beginPath(); tx.arc(x, y, r * 0.44, 0, Math.PI * 2);
    tx.fillStyle = 'rgba(247,246,240,.92)'; tx.fill();
    tx.fillStyle = '#111';
    tx.font = 'bold ' + (shownNum > 9 ? 5.5 : 6.5) + 'px Space Mono,monospace';
    tx.textAlign = 'center'; tx.textBaseline = 'middle';
    tx.fillText(String(shownNum), x, y);
  }
  tx.beginPath(); tx.arc(x - r * 0.27, y - r * 0.29, r * 0.17, 0, Math.PI * 2);
  tx.fillStyle = 'rgba(255,255,255,.55)'; tx.fill();
  tx.beginPath(); tx.arc(x, y, r, 0, Math.PI * 2);
  tx.strokeStyle = 'rgba(255,255,255,.17)'; tx.lineWidth = 0.8; tx.stroke();
}

function drawCue() {
  if (!started || !cue || inMotion) return;

  // Ball-in-hand mode: draw placement ghost
  if (ballInHand) {
    const valid = isValidPlacement(cue.x, cue.y);
    tx.beginPath(); tx.arc(cue.x, cue.y, BR, 0, Math.PI * 2);
    tx.strokeStyle = valid ? 'rgba(80,220,100,0.85)' : 'rgba(220,60,60,0.85)';
    tx.lineWidth = 2.5;
    tx.setLineDash([4, 4]);
    tx.stroke();
    tx.setLineDash([]);
    // Pulsing fill
    tx.beginPath(); tx.arc(cue.x, cue.y, BR, 0, Math.PI * 2);
    tx.fillStyle = valid ? 'rgba(80,220,100,0.15)' : 'rgba(220,60,60,0.12)';
    tx.fill();
    // Label
    tx.fillStyle = valid ? 'rgba(80,220,100,0.9)' : 'rgba(220,60,60,0.9)';
    tx.font = 'bold 9px Space Mono,monospace';
    tx.textAlign = 'center';
    tx.fillText(valid ? 'CLICK TO PLACE' : 'INVALID', cue.x, cue.y - BR - 6);
    return;
  }

  if (!canShoot || cue.pocketed) return;
  if (!mouseOnTable && !charging) return;

  const ang = activeEffects.drunk ? aimAngle + drunkOffset : aimAngle;
  const cueBR2 = cue._r || BR;
  const pullback = 14 + (power / 100) * 55;
  const tipX = cue.x - Math.cos(ang) * (cueBR2 + pullback);
  const tipY = cue.y - Math.sin(ang) * (cueBR2 + pullback);
  const buttX = tipX - Math.cos(ang) * 190;
  const buttY = tipY - Math.sin(ang) * 190;
  const contactX = cue.x - Math.cos(ang) * cueBR2;
  const contactY = cue.y - Math.sin(ang) * cueBR2;

  // Aim guide line — suppressed by shortsighted; limited by fog of war; wobbled by drunk
  const displayAng = activeEffects.drunk ? aimAngle + drunkOffset : aimAngle;
  const cueBR = cue._r || BR;
  // Aim line and ghost ball — skip when fog (handled in drawFogOfWar) or shortsighted
  if (!activeEffects.shortsighted && !activeEffects.fogOfWar) {
    tx.save(); tx.globalAlpha = charging ? 0.06 : 0.1;
    tx.strokeStyle = '#fff'; tx.lineWidth = 1; tx.setLineDash([5, 8]);
    tx.beginPath();
    tx.moveTo(cue.x + Math.cos(displayAng) * cueBR, cue.y + Math.sin(displayAng) * cueBR);
    tx.lineTo(cue.x + Math.cos(displayAng) * 340, cue.y + Math.sin(displayAng) * 340);
    tx.stroke(); tx.setLineDash([]); tx.restore();
    // Ghost ball
    tx.beginPath(); tx.arc(
      cue.x + Math.cos(displayAng) * cueBR * 2.1,
      cue.y + Math.sin(displayAng) * cueBR * 2.1,
      BR, 0, Math.PI * 2
    );
    tx.strokeStyle = 'rgba(255,255,255,.17)'; tx.lineWidth = 1; tx.stroke();
  }

  // Cue stick
  const cg = tx.createLinearGradient(tipX, tipY, buttX, buttY);
  const chargeGlow = power > 60 ? Math.round((power - 60) / 40 * 120) : 0;
  cg.addColorStop(0, '#5ab5ff');
  cg.addColorStop(0.03, power > 60 ? `rgb(${220 + chargeGlow},${180 - chargeGlow},80)` : '#f0e0b0');
  cg.addColorStop(0.25, '#c8a060');
  cg.addColorStop(1, '#3a1808');
  tx.beginPath(); tx.moveTo(tipX, tipY); tx.lineTo(buttX, buttY);
  tx.strokeStyle = cg; tx.lineWidth = 5.5; tx.lineCap = 'round'; tx.stroke();
  tx.beginPath(); tx.arc(contactX, contactY, 3.5, 0, Math.PI * 2);
  tx.fillStyle = '#5ab5ff'; tx.fill();
}

// ── UI Helpers ────────────────────────────────────────────────
function updateHeader() {
  const el = document.getElementById('scores');
  el.innerHTML = '';
  if (gameVariant === 'cutthroat') refreshCutthroatScores();
  if (gameVariant === 'doubles') refreshDoublesScores();
  const lowestNine = gameVariant === 'nine' ? getLowestObjectBallOnTable() : null;
  players.forEach((p, i) => {
    const d = document.createElement('div');
    d.className = 'pcard' + (i === current ? ' active' : '');
    let badge = '';
    if (gameVariant === 'cutthroat' && p.group) {
      badge = '<span class="ptype ' + p.group + '-t">GROUP ' + getCutthroatGroupTag(p.group) + '</span>';
    } else if (gameVariant === 'doubles') {
      const t = (typeof p.team === 'number') ? p.team : getDoublesTeamForPlayer(i);
      const teamType = getDoublesTeamType(t);
      const teamText = t === 0 ? 'TEAM A' : 'TEAM B';
      const typeText = teamType ? (' · ' + teamType.toUpperCase()) : '';
      badge = '<span class="ptype ' + (t === 0 ? 'team-a-t' : 'team-b-t') + '">' + teamText + typeText + '</span>';
    } else if (gameVariant === 'nine') {
      badge = '<span class="ptype nine-t">LOW ' + (lowestNine == null ? '-' : lowestNine) + '</span>';
    } else if (p.type) {
      badge = '<span class="ptype ' + (p.type === 'solid' ? 'solid-t' : 'stripe-t') + '">' + p.type.toUpperCase() + '</span>';
    }
    let scoreValue = p.score;
    if (gameVariant === 'cutthroat') scoreValue = getCutthroatRemaining(p.group);
    if (gameVariant === 'doubles') {
      const t = (typeof p.team === 'number') ? p.team : getDoublesTeamForPlayer(i);
      scoreValue = getDoublesTeamScore(t);
    }
    const scoreLabel =
      gameVariant === 'cutthroat'
        ? 'LEFT'
        : (gameVariant === 'nine'
          ? 'POCKETED'
          : (gameVariant === 'doubles' ? 'TEAM SCORE' : 'SCORE'));
    const handCount = Array.isArray(p.hand) ? p.hand.length : 0;
    d.innerHTML =
      '<div class="pname">' + p.name + '</div>' +
      badge +
      '<div class="pscore">' + scoreValue + '</div>' +
      '<div class="phand">' + scoreLabel + ' · HAND ' + handCount + '/' + MAX_HAND_CARDS + '</div>';
    el.appendChild(d);
  });
}

function updateDots() {
  const el = document.getElementById('bdots');
  el.innerHTML = '';
  balls.filter(b => !b.pocketed).forEach(b => {
    const d = document.createElement('div');
    d.className = 'bdot';
    if (b.stripe) {
      d.style.background = 'linear-gradient(to bottom,#f5f4ee 28%,' + b.c + ' 28%,' + b.c + ' 72%,#f5f4ee 72%)';
    } else {
      d.style.background = b.c;
    }
    d.style.color = b.num === 8 ? '#fff' : '#000';
    d.textContent = b.num;
    el.appendChild(d);
  });
}

function setStatus(msg, foul) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status' + (foul ? ' foul' : '');
}

// ── Fog of War overlay ───────────────────────────────────────
function drawFogOfWar() {
  if (!cue || cue.pocketed) return;
  const displayAng = activeEffects.drunk ? aimAngle + drunkOffset : aimAngle;
  const cueBR = cue._r || BR;
  const corridorW = BR * 3.7;

  // Fully obfuscate table outside line of sight.
  tx.save();
  tx.fillStyle = 'rgba(0, 0, 0, 1)';
  tx.fillRect(0, 0, TW, TH);
  tx.restore();

  tx.save();

  tx.beginPath();
  tx.arc(cue.x, cue.y, cueBR + 8, 0, Math.PI * 2);
  const cosA = Math.cos(displayAng), sinA = Math.sin(displayAng);
  const perpX = -sinA, perpY = cosA;
  const startX = cue.x + cosA * (cueBR + 2);
  const startY = cue.y + sinA * (cueBR + 2);
  const endX   = cue.x + cosA * 380;
  const endY   = cue.y + sinA * 380;
  const hw = corridorW / 2;
  tx.moveTo(startX + perpX*hw, startY + perpY*hw);
  tx.lineTo(endX   + perpX*hw, endY   + perpY*hw);
  tx.lineTo(endX   - perpX*hw, endY   - perpY*hw);
  tx.lineTo(startX - perpX*hw, startY - perpY*hw);
  tx.closePath();
  tx.clip();

  const fg = tx.createRadialGradient(TW * 0.5, TH * 0.5, 20, TW * 0.5, TH * 0.5, TW * 0.65);
  fg.addColorStop(0, '#2aa259');
  fg.addColorStop(1, '#145f36');
  tx.fillStyle = fg;
  const poly = getWarpPolygonPoints();
  tx.beginPath();
  tx.moveTo(poly[0].x, poly[0].y);
  for (let i = 1; i < poly.length; i++) tx.lineTo(poly[i].x, poly[i].y);
  tx.closePath();
  tx.fill();
  drawTableEffects();
  [cue].concat(balls).forEach(drawBall);
  drawCueAimLine(displayAng, cueBR);

  tx.restore();
}

// Extracted aim-line + ghost ball draw — called both normally and inside fog corridor
function drawCueAimLine(displayAng, cueBR) {
  if (activeEffects.shortsighted) return;
  // Aim line
  let minDist = 340;
  balls.filter(b=>!b.pocketed).forEach(b=>{
    const dx=b.x-cue.x, dy=b.y-cue.y;
    const proj=dx*Math.cos(displayAng)+dy*Math.sin(displayAng);
    const perp=Math.abs(-dx*Math.sin(displayAng)+dy*Math.cos(displayAng));
    if(proj>0&&perp<BR*2&&proj<minDist) minDist=proj;
  });
  tx.save();
  tx.globalAlpha = charging ? 0.06 : 0.1;
  tx.strokeStyle = '#fff'; tx.lineWidth = 1; tx.setLineDash([5, 8]);
  tx.beginPath();
  tx.moveTo(cue.x + Math.cos(displayAng)*cueBR, cue.y + Math.sin(displayAng)*cueBR);
  tx.lineTo(cue.x + Math.cos(displayAng)*(minDist+BR), cue.y + Math.sin(displayAng)*(minDist+BR));
  tx.stroke(); tx.setLineDash([]); tx.restore();
  // Ghost ball
  tx.beginPath(); tx.arc(
    cue.x + Math.cos(displayAng)*cueBR*2.1,
    cue.y + Math.sin(displayAng)*cueBR*2.1,
    BR, 0, Math.PI*2
  );
  tx.strokeStyle='rgba(255,255,255,.17)'; tx.lineWidth=1; tx.stroke();
}

// ── Loop ──────────────────────────────────────────────────────
function loop() {
  physicsStep();
  drawTable();
  if (started && cue) {
    drawTableEffects();
    if (tablePlacerActive) drawTablePlacerPreview();
    drawCue();
    [cue].concat(balls).forEach(drawBall);
    if (activeEffects.fogOfWar) drawFogOfWar();
    if (ballPickerStep) drawBallPickerHighlights();
    if (pocketPickerStep) drawPocketPickerHighlights();
    if (railPickerStep) drawRailPickerHighlights();
    if (warpPocketResizeStep) drawWarpPocketResizeGuide();
  }
  redrawSpin();
  requestAnimationFrame(loop);
}


// ── CARD SYSTEM (CARD_POOL defined after applier functions below) ──

const MAX_HAND_CARDS = 7;
const AUTO_DRAW_CARDS_PER_TURN = 3;
const PLAY_CARDS_PER_TURN = 2;
// (pendingBallInHand declared at top)

// Interaction-phase queue: cards that need player interaction after confirm
// Each entry: { type: 'ball_pick'|'table_place'|'pocket_pick'|'rail_pick'|'portal_place', effectKey, ... }
// (interactionQueue declared at top)

function pickRandomCards(n) {
  const available = getAvailableCardsForDraft();
  const allBall  = [...available.filter(c=>c.type==='ball')].sort(()=>Math.random()-.5);
  const allTable = [...available.filter(c=>c.type==='table')].sort(()=>Math.random()-.5);
  const pick = [];
  if (allBall.length)  pick.push(allBall.shift());   // 1 guaranteed ball
  if (allTable.length) pick.push(allTable.shift());  // 1 guaranteed table
  // Fill remaining slots randomly from whatever's left
  const rest = [...allBall, ...allTable].sort(()=>Math.random()-.5);
  rest.forEach(c => { if (pick.length < n) pick.push(c); });
  // Shuffle final hand so guaranteed picks aren't always in same position
  return pick.sort(()=>Math.random()-.5);
}

const RAIL_EFFECT_CARD_IDS = new Set(['bounce_house', 'dead_rail', 'warp_rail']);

function isRailEffectCard(card) {
  return !!(card && RAIL_EFFECT_CARD_IDS.has(card.id));
}

function pickGuaranteedTurnCards(n) {
  const available = getAvailableCardsForDraft();
  if (!n || n <= 0 || !available.length) return [];
  const picked = [];
  const pickedIds = new Set();
  const pickOne = (predicate) => {
    const options = available.filter(c => !pickedIds.has(c.id) && (!predicate || predicate(c)));
    if (!options.length) return null;
    const card = options[Math.floor(Math.random() * options.length)];
    picked.push(card);
    pickedIds.add(card.id);
    return card;
  };

  if (n >= 2) {
    pickOne(c => c.type === 'ball');      // guarantee one ball effect
    pickOne(c => isRailEffectCard(c));    // guarantee one rail effect
  } else if (n === 1) {
    pickOne(c => c.type === 'ball') || pickOne(c => isRailEffectCard(c));
  }
  while (picked.length < n) {
    if (!pickOne()) break;
  }
  return picked.slice(0, n);
}

function autoDrawCardsToHand(playerIdx) {
  const p = players[playerIdx];
  if (!p) return [];
  if (!p.hand) p.hand = [];
  const openSlots = Math.max(0, MAX_HAND_CARDS - p.hand.length);
  const drawCount = Math.min(AUTO_DRAW_CARDS_PER_TURN, openSlots);
  if (drawCount <= 0) return [];
  const drawn = pickGuaranteedTurnCards(drawCount);
  p.hand.push(...drawn);
  return drawn;
}

function clearCardDrawAnimation() {
  if (phaseDrawAnimTimer) {
    clearTimeout(phaseDrawAnimTimer);
    phaseDrawAnimTimer = null;
  }
  phaseDrawAnimDone = true;
  const bar = document.getElementById('cardAutoDrawAnim');
  if (bar) {
    bar.classList.remove('show');
    bar.innerHTML = '';
  }
}

function renderCardDrawAnimation() {
  const bar = document.getElementById('cardAutoDrawAnim');
  if (!bar) return;
  if (phaseDrawAnimDone || !phaseAutoDrawnCards.length) {
    bar.classList.remove('show');
    bar.innerHTML = '';
    return;
  }
  if (phaseDrawAnimTimer) return;
  bar.innerHTML = phaseAutoDrawnCards.map((card, i) =>
    `<div class="draw-fly-card draw-${card.type}" style="animation-delay:${i * 120}ms">
      <span class="draw-fly-icon">${card.icon}</span>
      <span class="draw-fly-name">${card.name}</span>
    </div>`
  ).join('');
  bar.classList.add('show');
  phaseDrawAnimTimer = setTimeout(() => {
    phaseDrawAnimTimer = null;
    phaseDrawAnimDone = true;
    bar.classList.remove('show');
    bar.innerHTML = '';
  }, 1500);
}

function getAvailableCardsForDraft() {
  // open_pocket only available when at least one pocket is actually blocked
  return CARD_POOL.filter(c =>
    c.id !== 'open_pocket' || activeEffects.blockedPockets.length > 0
  );
}

function shouldUseDebugCardDraw(playerIdx) {
  if (!debugCardPickEnabled) return false;
  if (isOnlineActive()) return playerIdx === onlineSession.playerIndex;
  return playerIdx === 0;
}

function toggleGlossary() {
  const body = document.getElementById('cardGlossaryBody');
  const chev = document.getElementById('glossaryChevron');
  const open = body.classList.toggle('open');
  chev.textContent = open ? '^' : 'v';
  if (open && !body.innerHTML.trim()) buildGlossary();
}

function buildGlossary() {
  const body = document.getElementById('cardGlossaryBody');
  const available = getAvailableCardsForDraft();
  const balls2  = available.filter(c => c.type === 'ball');
  const tables2 = available.filter(c => c.type === 'table');
  const section = (title, cards, badgeClass) => {
    const rows = cards.map(c =>
      `<div class="glossary-row">
        <span class="glossary-icon">${c.icon}</span>
        <span class="glossary-name">${c.name}</span>
        <span class="glossary-desc">${c.desc}</span>
      </div>`
    ).join('');
    return `<div class="glossary-section">
      <div class="glossary-section-title ${badgeClass}">${title}</div>
      ${rows}
    </div>`;
  };
  body.innerHTML =
    section('BALL EFFECTS — Last 1 turn for opponent', balls2, 'badge-ball') +
    section('TABLE EFFECTS — Permanent', tables2, 'badge-table');
}

function showCardPhase(playerIdx) {
  if (isOnlineActive() && playerIdx !== onlineSession.playerIndex) {
    return;
  }
  cardPhaseForPlayer = playerIdx;
  if (!players[playerIdx].hand) players[playerIdx].hand = [];
  cardPhaseActive = true;
  cardPhaseMode = 'play';
  phaseOfferSelected = new Set();
  phaseHandSelected = new Set();
  phaseOfferCards = [];
  interactionQueue = [];
  phaseDrawAnimDone = false;
  if (phaseDrawAnimTimer) {
    clearTimeout(phaseDrawAnimTimer);
    phaseDrawAnimTimer = null;
  }
  phaseAutoDrawnCards = autoDrawCardsToHand(playerIdx);

  updateHeader();
  renderCardPlayStep();
  document.getElementById('cardOverlay').classList.add('show');
  document.getElementById('cardConfirmBtn').style.display = '';
  // Reset glossary so it rebuilds with current availability
  const gb = document.getElementById('cardGlossaryBody');
  if (gb) { gb.innerHTML = ''; gb.classList.remove('open'); }
  const gc = document.getElementById('glossaryChevron');
  if (gc) gc.textContent = 'v';
}

function renderCardDrawStep() {
  const p = players[cardPhaseForPlayer];
  const openSlots = Math.max(0, MAX_HAND_CARDS - ((p.hand && p.hand.length) || 0));
  const mustPick = Math.min(AUTO_DRAW_CARDS_PER_TURN, openSlots);
  if (mustPick <= 0) {
    phaseOfferCards = [];
    phaseOfferSelected = new Set();
    phaseHandSelected = new Set();
    renderCardPlayStep();
    return;
  }

  cardPhaseMode = 'draw';
  const debugDraw = shouldUseDebugCardDraw(cardPhaseForPlayer);
  if (!phaseOfferCards.length) {
    phaseOfferCards = debugDraw ? getAvailableCardsForDraft() : pickRandomCards(4);
  }
  document.getElementById('cardPhaseTitle').textContent = p.name.toUpperCase() + ' — DRAW TO HAND';
  document.getElementById('cardPhaseSub').textContent = debugDraw
    ? 'DEBUG MODE — pick from full card list · choose up to ' + mustPick + ' card' + (mustPick === 1 ? '' : 's')
    : ('Pick up to ' + mustPick + ' card' + (mustPick === 1 ? '' : 's') + ' to add to your hand (max ' + MAX_HAND_CARDS + ')');

  const area = document.getElementById('cardDraftArea');
  area.innerHTML = '';
  area.classList.toggle('debug-scroll', debugDraw);
  area.style.cssText = '';
  phaseOfferCards.forEach((card, i) => {
    const el = document.createElement('div');
    el.className = 'card card--' + card.type + (phaseOfferSelected.has(i) ? ' selected' : '');
    el.innerHTML = `
      <div class="card-type-badge badge-${card.type}">${card.type}</div>
      <div class="card-icon">${card.icon}</div>
      <div class="card-name">${card.name}</div>
      <div class="card-desc">${card.desc}</div>
      <div class="card-footer">${card.type === 'ball' ? '1 TURN' : 'PERMANENT'}</div>`;
    el.addEventListener('click', () => {
      if (phaseOfferSelected.has(i)) {
        phaseOfferSelected.delete(i);
      } else if (phaseOfferSelected.size < mustPick) {
        phaseOfferSelected.add(i);
      }
      renderCardDrawStep();
    });
    if (phaseOfferSelected.has(i)) el.classList.add('selected');
    area.appendChild(el);
  });

  const btn = document.getElementById('cardConfirmBtn');
  btn.textContent = phaseOfferSelected.size
    ? ('ADD ' + phaseOfferSelected.size + ' TO HAND')
    : 'SKIP DRAW';
  btn.disabled = false;
  document.getElementById('cardSelectHint').textContent =
    (debugDraw ? 'DEBUG PICK · ' : '') +
    'Select up to ' + mustPick + ' card' + (mustPick === 1 ? '' : 's') + ' · hand ' + p.hand.length + '/' + MAX_HAND_CARDS;
}

function renderCardPlayStep() {
  cardPhaseMode = 'play';
  const p = players[cardPhaseForPlayer];
  const target = players[getNextPlayerIndex(cardPhaseForPlayer)];
  document.getElementById('cardPhaseTitle').textContent = p.name.toUpperCase() + ' — PLAY FROM HAND';
  const drew = phaseAutoDrawnCards.length;
  const drawMsg = drew
    ? ('Auto-drew ' + drew + ' card' + (drew === 1 ? '' : 's') + ' (ball + rail guaranteed when space allows).')
    : 'Hand is full, so no new cards were drawn.';
  document.getElementById('cardPhaseSub').textContent =
    drawMsg + ' Play up to ' + PLAY_CARDS_PER_TURN + ' card(s) against ' + target.name + ' or end turn';
  renderCardDrawAnimation();

  const area = document.getElementById('cardDraftArea');
  area.innerHTML = '';
  area.classList.remove('debug-scroll');
  area.style.cssText = '';
  const hand = p.hand || [];
  if (!hand.length) {
    area.innerHTML = '<div class="card-empty">No cards in hand. End turn to continue.</div>';
  }
  hand.forEach((card, i) => {
    const el = document.createElement('div');
    el.className = 'card card--' + card.type + (phaseHandSelected.has(i) ? ' selected' : '');
    el.innerHTML = `
      <div class="card-type-badge badge-${card.type}">${card.type}</div>
      <div class="card-icon">${card.icon}</div>
      <div class="card-name">${card.name}</div>
      <div class="card-desc">${card.desc}</div>
      <div class="card-footer">${card.type === 'ball' ? '1 TURN' : 'PERMANENT'}</div>`;
    el.addEventListener('click', () => {
      if (phaseHandSelected.has(i)) {
        phaseHandSelected.delete(i);
      } else if (phaseHandSelected.size < PLAY_CARDS_PER_TURN) {
        phaseHandSelected.add(i);
      }
      renderCardPlayStep();
    });
    if (phaseHandSelected.has(i)) el.classList.add('selected');
    area.appendChild(el);
  });

  const btn = document.getElementById('cardConfirmBtn');
  btn.disabled = false;
  btn.textContent = phaseHandSelected.size ? ('PLAY ' + phaseHandSelected.size + ' CARD' + (phaseHandSelected.size === 1 ? '' : 'S')) : 'END TURN';
  document.getElementById('cardSelectHint').textContent =
    'Selected ' + phaseHandSelected.size + '/' + PLAY_CARDS_PER_TURN + ' · hand ' + hand.length + '/' + MAX_HAND_CARDS;
}

document.getElementById('cardConfirmBtn').addEventListener('click', () => {
  if (onlineInputLocked()) return;
  audioCall('unlockFromGesture');
  if (cardPhaseForPlayer < 0 || !players[cardPhaseForPlayer]) return;
  const p = players[cardPhaseForPlayer];
  if (cardPhaseMode === 'draw') {
    const openSlots = Math.max(0, MAX_HAND_CARDS - ((p.hand && p.hand.length) || 0));
    const mustPick = Math.min(AUTO_DRAW_CARDS_PER_TURN, openSlots);
    if (phaseOfferSelected.size > mustPick) return;
    const picked = [...phaseOfferSelected].map(i => phaseOfferCards[i]).filter(Boolean);
    p.hand = p.hand || [];
    p.hand.push(...picked.slice(0, mustPick));
    updateHeader();
    phaseOfferCards = [];
    phaseOfferSelected = new Set();
    phaseHandSelected = new Set();
    renderCardPlayStep();
    return;
  }

  document.getElementById('cardOverlay').classList.remove('show');
  clearCardDrawAnimation();
  cardPhaseActive = false;
  interactionQueue = [];
  p.hand = p.hand || [];
  const playIdx = [...phaseHandSelected].sort((a, b) => b - a);
  const toPlay = playIdx.map(i => p.hand[i]).filter(Boolean);
  playIdx.forEach(i => p.hand.splice(i, 1));
  updateHeader();
  toPlay.forEach(card => {
    try {
      if (card && card.id) audioCall('cardPlayed', card.id);
      if (card && typeof card.fn === 'function') card.fn();
    } catch (err) {
      console.error('Card execution failed:', card && card.id, err);
      setStatus('Card failed: ' + ((card && card.name) || 'Unknown'), true);
    }
  });

  processInteractionQueue();
});

const glossaryToggle = document.getElementById('cardGlossaryToggle');
if (glossaryToggle) glossaryToggle.addEventListener('click', toggleGlossary);

// ── Interaction queue runner ──────────────────────────────────
function processInteractionQueue() {
  if (!interactionQueue.length) { finishCardPhase(); return; }
  const step = interactionQueue.shift();

  if (step.type === 'ball_pick')    showBallPicker(step);
  if (step.type === 'pocket_pick')  showPocketPicker(step);
  if (step.type === 'rail_pick')    showRailPicker(step);
  if (step.type === 'table_place')  showTablePlacer(step);
  if (step.type === 'portal_place') showPortalPlacer(step);
  if (step.type === 'move_hole')    showMoveHolePicker(step);
}

function finishCardPhase() {
  updateEffectsPanel();
  updateHeader();
  // Apply size effect to cue ball immediately so it's visible
  if (cue) cue._r = activeEffects.bigBall ? BR*2 : activeEffects.smallBall ? BR*0.5 : BR;
  if (pendingBallInHand) {
    pendingBallInHand = false;
    updateHeader();
    enterBallInHand();
    return;
  }
  canShoot = true;
  setStatus(players[current].name + "'s Turn");
  queueOnlineSync('turn_ready');
}

// ── Shared overlay helper ─────────────────────────────────────
function openPickerOverlay(title, sub) {
  const ov = document.getElementById('cardOverlay');
  document.getElementById('cardPhaseTitle').textContent  = title;
  document.getElementById('cardPhaseSub').textContent    = sub;
  document.getElementById('cardDraftArea').innerHTML     = '';
  document.getElementById('cardDraftArea').style.cssText = 'flex-wrap:wrap;max-width:560px;justify-content:center;gap:12px;';
  document.getElementById('cardSelectHint').textContent  = '';
  document.getElementById('cardConfirmBtn').style.display = 'none';
  ov.classList.add('show');
}

// ── Ball picker (heavyweight, lightweight, confusion, cloak) ──
// (ballPickerStep declared at top)

function showBallPicker(step) {
  ballPickerStep = step;
  // Dim the card overlay completely, use the table directly
  document.getElementById('cardOverlay').classList.remove('show');

  const labels = {
    heavyweight: ['PICK BALL: HEAVYWEIGHT', 'Click a ball on the table — it becomes nearly immovable'],
    lightweight: ['PICK BALL: LIGHTWEIGHT', 'Click a ball on the table — it flies away on any contact'],
    confusion:   ['PICK BALL: CONFUSION',   'Click a ball — it is disguised and flips stripe/solid this turn'],
    cloaked:     ['PICK BALL: CLOAK',       'Click a ball on the table — it disappears from opponent view'],
  };
  const [title, sub] = labels[step.effectKey] || ['CLICK A BALL ON THE TABLE', ''];
  setStatus('🎯 ' + title + ' — ' + sub, true);
  // Show a full-screen semi-transparent label over the table canvas
  showBallPickerHint(title, sub);
}

function showBallPickerHint(title, sub) {
  let hint = document.getElementById('ballPickerHint');
  if (!hint) {
    hint = document.createElement('div');
    hint.id = 'ballPickerHint';
    hint.style.cssText = `position:absolute;top:0;left:0;right:0;pointer-events:none;
      text-align:center;padding:8px 0;z-index:50;
      background:linear-gradient(rgba(0,0,0,0.7),transparent);`;
    const tableWrap = document.querySelector('#tableCanvas').parentElement;
    tableWrap.style.position = 'relative';
    tableWrap.appendChild(hint);
  }
  hint.innerHTML = `<div style="font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:4px;color:var(--gold)">${title}</div>
    <div style="font-size:9px;opacity:.6;letter-spacing:2px">${sub}</div>`;
  hint.style.display = '';
}

function hideBallPickerHint() {
  const hint = document.getElementById('ballPickerHint');
  if (hint) hint.style.display = 'none';
  ballPickerStep = null;
  ballPickerPreviewNum = null;
}

function handleBallPickerClick(tableX, tableY) {
  if (!ballPickerStep) return false;
  const step = ballPickerStep;
  const liveBalls = balls.filter(b => !b.pocketed && b.num !== 0 && b.num !== 8);
  // Find ball under click
  let picked = null;
  let bestDist = Infinity;
  liveBalls.forEach(b => {
    const d = Math.hypot(b.x - tableX, b.y - tableY);
    if (d < BR + 10 && d < bestDist) {
      bestDist = d;
      picked = b;
    }
  });
  if (!picked) return true; // consumed but no hit — wait for valid click
  ballPickerPreviewNum = picked.num;
  const applyPick = () => {
    if      (step.effectKey==='confusion') { const cm=buildConfusionFor(picked.num); activeEffects.confusionMap=cm.numMap; activeEffects.confusionStripeMap=cm.stripeMap; activeEffects.confusion=true; }
    else if (step.effectKey==='cloaked')   { activeEffects.cloaked = picked.num; }
    else                                   { activeEffects[step.effectKey] = picked.num; }
    hideBallPickerHint();
    processInteractionQueue();
  };
  requestSelectionConfirm({
    title: 'CONFIRM BALL',
    message: 'Use ball #' + picked.num + ' for this card?',
    onConfirm: applyPick,
    onCancel: () => { ballPickerPreviewNum = null; }
  });
  return true;
}

function buildConfusionFor(targetNum) {
  const numMap = {}, stripeMap = {};
  const targetBall = balls.find(b => b.num === targetNum);
  if (!targetBall) return { numMap, stripeMap };

  const opposite = balls.filter(b =>
    !b.pocketed && b.num !== 0 && b.num !== 8 && b.num !== targetNum && b.stripe !== targetBall.stripe
  );
  const others = balls.filter(b =>
    !b.pocketed && b.num !== 0 && b.num !== 8 && b.num !== targetNum
  );
  const pool = opposite.length ? opposite : others;
  if (pool.length) {
    const fake = pool[Math.floor(Math.random() * pool.length)];
    numMap[targetNum] = fake.num;
  }
  // Always force stripe <-> solid appearance swap for the target ball.
  stripeMap[targetNum] = !targetBall.stripe;
  return { numMap, stripeMap };
}

// ── Pocket picker ─────────────────────────────────────────────
function showPocketPicker(step) {
  pocketPickerStep = step;
  pocketPickerHover = null;
  document.getElementById('cardOverlay').classList.remove('show');
  const title = step.title || 'PICK A POCKET';
  const sub = step.sub || 'Click a pocket directly on the table';
  setStatus('🎯 ' + title + ' — ' + sub, true);
  let hint = document.getElementById('pocketPickerHint');
  if (!hint) {
    hint = document.createElement('div');
    hint.id = 'pocketPickerHint';
    hint.style.cssText = 'position:absolute;top:0;left:0;right:0;pointer-events:none;' +
      'text-align:center;padding:8px 0;z-index:50;background:linear-gradient(rgba(0,0,0,0.7),transparent);';
    const wrap = document.querySelector('#tableCanvas').parentElement;
    if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(hint); }
  }
  hint.innerHTML = '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:4px;color:var(--gold)">' + title + '</div>' +
    '<div style="font-size:9px;opacity:.6;letter-spacing:2px">' + sub + '</div>';
  hint.style.display = '';
}

function hidePocketPickerHint() {
  const hint = document.getElementById('pocketPickerHint');
  if (hint) hint.style.display = 'none';
  pocketPickerStep = null;
  pocketPickerHover = null;
}

function getPocketFromTablePos(x, y) {
  let bestIdx = -1;
  let bestDist = Infinity;
  for (let i = 0; i < POCKETS.length; i++) {
    const p = getPocketPos(i);
    const d = Math.hypot(x - p.x, y - p.y);
    if (d < bestDist) {
      bestDist = d;
      bestIdx = i;
    }
  }
  return bestDist <= (POCKET_R + BR * 1.1) ? bestIdx : -1;
}

function handlePocketPickerMove(x, y) {
  if (!pocketPickerStep) return;
  pocketPickerHover = getPocketFromTablePos(x, y);
}

function handlePocketPickerClick(x, y) {
  if (!pocketPickerStep) return false;
  const idx = getPocketFromTablePos(x, y);
  if (idx < 0) return true;
  const step = pocketPickerStep;
  if (typeof step.allowPick === 'function' && !step.allowPick(idx)) return true;
  const result = step.onPick(idx);
  hidePocketPickerHint();
  if (result !== false) processInteractionQueue();
  return true;
}

function drawPocketPickerHighlights() {
  if (!pocketPickerStep) return;
  const t = Date.now() / 420;
  const pulse = 0.5 + 0.5 * Math.sin(t * Math.PI * 2);
  for (let i = 0; i < POCKETS.length; i++) {
    const p = getPocketPos(i);
    const blocked = activeEffects.blockedPockets.includes(i);
    const allowed = typeof pocketPickerStep.allowPick === 'function' ? pocketPickerStep.allowPick(i) : true;
    const hover = i === pocketPickerHover;
    tx.beginPath();
    tx.arc(p.x, p.y, POCKET_R + 8 + pulse * 3 + (hover ? 2 : 0), 0, Math.PI * 2);
    tx.strokeStyle = !allowed
      ? 'rgba(110,110,110,0.45)'
      : (hover ? 'rgba(255,255,255,0.95)' : (blocked ? 'rgba(231,76,60,0.9)' : 'rgba(201,168,76,0.85)'));
    tx.lineWidth = hover ? 3 : 2;
    tx.stroke();
  }
  tx.save();
  tx.fillStyle = 'rgba(201,168,76,0.92)';
  tx.font = 'bold 11px Space Mono,monospace';
  tx.textAlign = 'center';
  tx.textBaseline = 'top';
  tx.fillText('▼ CLICK A POCKET ON TABLE', TW / 2, RAIL + 4);
  tx.restore();
}

// ── Rail picker — live table click ────────────────────────────
function showRailPicker(step) {
  railPickerStep  = step;
  railPickerHover = null;
  document.getElementById('cardOverlay').classList.remove('show');
  const cardName = step.cardName || 'RAIL EFFECT';
  setStatus('🎯 ' + cardName + ' — Click a rail on the table to apply', true);
  // Show hint banner above table canvas
  let hint = document.getElementById('railPickerHint');
  if (!hint) {
    hint = document.createElement('div');
    hint.id = 'railPickerHint';
    hint.style.cssText = 'position:absolute;top:0;left:0;right:0;pointer-events:none;' +
      'text-align:center;padding:8px 0;z-index:50;' +
      'background:linear-gradient(rgba(0,0,0,0.7),transparent);';
    const wrap = document.querySelector('#tableCanvas').parentElement;
    if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(hint); }
  }
  hint.innerHTML = '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:20px;letter-spacing:4px;color:var(--gold)">' + cardName + '</div>' +
    '<div style="font-size:9px;opacity:.6;letter-spacing:2px">CLICK A RAIL ON THE TABLE TO SELECT</div>';
  hint.style.display = '';
}

function hideRailPickerHint() {
  const hint = document.getElementById('railPickerHint');
  if (hint) hint.style.display = 'none';
  railPickerStep  = null;
  railPickerHover = null;
}

function getNearestWarpEdge(x, y) {
  const edges = getWarpEdges();
  let best = null;
  edges.forEach(edge => {
    const ex = edge.b.x - edge.a.x;
    const ey = edge.b.y - edge.a.y;
    const lenSq = ex * ex + ey * ey || 1;
    const tRaw = ((x - edge.a.x) * ex + (y - edge.a.y) * ey) / lenSq;
    const t = Math.max(0, Math.min(1, tRaw));
    const cx = edge.a.x + ex * t;
    const cy = edge.a.y + ey * t;
    const d = Math.hypot(x - cx, y - cy);
    if (!best || d < best.dist) best = { wall: edge.wall, dist: d, x: cx, y: cy };
  });
  return best;
}

function getRailFromTablePos(x, y) {
  const band = Math.max(10, RAIL * 0.9);
  const best = getNearestWarpEdge(x, y);
  return best && best.dist <= band ? best.wall : null;
}

function handleRailPickerClick(tableX, tableY) {
  if (!railPickerStep) return false;
  const rail = getRailFromTablePos(tableX, tableY);
  if (!rail) return true; // consumed but no valid rail
  const result = railPickerStep.onPick(rail);
  hideRailPickerHint();
  if (result !== false) processInteractionQueue();
  return true;
}

function handleRailPickerMove(tableX, tableY) {
  if (!railPickerStep) return;
  railPickerHover = getRailFromTablePos(tableX, tableY);
}

function drawRailPickerHighlights() {
  const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 300 * Math.PI);
  const edges = getWarpEdges();
  ['top','bottom','left','right'].forEach(r => {
    const group = edges.filter(e => e.wall === r);
    if (!group.length) return;
    const isHover = r === railPickerHover;
    tx.save();
    tx.globalAlpha = isHover ? 0.92 : 0.45 + pulse * 0.2;
    tx.strokeStyle = isHover ? '#fff' : '#c9a84c';
    tx.lineWidth = isHover ? 13 : 10;
    tx.lineCap = 'round';
    group.forEach(edge => {
      tx.beginPath();
      tx.moveTo(edge.a.x, edge.a.y);
      tx.lineTo(edge.b.x, edge.b.y);
      tx.stroke();
    });
    tx.globalAlpha = isHover ? 1 : 0.8;
    tx.fillStyle = isHover ? '#000' : 'rgba(255,255,255,0.9)';
    tx.font = `bold ${isHover ? 10 : 8}px Space Mono,monospace`;
    tx.textAlign = 'center'; tx.textBaseline = 'middle';
    const first = group[0];
    const last = group[group.length - 1];
    tx.fillText(r.toUpperCase(), (first.a.x + last.b.x) / 2, (first.a.y + last.b.y) / 2);
    tx.restore();
  });
  tx.save();
  tx.fillStyle = 'rgba(201,168,76,0.85)';
  tx.font = 'bold 11px Space Mono,monospace';
  tx.textAlign = 'center'; tx.textBaseline = 'top';
  tx.fillText('▼ CLICK A RAIL TO SELECT', TW/2, RAIL + 4);
  tx.restore();
}

function clampWarpCorner(name, x, y, c) {
  const minW = 260;
  const minH = 125;
  const pad = 18;
  const minX = RAIL - pad;
  const maxX = TW - RAIL + pad;
  const minY = RAIL - pad;
  const maxY = TH - RAIL + pad;

  let nx = Math.max(minX, Math.min(maxX, x));
  let ny = Math.max(minY, Math.min(maxY, y));

  if (name === 'tl') {
    nx = Math.min(nx, c.tr.x - minW);
    ny = Math.min(ny, c.bl.y - minH);
  } else if (name === 'tr') {
    nx = Math.max(nx, c.tl.x + minW);
    ny = Math.min(ny, c.br.y - minH);
  } else if (name === 'bl') {
    nx = Math.min(nx, c.br.x - minW);
    ny = Math.max(ny, c.tl.y + minH);
  } else if (name === 'br') {
    nx = Math.max(nx, c.bl.x + minW);
    ny = Math.max(ny, c.tr.y + minH);
  }
  return { x: nx, y: ny };
}

function clampNum(v, min, max) {
  if (min > max) {
    const mid = (min + max) / 2;
    min = mid;
    max = mid;
  }
  return Math.max(min, Math.min(max, v));
}

function clampWarpMid(which, x, y, c, m) {
  const edgeInset = 42;
  const outward = 74;
  const minGap = 120;
  const yTopLimit = Math.min(c.tl.y, c.tr.y) - outward;
  const yBottomLimit = Math.max(c.bl.y, c.br.y) + outward;

  let ny;
  if (which === 'top') {
    const maxTop = Math.min(c.bl.y, c.br.y, m.bottom.y) - minGap;
    ny = clampNum(y, yTopLimit, maxTop);
  } else {
    const minBottom = Math.max(c.tl.y, c.tr.y, m.top.y) + minGap;
    ny = clampNum(y, minBottom, yBottomLimit);
  }

  const lx = (Math.abs(c.bl.y - c.tl.y) < 1e-6)
    ? c.tl.x
    : c.tl.x + (ny - c.tl.y) * (c.bl.x - c.tl.x) / (c.bl.y - c.tl.y);
  const rx = (Math.abs(c.br.y - c.tr.y) < 1e-6)
    ? c.tr.x
    : c.tr.x + (ny - c.tr.y) * (c.br.x - c.tr.x) / (c.br.y - c.tr.y);
  const minX = Math.min(lx, rx) + edgeInset;
  const maxX = Math.max(lx, rx) - edgeInset;

  return {
    x: clampNum(x, minX, maxX),
    y: ny,
  };
}

function normalizeWarpGeometry(corners, mids) {
  const c = {
    tl: { x: corners.tl.x, y: corners.tl.y },
    tr: { x: corners.tr.x, y: corners.tr.y },
    br: { x: corners.br.x, y: corners.br.y },
    bl: { x: corners.bl.x, y: corners.bl.y },
  };
  const m = {
    top: { x: mids.top.x, y: mids.top.y },
    bottom: { x: mids.bottom.x, y: mids.bottom.y },
  };
  c.tl = clampWarpCorner('tl', c.tl.x, c.tl.y, c);
  c.tr = clampWarpCorner('tr', c.tr.x, c.tr.y, c);
  c.bl = clampWarpCorner('bl', c.bl.x, c.bl.y, c);
  c.br = clampWarpCorner('br', c.br.x, c.br.y, c);
  m.top = clampWarpMid('top', m.top.x, m.top.y, c, m);
  m.bottom = clampWarpMid('bottom', m.bottom.x, m.bottom.y, c, m);
  return { corners: c, mids: m };
}

function beginWarpPocketResize(pocketIdx) {
  warpPocketResizeStep = { pocketIdx, preview: null };
  const labels = ['TOP-LEFT', 'TOP-MID', 'TOP-RIGHT', 'BOT-LEFT', 'BOT-MID', 'BOT-RIGHT'];
  setStatus(
    'WARP RAIL — click to preview ' + (labels[pocketIdx] || ('POCKET ' + (pocketIdx + 1))) + ' inward/outward move',
    true
  );
}

function getWarpPreviewFromPocketMove(idx, x, y) {
  const c = getWarpCorners();
  const m = getWarpMids();

  if (idx === 0) {
    c.tl = clampWarpCorner('tl', x, y, c);
  } else if (idx === 1) {
    m.top = clampWarpMid('top', x, y, c, m);
  } else if (idx === 2) {
    c.tr = clampWarpCorner('tr', x, y, c);
  } else if (idx === 3) {
    c.bl = clampWarpCorner('bl', x, y, c);
  } else if (idx === 4) {
    m.bottom = clampWarpMid('bottom', x, y, c, m);
  } else if (idx === 5) {
    c.br = clampWarpCorner('br', x, y, c);
  }
  return normalizeWarpGeometry(c, m);
}

function handleWarpPocketResizeClick(x, y) {
  if (!warpPocketResizeStep) return false;
  const idx = warpPocketResizeStep.pocketIdx;
  const normalized = getWarpPreviewFromPocketMove(idx, x, y);
  warpPocketResizeStep.preview = normalized;

  requestSelectionConfirm({
    title: 'CONFIRM WARP RAIL',
    message: 'Apply this warped table shape?',
    onConfirm: () => {
      activeEffects.warpCorners = normalized.corners;
      activeEffects.warpMids = normalized.mids;
      shiftAllBallsInsideWarp();
      normalizePortalsToWarp();
      if (activeEffects.movedPockets && activeEffects.movedPockets[idx]) {
        delete activeEffects.movedPockets[idx];
      }
      warpPocketResizeStep = null;
      updateEffectsPanel();
      processInteractionQueue();
    },
    onCancel: () => {
      if (warpPocketResizeStep) warpPocketResizeStep.preview = null;
    }
  });
  return true;
}

function drawWarpPocketResizeGuide() {
  if (!warpPocketResizeStep) return;
  const idx = warpPocketResizeStep.pocketIdx;
  const p = getPocketPos(idx);
  const preview = warpPocketResizeStep.preview;
  if (preview) {
    const prePoly = [
      preview.corners.tl,
      preview.mids.top,
      preview.corners.tr,
      preview.corners.br,
      preview.mids.bottom,
      preview.corners.bl,
    ];
    tx.save();
    tx.beginPath();
    tx.moveTo(prePoly[0].x, prePoly[0].y);
    for (let i = 1; i < prePoly.length; i++) tx.lineTo(prePoly[i].x, prePoly[i].y);
    tx.closePath();
    tx.strokeStyle = 'rgba(86,184,255,0.95)';
    tx.lineWidth = 2.5;
    tx.setLineDash([8, 5]);
    tx.stroke();
    tx.setLineDash([]);
    tx.restore();
  }
  tx.save();
  tx.beginPath();
  tx.arc(p.x, p.y, POCKET_R + 12, 0, Math.PI * 2);
  tx.strokeStyle = 'rgba(86,184,255,0.95)';
  tx.lineWidth = 3;
  tx.stroke();
  tx.fillStyle = 'rgba(86,184,255,0.95)';
  tx.font = 'bold 10px Space Mono,monospace';
  tx.textAlign = 'center';
  tx.textBaseline = 'top';
  tx.fillText(preview ? 'CONFIRM WARP OR CLICK ELSEWHERE TO PREVIEW AGAIN' : 'CLICK WHERE THIS POCKET SHOULD MOVE (IN/OUT)', TW / 2, RAIL + 6);
  tx.restore();
}

// ── Table placer (click on table to place object) ─────────────
// Used for: bouncer, ice patch, mud patch, move-hole destination
// (tablePlacerStep/Active declared at top)

function showTablePlacer(step) {
  step.preview = null;
  tablePlacerStep   = step;
  tablePlacerActive = true;
  document.getElementById('cardOverlay').classList.remove('show');
  setStatus('📍 ' + (step.statusMsg||'Click on the table to place') + ' — click, preview, confirm', true);
}

function getTablePlacementPoint(step, x, y) {
  if (step && typeof step.getPlacementPoint === 'function') {
    return step.getPlacementPoint(x, y);
  }
  return { x, y };
}

// Called from table mousedown handler when tablePlacerActive
function handleTablePlacerClick(tx2, ty2) {
  if (!tablePlacerActive || !tablePlacerStep) return false;
  const step = tablePlacerStep;
  const placePoint = getTablePlacementPoint(step, tx2, ty2);
  step.preview = { x: placePoint.x, y: placePoint.y };
  requestSelectionConfirm({
    title: step.confirmTitle || 'CONFIRM PLACEMENT',
    message: step.confirmMessage || 'Use this placement?',
    onConfirm: () => {
      step.onPlace(placePoint.x, placePoint.y);
      tablePlacerActive = false;
      tablePlacerStep   = null;
      processInteractionQueue();
    },
    onCancel: () => {
      if (tablePlacerStep) tablePlacerStep.preview = null;
    }
  });
  return true;
}

function drawTablePlacerPreview() {
  if (!tablePlacerActive || !tablePlacerStep) return;
  const step = tablePlacerStep;
  const p = step.preview || getTablePlacementPoint(step, mouseTableX, mouseTableY);
  if (!p) return;

  const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 250 * Math.PI);
  tx.save();
  tx.beginPath();
  tx.arc(p.x, p.y, 11 + pulse * 3, 0, Math.PI * 2);
  tx.strokeStyle = 'rgba(86,184,255,0.95)';
  tx.lineWidth = 2.6;
  tx.stroke();

  tx.beginPath();
  tx.arc(p.x, p.y, 3.2, 0, Math.PI * 2);
  tx.fillStyle = 'rgba(255,255,255,0.95)';
  tx.fill();

  if (step.previewKind === 'bear_trap') {
    drawBearTrapSymbol(p.x, p.y, 1);
  }

  tx.fillStyle = 'rgba(86,184,255,0.95)';
  tx.font = 'bold 9px Space Mono,monospace';
  tx.textAlign = 'center';
  tx.textBaseline = 'top';
  tx.fillText(step.preview ? 'CONFIRM / RESELECT' : 'CLICK TO PREVIEW', TW / 2, RAIL + 6);
  tx.restore();
}

// ── Portal placer (two clicks: entry then exit) ───────────────
// (portalPlaceState/Entry declared at top)

function showPortalPlacer(step) {
  portalPlaceState = 1;
  portalEntry = null;
  document.getElementById('cardOverlay').classList.remove('show');
  setStatus('🌀 PORTAL: Click to place ENTRY point', true);
}

function handlePortalClick(px2, py2) {
  const spot = clampPortalPointInsideWarp(px2, py2, 16);
  if (portalPlaceState === 1) {
    requestSelectionConfirm({
      title: 'CONFIRM PORTAL ENTRY',
      message: 'Use this ENTRY portal location?',
      onConfirm: () => {
        portalEntry = spot;
        portalPlaceState = 2;
        setStatus('🌀 PORTAL: Click to place EXIT point', true);
      }
    });
    return true;
  }
  if (portalPlaceState === 2) {
    requestSelectionConfirm({
      title: 'CONFIRM PORTAL EXIT',
      message: 'Use this EXIT portal location?',
      onConfirm: () => {
        let exit = separatePortalPoints(portalEntry, spot, 32);
        exit = clampPortalPointInsideWarp(exit.x, exit.y, 16);
        activeEffects.portals = [portalEntry, exit];
        normalizePortalsToWarp();
        portalPlaceState = 0;
        portalEntry = null;
        processInteractionQueue();
      }
    });
    return true;
  }
  return false;
}

// ── Move Hole picker (pick pocket, then table placer for dest) ─
function showMoveHolePicker(step) {
  showPocketPicker({
    title:'MOVE A POCKET',
    sub:'Choose which pocket to relocate',
    onPick: (idx) => {
      // Now ask where to drag it
      showTablePlacer({
        statusMsg: 'Click to place pocket #'+(idx+1)+' in new position',
        confirmTitle:'CONFIRM MOVE HOLE',
        confirmMessage:'Move this pocket to the previewed position?',
        getPlacementPoint:(tx2, ty2) => {
          const inner = getInnerBounds(4);
          return {
            x: Math.max(inner.left, Math.min(inner.right, tx2)),
            y: Math.max(inner.top, Math.min(inner.bottom, ty2)),
          };
        },
        onPlace: (tx2, ty2) => {
          if (!activeEffects.movedPockets) activeEffects.movedPockets = {};
          activeEffects.movedPockets[idx] = {x:tx2, y:ty2};
        }
      });
    }
  });
}

// ── updateEffectsPanel ────────────────────────────────────────
function updateEffectsPanel() {
  const box   = document.getElementById('effectsBox');
  const panel = document.getElementById('activeEffects');
  const chips = [];
  const ae = activeEffects;

  if (ae.fogOfWar)    chips.push({t:'ball',  label:'Fog of War'});
  if (ae.heavyweight) chips.push({t:'ball',  label:'Heavyweight · ball '+ae.heavyweight});
  if (ae.lightweight) chips.push({t:'ball',  label:'Lightweight · ball '+ae.lightweight});
  if (ae.confusion)   chips.push({t:'ball',  label:'Confusion'});
  if (ae.cloaked)     chips.push({t:'ball',  label:'Cloaked · ball '+ae.cloaked});
  if (ae.sticky)      chips.push({t:'ball',  label:'Sticky cue'});
  if (ae.drunk)       chips.push({t:'ball',  label:'Drunk aim'});
  if (ae.shortsighted)chips.push({t:'ball',  label:'Shortsighted'});
  if (ae.roidRage)    chips.push({t:'ball',  label:'Roid Rage ≥75%'});
  if (ae.coolHands)   chips.push({t:'ball',  label:'Cool Hands ≤25%'});
  if (ae.bigBall)     chips.push({t:'ball',  label:'Big Cue Ball'});
  if (ae.smallBall)   chips.push({t:'ball',  label:'Small Cue Ball'});
  if (ae.oilCue)      chips.push({t:'ball',  label:'Oil Cue'});
  if (ae.reverseSpin) chips.push({t:'ball',  label:'Reverse Spin'});
  if (ae.mirror)      chips.push({t:'ball',  label:'Mirror Table'});
  if (ae.magnet)      chips.push({t:'ball',  label:'Pocket Magnet'});
  if (ae.turbo)       chips.push({t:'ball',  label:'Turbo Shot'});
  if (ae.bouncer)     chips.push({t:'table', label:'Bouncer placed'});
  if (ae.bounceHouseRail.length) chips.push({t:'table', label:'Bounce House: '+ae.bounceHouseRail.join(', ')});
  if (ae.deadRail.length)    chips.push({t:'table', label:'Dead Rail: '+ae.deadRail.join(', ')});
  if (ae.bearTrapZone)       chips.push({t:'table', label:'Bear Trap armed'});
  if (ae.bearTrap.length)    chips.push({t:'table', label:'Bear Trap (legacy rail): '+ae.bearTrap.join(', ')});
  if (ae.portals)     chips.push({t:'table', label:'Portals active'});
  if (ae.icePatch)    chips.push({t:'table', label:'Ice Patch'});
  if (ae.blockedPockets&&ae.blockedPockets.length)
    chips.push({t:'table', label:'Blocked pocket(s): '+ae.blockedPockets.map(i=>i+1).join(',')});
  if (hasWarpShape()) chips.push({t:'table', label:'Warp Shape active'});
  if (ae.mudPatch)    chips.push({t:'table', label:'Mud Patch'});
  if (ae.wind!==0)    chips.push({t:'table', label:'Crosswind '+(ae.wind>0?'→':'←')});
  if (ae.pocketShrink!==null) chips.push({t:'table', label:'Shrunk pocket '+(ae.pocketShrink+1)});
  if (ae.movedPockets && Object.keys(ae.movedPockets).length)
    chips.push({t:'table', label:'Pocket(s) moved'});

  box.style.display = chips.length ? '' : 'none';
  panel.innerHTML = chips.map(c=>`<div class="effect-chip effect-${c.t}">${c.label}</div>`).join('');
}

// ── clearBallEffects ──────────────────────────────────────────
function stopDrunkTimer() {
  if (drunkenTimer) {
    clearInterval(drunkenTimer);
    drunkenTimer = null;
  }
  drunkOffset = 0;
}

function stopRoidRageTimer() {
  if (roidRageTimer) {
    clearInterval(roidRageTimer);
    roidRageTimer = null;
  }
}

function startDrunkTimer() {
  stopDrunkTimer();
  let t = 0;
  drunkenTimer = setInterval(() => {
    t += 0.08;
    drunkOffset = Math.sin(t) * (Math.PI / 12);
  }, 30);
}

function startRoidRageTimer() {
  stopRoidRageTimer();
  roidRageTimer = setInterval(() => {
    if (!inMotion && canShoot && activeEffects.roidRage) {
      const lim = getShotPowerBounds();
      power = Math.max(lim.min, Math.min(lim.max, power + (Math.random() - .45) * 18));
      updatePowerUI();
    }
  }, 80);
}

function clearBallEffects() {
  const ae = activeEffects;
  ae.fogOfWar=false; ae.heavyweight=null; ae.lightweight=null;
  ae.confusion=false; ae.confusionMap=null; ae.confusionStripeMap=null; ae.cloaked=null;
  ae.sticky=false; ae.drunk=false; ae.shortsighted=false;
  ae.roidRage=false; ae.coolHands=false; ae.bigBall=false; ae.smallBall=false;
  ae.oilCue=false; ae.reverseSpin=false; ae.mirror=false;
  ae.magnet=false; ae.turbo=false;
  stopDrunkTimer();
  stopRoidRageTimer();
  // Reset cue ball size
  if (cue) cue._r = BR;
  updateEffectsPanel();
}

// ── Timers ────────────────────────────────────────────────────
// (drunkenTimer, roidRageTimer, drunkOffset declared at top)

// ════════════════════════════════════════════════════════════════
// ── BALL CARD APPLIERS ─────────────────────────────────────────
// ════════════════════════════════════════════════════════════════
function applyFogOfWar()    { activeEffects.fogOfWar    = true; }

function clearRailEffects(rail) {
  // Remove this rail from any existing rail effect type (one rail = one effect type at a time)
  ['bounceHouseRail','deadRail'].forEach(k => {
    const arr = activeEffects[k];
    if (Array.isArray(arr)) {
      const i = arr.indexOf(rail);
      if (i !== -1) arr.splice(i, 1);
    }
  });
}
function applyShortsighted(){ activeEffects.shortsighted = true; }
function applySticky()      { activeEffects.sticky      = true; }
function applyBigBall()     { activeEffects.bigBall     = true; }
function applySmallBall()   { activeEffects.smallBall   = true; }
function applyCoolHands()   {
  activeEffects.coolHands = true;
  power = clampShotPower(power);
  updatePowerUI();
}
function applyOilCue()      { activeEffects.oilCue      = true; }
function applyReverseSpin() { activeEffects.reverseSpin = true; }
function applyTurbo()       { activeEffects.turbo       = true; }

function applyMirror()      {
  activeEffects.mirror = true;
  // flip happens visually only via drawBall transform — no physics change needed
}
function applyMagnet()      { activeEffects.magnet      = true; }

function applyDrunk() {
  activeEffects.drunk = true;
  startDrunkTimer();
}

function applyRoidRage() {
  activeEffects.roidRage = true;
  power = clampShotPower(Math.max(power, 75));
  updatePowerUI();
  startRoidRageTimer();
}

// These queue a ball-pick interaction
function applyHeavyweight() { interactionQueue.push({type:'ball_pick', effectKey:'heavyweight'}); }
function applyLightweight()  { interactionQueue.push({type:'ball_pick', effectKey:'lightweight'}); }
function applyConfusion() {
  // queue ball pick — handler will build confusionMap for chosen ball
  interactionQueue.push({type:'ball_pick', effectKey:'confusion'});
}
function applyCloak() {
  interactionQueue.push({type:'ball_pick', effectKey:'cloaked'});
}

// ════════════════════════════════════════════════════════════════
// ── TABLE CARD APPLIERS ────────────────────────────────────────
// ════════════════════════════════════════════════════════════════

// Bouncer — player places it
function applyBouncer() {
  interactionQueue.push({
    type:'table_place',
    statusMsg:'Click to place your BOUNCER anywhere on the table',
    confirmTitle:'CONFIRM BOUNCER',
    confirmMessage:'Place Bouncer at this location?',
    getPlacementPoint:(x,y) => {
      const inner = getInnerBounds(BR * 0.9);
      return {
        x: Math.max(inner.left, Math.min(inner.right, x)),
        y: Math.max(inner.top, Math.min(inner.bottom, y)),
      };
    },
    onPlace:(x,y) => {
      activeEffects.bouncer = {x, y, r:BR * 0.9};
    }
  });
}

// Bounce House — pick rail, that rail has huge bounce
function applyBounceHouse() {
  interactionQueue.push({
    type:'rail_pick', cardName:'BOUNCE HOUSE',
    title:'BOUNCE HOUSE',
    sub:'Pick a rail section — it becomes a rubber band (2.2× bounce)',
    onPick: (rail) => { clearRailEffects(rail); activeEffects.bounceHouseRail.push(rail); }
  });
}

// Dead Rail — pick rail, near-zero bounce
function applyDeadRail() {
  interactionQueue.push({
    type:'rail_pick', cardName:'DEAD RAIL',
    title:'DEAD RAIL',
    sub:'Pick a rail section — balls barely bounce off it (0.1× bounce)',
    onPick: (rail) => { clearRailEffects(rail); activeEffects.deadRail.push(rail); }
  });
}

// Bear Trap — place hidden trap zone, stops balls dead
function applyBearTrap() {
  interactionQueue.push({
    type:'table_place',
    statusMsg:'Place hidden BEAR TRAP anywhere on table',
    previewKind:'bear_trap',
    confirmTitle:'CONFIRM BEAR TRAP',
    confirmMessage:'Arm Bear Trap at this location?',
    getPlacementPoint:(x,y) => {
      const inner = getInnerBounds(0);
      const r = 12;
      return {
        x: Math.max(inner.left + r, Math.min(inner.right - r, x)),
        y: Math.max(inner.top + r, Math.min(inner.bottom - r, y)),
      };
    },
    onPlace:(x,y) => {
      const r = 12;
      activeEffects.bearTrapZone = { x, y, r };
      activeEffects.bearTrapRevealUntil = Date.now() + 1500;
      // Clear legacy rail trap effect when using new mode.
      activeEffects.bearTrap = [];
    }
  });
}

// Portal — two placements (entry + exit)
function applyPortal() {
  interactionQueue.push({ type:'portal_place' });
}

// Ice Patch — player places it
function applyIcePatch() {
  interactionQueue.push({
    type:'table_place',
    statusMsg:'Click to place ICE PATCH (frictionless zone)',
    confirmTitle:'CONFIRM ICE PATCH',
    confirmMessage:'Place Ice Patch here?',
    getPlacementPoint:(x,y) => {
      const inner = getInnerBounds(0);
      return {
        x: Math.max(inner.left + 55, Math.min(inner.right - 55, x)),
        y: Math.max(inner.top + 50, Math.min(inner.bottom - 50, y)),
      };
    },
    onPlace:(x,y) => {
      activeEffects.icePatch = {x, y, r:35};
    }
  });
}

// Block Pocket
function applyBlockPocket() {
  interactionQueue.push({
    type:'pocket_pick',
    title:'BLOCK A POCKET',
    sub:'Choose a pocket to seal — balls bounce off instead of dropping',
    allowPick: (idx) => !activeEffects.blockedPockets.includes(idx),
    onPick: (idx) => {
      if (!activeEffects.blockedPockets.includes(idx))
        activeEffects.blockedPockets.push(idx);
    }
  });
}

// Open Pocket
function applyOpenPocket() {
  if (!activeEffects.blockedPockets.length) return; // nothing to open
  interactionQueue.push({
    type:'pocket_pick',
    title:'OPEN A POCKET',
    sub:'Choose a blocked pocket to re-open',
    allowPick: (idx) => activeEffects.blockedPockets.includes(idx),
    onPick: (idx) => {
      activeEffects.blockedPockets = activeEffects.blockedPockets.filter(i=>i!==idx);
    }
  });
}

// Move Hole
function applyMoveHole() {
  interactionQueue.push({ type:'move_hole' });
}

// Warp Rail
function applyWarpRail() {
  interactionQueue.push({
    type:'pocket_pick',
    title:'WARP RAIL',
    sub:'Pick a pocket, then click where that pocket should move inward/outward',
    onPick: (pocketIdx) => {
      beginWarpPocketResize(pocketIdx);
      return false;
    }
  });
}

// Mud Patch — player places it
function applyMudPatch() {
  interactionQueue.push({
    type:'table_place',
    statusMsg:'Click to place MUD PATCH (slow zone)',
    confirmTitle:'CONFIRM MUD PATCH',
    confirmMessage:'Place Mud Patch here?',
    getPlacementPoint:(x,y) => {
      const inner = getInnerBounds(0);
      return {
        x: Math.max(inner.left + 50, Math.min(inner.right - 50, x)),
        y: Math.max(inner.top + 45, Math.min(inner.bottom - 45, y)),
      };
    },
    onPlace:(x,y) => {
      activeEffects.mudPatch = {x, y, r:28};
    }
  });
}

function applyPocketShrink() {
  interactionQueue.push({
    type:'pocket_pick',
    title:'SHRINK A POCKET',
    sub:'Choose a pocket to shrink to 65% of its normal size',
    allowPick: (idx) => !activeEffects.blockedPockets.includes(idx),
    onPick: (idx) => { activeEffects.pocketShrink = idx; }
  });
}

function applyWind() { activeEffects.wind = (Math.random()>.5?1:-1)*0.012; }

function applyEarthquake() {
  // Nudge all stationary balls by a small random amount
  balls.filter(b=>!b.pocketed).forEach(b=>{
    b.vx += (Math.random()-.5)*2.5;
    b.vy += (Math.random()-.5)*2.5;
  });
}

// ════════════════════════════════════════════════════════════════
// ── getPocketPos helper (respects moved pockets) ──────────────
// ════════════════════════════════════════════════════════════════
function getBasePocketPos(idx) {
  const c = getWarpCorners();
  const m = getWarpMids();
  const base = [
    { x: c.tl.x,     y: c.tl.y },
    { x: m.top.x,    y: m.top.y },
    { x: c.tr.x,     y: c.tr.y },
    { x: c.bl.x,     y: c.bl.y },
    { x: m.bottom.x, y: m.bottom.y },
    { x: c.br.x,     y: c.br.y },
  ];
  return base[idx] || POCKETS[idx];
}

function getPocketPos(idx) {
  if (activeEffects.movedPockets && activeEffects.movedPockets[idx]) {
    return activeEffects.movedPockets[idx];
  }
  return getBasePocketPos(idx);
}

// ════════════════════════════════════════════════════════════════
// ── Physics helpers ────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════
function getWallDamp(wall) {
  if (activeEffects.bounceHouseRail.includes(wall)) return WALL_DAMP * 2.2;
  if (activeEffects.deadRail.includes(wall))        return 0.10;
  if (activeEffects.bearTrap.includes(wall))        return 0.0;
  return WALL_DAMP;
}

function getBearTrapStop(wall) {
  return activeEffects.bearTrap.includes(wall);
}

function getPocketR(idx) {
  if (activeEffects.pocketShrink === idx)               return POCKET_R * 0.65;
  if (activeEffects.blockedPockets.includes(idx))       return 0; // handled separately
  return POCKET_R;
}

function clampBallSpeed(b, maxSpeed = MAX_BALL_SPEED) {
  const v = Math.hypot(b.vx, b.vy);
  if (v > maxSpeed && v > 1e-6) {
    const s = maxSpeed / v;
    b.vx *= s;
    b.vy *= s;
  }
  const w = Math.hypot(b.wx, b.wy);
  if (w > maxSpeed && w > 1e-6) {
    const s = maxSpeed / w;
    b.wx *= s;
    b.wy *= s;
  }
}

function isNearOpenPocketMouth(b, radius) {
  for (let i = 0; i < POCKETS.length; i++) {
    if (activeEffects.blockedPockets.includes(i)) continue;
    const pr = getPocketR(i);
    if (pr <= 0) continue;
    const pk = getPocketPos(i);
    const dx = b.x - pk.x;
    const dy = b.y - pk.y;
    const dist = Math.hypot(dx, dy);
    const mouthBand = pr + radius * 0.38 + 1.2;
    if (dist > mouthBand) continue;
    const toPocketX = pk.x - b.x;
    const toPocketY = pk.y - b.y;
    const approaching = (b.vx * toPocketX + b.vy * toPocketY) >= 0.03;
    if (approaching || dist <= pr + radius * 0.28) return true;
  }
  return false;
}

function resolveWarpWallCollision(b, radius) {
  if (
    !Number.isFinite(b.x) || !Number.isFinite(b.y) ||
    !Number.isFinite(b.vx) || !Number.isFinite(b.vy)
  ) return;
  if (isNearOpenPocketMouth(b, radius)) return;

  const edges = getWarpEdges();
  const centroid = getWarpCentroid();
  const maxPush = radius * 1.2 + 2;
  for (let pass = 0; pass < 3; pass++) {
    let best = null;
    for (let i = 0; i < edges.length; i++) {
      const e = edges[i];
      const ex = e.b.x - e.a.x;
      const ey = e.b.y - e.a.y;
      const lenSq = ex * ex + ey * ey || 1;
      const tRaw = ((b.x - e.a.x) * ex + (b.y - e.a.y) * ey) / lenSq;
      const t = Math.max(0, Math.min(1, tRaw));
      const cx = e.a.x + ex * t;
      const cy = e.a.y + ey * t;
      const dx = b.x - cx;
      const dy = b.y - cy;
      const dist = Math.hypot(dx, dy);
      const penetration = radius - dist;
      if (penetration <= 0) continue;
      if (!best || penetration > best.penetration) {
        best = { edge: e, cx, cy, dx, dy, dist, penetration };
      }
    }
    if (!best) break;

    let nx = 0, ny = 0;
    if (best.dist > 1e-6) {
      nx = best.dx / best.dist;
      ny = best.dy / best.dist;
    } else {
      const ex = best.edge.b.x - best.edge.a.x;
      const ey = best.edge.b.y - best.edge.a.y;
      const len = Math.hypot(ex, ey) || 1;
      nx = -ey / len;
      ny = ex / len;
    }

    // Keep the collision normal pointing inward (toward felt center).
    const toCentroidX = centroid.x - best.cx;
    const toCentroidY = centroid.y - best.cy;
    if (nx * toCentroidX + ny * toCentroidY < 0) {
      nx = -nx;
      ny = -ny;
    }

    const push = Math.min(maxPush, best.penetration + 0.01);
    b.x += nx * push;
    b.y += ny * push;

    if (getBearTrapStop(best.edge.wall)) {
      b.vx = b.vy = b.wx = b.wy = 0;
      return;
    }

    // nx/ny points from rail toward ball center; reflect if moving into rail.
    const vn = b.vx * nx + b.vy * ny;
    if (vn < -1e-4) {
      const damp = getWallDamp(best.edge.wall);
      b.vx -= (1 + damp) * vn * nx;
      b.vy -= (1 + damp) * vn * ny;
      let railType = 'rail';
      if (activeEffects.bounceHouseRail.includes(best.edge.wall)) railType = 'bounce_house';
      else if (activeEffects.deadRail.includes(best.edge.wall)) railType = 'dead_rail';
      else if (activeEffects.bearTrap.includes(best.edge.wall)) railType = 'bear_trap';
      audioCall('railHit', Math.max(0.08, Math.min(1, (-vn) / 12)), railType);
    }
    if (best.edge.wall === 'left' || best.edge.wall === 'right') b.sx *= -0.5;
    else b.sy *= -0.5;
    b.wx = b.vx;
    b.wy = b.vy;
    clampBallSpeed(b);
  }

  if (
    Math.abs(b.x) > TW * 2 || Math.abs(b.y) > TH * 2 ||
    !Number.isFinite(b.x) || !Number.isFinite(b.y) ||
    !Number.isFinite(b.vx) || !Number.isFinite(b.vy)
  ) {
    const inner = getInnerBounds(radius + 1);
    b.x = Math.max(inner.left, Math.min(inner.right, Number.isFinite(b.x) ? b.x : TW / 2));
    b.y = Math.max(inner.top, Math.min(inner.bottom, Number.isFinite(b.y) ? b.y : TH / 2));
    b.vx = b.vy = b.wx = b.wy = b.sx = b.sy = 0;
  }
}

function applyTableEffects(b) {
  // Mud patch — friction zone
  if (activeEffects.mudPatch) {
    const m=activeEffects.mudPatch, dx=b.x-m.x, dy=b.y-m.y;
    if (dx*dx+dy*dy < m.r*m.r) { b.vx*=0.87; b.vy*=0.87; }
  }
  // Ice patch — low friction circle
  if (activeEffects.icePatch) {
    const ic=activeEffects.icePatch, dx=b.x-ic.x, dy=b.y-ic.y;
    if (dx*dx+dy*dy < ic.r*ic.r) { b.vx*=1.012; b.vy*=1.012; }
  }
  // Crosswind
  if (activeEffects.wind!==0) b.vx += activeEffects.wind;
  // Pocket magnet — pull moving balls toward nearest pocket
  if (activeEffects.magnet) {
    const spd = Math.hypot(b.vx,b.vy);
    if (spd > 0.5) {
      let nearestD=9999, npx=0, npy=0;
      POCKETS.forEach((_,i)=>{ const pp=getPocketPos(i); const d=Math.hypot(b.x-pp.x,b.y-pp.y); if(d<nearestD){nearestD=d;npx=pp.x;npy=pp.y;} });
      if (nearestD < 150) {
        if (nearestD > 1e-4) {
          b.vx += (npx - b.x) / nearestD * 0.04;
          b.vy += (npy - b.y) / nearestD * 0.04;
        } else {
          b.vx *= 0.92;
          b.vy *= 0.92;
        }
      }
    }
  }
  // Hidden bear trap zone — any ball touching it stops immediately.
  if (activeEffects.bearTrapZone) {
    const t = activeEffects.bearTrapZone;
    const rr = (b.num === 0 ? (b._r || BR) : BR) + (t.r || 12);
    const dx = b.x - t.x, dy = b.y - t.y;
    if (dx * dx + dy * dy <= rr * rr) {
      const preSpd = Math.hypot(b.vx, b.vy);
      if (preSpd > 0.35) audioCall('railHit', Math.max(0.15, Math.min(1, preSpd / 9)), 'bear_trap');
      b.vx = b.vy = b.wx = b.wy = b.sx = b.sy = 0;
    }
  }
  // Portal teleport
  if (activeEffects.portals) {
    const [entry,exit] = activeEffects.portals;
    if (!b._inPortal) {
      const de = Math.hypot(b.x-entry.x, b.y-entry.y);
      if (de < 16) {
        const radius = (b.num === 0 ? (b._r || BR) : BR) + 1.2;
        const target = shiftPointInsideWarp(exit.x, exit.y, radius);
        b.x = target.x;
        b.y = target.y;
        b._inPortal = true;
        setTimeout(()=>{ b._inPortal=false; }, 400);
      }
    }
  }
}


// ── CARD_POOL — defined here after all applier functions ─────
const BEAR_TRAP_ICON = `
<svg class="bear-trap-svg" viewBox="0 0 64 64" aria-hidden="true">
  <path d="M14 17 L50 17 L46 28 L18 28 Z" fill="#bcc4cf" stroke="#616974" stroke-width="1.5"/>
  <polygon points="20,28 23,33 26,28" fill="#d6dde6"/>
  <polygon points="26,28 29,33 32,28" fill="#d6dde6"/>
  <polygon points="32,28 35,33 38,28" fill="#d6dde6"/>
  <polygon points="38,28 41,33 44,28" fill="#d6dde6"/>

  <path d="M18 36 L46 36 L50 47 L14 47 Z" fill="#9ca6b3" stroke="#5b646f" stroke-width="1.5"/>
  <polygon points="20,36 23,31 26,36" fill="#c4ccd8"/>
  <polygon points="26,36 29,31 32,36" fill="#c4ccd8"/>
  <polygon points="32,36 35,31 38,36" fill="#c4ccd8"/>
  <polygon points="38,36 41,31 44,36" fill="#c4ccd8"/>

  <circle cx="32" cy="32" r="7.5" fill="#2b3138" stroke="#7a848f" stroke-width="1.5"/>
  <circle cx="32" cy="32" r="3.3" fill="#101417"/>

  <rect x="30" y="47" width="4" height="6" rx="1" fill="#7b8591"/>
  <rect x="30" y="53" width="4" height="5" rx="1" fill="#666f7a"/>
  <circle cx="32" cy="60.2" r="2.8" fill="none" stroke="#8f98a4" stroke-width="2"/>
</svg>`;

const WARP_RAIL_ICON = `
<svg class="warp-rail-svg" viewBox="0 0 64 64" aria-hidden="true">
  <path d="M8 14 L56 10 L52 54 L12 48 Z" fill="#5a3418" stroke="#8a5a2a" stroke-width="2"/>
  <path d="M16 20 L30 30 L47 18 L45 43 L32 35 L19 41 Z" fill="#1f8b50" stroke="#54b787" stroke-width="1.6"/>
  <circle cx="16" cy="20" r="2.7" fill="#0b0b0b"/>
  <circle cx="30" cy="30" r="2.4" fill="#0b0b0b"/>
  <circle cx="47" cy="18" r="2.7" fill="#0b0b0b"/>
  <circle cx="19" cy="41" r="2.7" fill="#0b0b0b"/>
  <circle cx="32" cy="35" r="2.4" fill="#0b0b0b"/>
  <circle cx="45" cy="43" r="2.7" fill="#0b0b0b"/>
  <path d="M16 20 Q30 12 47 18" stroke="#9ad5ff" stroke-width="1.7" fill="none" stroke-linecap="round"/>
  <path d="M19 41 Q33 49 45 43" stroke="#9ad5ff" stroke-width="1.7" fill="none" stroke-linecap="round"/>
</svg>`;

const SHRINK_POCKET_ICON = `
<svg class="shrink-pocket-svg" viewBox="0 0 64 64" aria-hidden="true">
  <path d="M10 14 L54 14 L54 50 L10 50 Z" fill="#4f2f16" stroke="#8d6135" stroke-width="2"/>
  <path d="M18 21 Q32 34 46 21" stroke="#2dc17a" stroke-width="5" fill="none" stroke-linecap="round"/>
  <path d="M22 26 Q32 34 42 26" stroke="#1f8a55" stroke-width="4" fill="none" stroke-linecap="round"/>
  <circle cx="32" cy="22.5" r="8.5" fill="#080808"/>
  <path d="M32 34 L32 43" stroke="#f0d593" stroke-width="3" stroke-linecap="round"/>
  <path d="M27 39 L32 45 L37 39" stroke="#f0d593" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="32" cy="49" r="5.2" fill="#080808"/>
</svg>`;

const CARD_POOL = [
  // BALL cards
  { id:'fog_of_war',    type:'ball',  icon:'🌫️', name:'FOG OF WAR',      desc:'Only the aim line to the first object ball is shown.',             fn: applyFogOfWar     },
  { id:'heavyweight',   type:'ball',  icon:'🏋️', name:'HEAVYWEIGHT',      desc:'Pick a ball — it behaves like a much heavier object.',             fn: applyHeavyweight  },
  { id:'lightweight',   type:'ball',  icon:'🪶', name:'LIGHTWEIGHT',      desc:'Pick a ball — it behaves like a much lighter object.',             fn: applyLightweight  },
  { id:'confusion',     type:'ball',  icon:'🔀', name:'CONFUSION',        desc:'Pick a ball — it is disguised and always flips stripe/solid type.', fn: applyConfusion    },
  { id:'cloak',         type:'ball',  icon:'👻', name:'CLOAK',            desc:'Pick a ball — it becomes invisible to your opponent.',             fn: applyCloak        },
  { id:'sticky',        type:'ball',  icon:'🍯', name:'STICKY',           desc:'Cue ball briefly drags the first ball it contacts.',              fn: applySticky       },
  { id:'drunk',         type:'ball',  icon:'🍺', name:'DRUNK',            desc:'Aim line and shot direction wobble ±15° continuously.',           fn: applyDrunk        },
  { id:'shortsighted',  type:'ball',  icon:'🔭', name:'SHORTSIGHTED',     desc:'No aim guide line or ghost ball shown.',                          fn: applyShortsighted },
  { id:'roid_rage',     type:'ball',  icon:'💢', name:'ROID RAGE',        desc:'Power surges and can never be below 75% this turn.',             fn: applyRoidRage     },
  { id:'cool_hands',    type:'ball',  icon:'🧊', name:'COOL HANDS',       desc:'Power is capped at 25% for this turn.',                           fn: applyCoolHands    },
  { id:'big_ball',      type:'ball',  icon:'🔵', name:'BIG BALL',         desc:'Cue ball is 2x normal size — wider hits, more force.',            fn: applyBigBall      },
  { id:'small_ball',    type:'ball',  icon:'⚪', name:'SMALL BALL',       desc:'Cue ball is half normal size — weaker, easier to miss.',          fn: applySmallBall    },
  { id:'oil_cue',       type:'ball',  icon:'💧', name:'OIL CUE',          desc:'Cue ball slides 40% further — backspin barely works.',            fn: applyOilCue       },
  { id:'reverse_spin',  type:'ball',  icon:'↩️', name:'REVERSE SPIN',     desc:'Left/right English is flipped for this turn.',                    fn: applyReverseSpin  },
  { id:'mirror',        type:'ball',  icon:'🪞', name:'MIRROR',           desc:'Opponent sees all object balls mirrored left-right.',             fn: applyMirror       },
  { id:'magnet',        type:'ball',  icon:'🧲', name:'MAGNET',           desc:'All moving balls are pulled slightly toward nearest pocket.',     fn: applyMagnet       },
  { id:'turbo',         type:'ball',  icon:'⚡', name:'TURBO',            desc:'Shot speed is multiplied 1.6x — hard to control.',               fn: applyTurbo        },
  // TABLE cards
  { id:'bouncer',       type:'table', icon:'🔴', name:'BOUNCER',          desc:'Place a rubber bumper anywhere — you choose the spot.',           fn: applyBouncer      },
  { id:'bounce_house',  type:'table', icon:'🎪', name:'BOUNCE HOUSE',     desc:'Pick a rail — it becomes a rubber band (2.2x bounce).',          fn: applyBounceHouse  },
  { id:'dead_rail',     type:'table', icon:'🪵', name:'DEAD RAIL',        desc:'Pick a rail — balls barely rebound (0.1x damping).',             fn: applyDeadRail     },
  { id:'bear_trap',     type:'table', icon:BEAR_TRAP_ICON, name:'BEAR TRAP',        desc:'Place an invisible trap — any ball touching it stops dead.',       fn: applyBearTrap     },
  { id:'portal',        type:'table', icon:'🌀', name:'PORTAL',           desc:'Place entry and exit portals — balls warp between them.',        fn: applyPortal       },
  { id:'ice_patch',     type:'table', icon:'🧊', name:'ICE PATCH',        desc:'Place a frictionless zone anywhere on the table interior.',       fn: applyIcePatch     },
  { id:'block_pocket',  type:'table', icon:'🚫', name:'BLOCK POCKET',     desc:'Seal one pocket — balls bounce off instead of dropping.',        fn: applyBlockPocket  },
  { id:'open_pocket',   type:'table', icon:'✅', name:'OPEN POCKET',      desc:'Re-open a previously blocked pocket.',                           fn: applyOpenPocket   },
  { id:'move_hole',     type:'table', icon:'🕳️', name:'MOVE HOLE',        desc:'Drag any pocket to a new position on the table.',                fn: applyMoveHole     },
  { id:'warp_rail',     type:'table', icon:WARP_RAIL_ICON, name:'WARP RAIL',        desc:'Pick a pocket, then move it inward/outward to warp the table.',   fn: applyWarpRail     },
  { id:'mud_patch',     type:'table', icon:'🟫', name:'MUD PATCH',        desc:'Place a sticky zone — balls slow sharply when passing through.', fn: applyMudPatch     },
  { id:'crosswind',     type:'table', icon:'💨', name:'CROSSWIND',        desc:'A permanent sideways drift nudges all balls.',                   fn: applyWind         },
  { id:'pocket_shrink', type:'table', icon:SHRINK_POCKET_ICON, name:'SHRINK POCKET',    desc:'Pick a pocket — it shrinks to 65% of normal size.',              fn: applyPocketShrink },
  { id:'earthquake',    type:'table', icon:'🌊', name:'EARTHQUAKE',       desc:'All stationary balls are nudged to random new positions.',       fn: applyEarthquake   },
];

function findCardById(id) {
  return CARD_POOL.find(c => c.id === id) || null;
}

function serializeGameSnapshot(reason) {
  return {
    reason: reason || 'update',
    ts: Date.now(),
    gameVariant,
    numP,
    current,
    onBreak,
    rackShotTaken,
    turnPocketed: [...turnPocketed],
    cueScratch,
    shotFirstContactBall,
    shotLowestAtStart,
    doublesNextShooterByTeam: { ...doublesNextShooterByTeam },
    started,
    inMotion,
    canShoot,
    power,
    aimAngle,
    gameOver,
    gameOverTitle,
    gameOverSub,
    ballInHand,
    activeEffects: JSON.parse(JSON.stringify(activeEffects)),
    players: players.map(p => ({
      name: p.name,
      score: p.score,
      type: p.type,
      group: p.group || null,
      team: (typeof p.team === 'number') ? p.team : null,
      handIds: (p.hand || []).map(card => card.id),
    })),
    balls: balls.map(b => ({ ...b })),
    cue: cue ? { ...cue } : null,
  };
}

function syncEffectTimersFromState() {
  if (activeEffects.drunk) startDrunkTimer();
  else stopDrunkTimer();
  if (activeEffects.roidRage) startRoidRageTimer();
  else stopRoidRageTimer();
}

function applyGameSnapshot(snapshot, fromRemote = false) {
  if (!snapshot || !Array.isArray(snapshot.players) || !Array.isArray(snapshot.balls)) return;
  syncingRemoteSnapshot = fromRemote;
  try {
    const snapVariant = (
      snapshot.gameVariant === 'nine' ||
      snapshot.gameVariant === 'cutthroat' ||
      snapshot.gameVariant === 'doubles' ||
      snapshot.gameVariant === 'eight'
    )
      ? snapshot.gameVariant
      : gameVariant;
    setGameVariant(snapVariant, true);

    const restoredPlayers = snapshot.players.map((p, i) => ({
      name: p.name || ('Player ' + (i + 1)),
      score: Number(p.score) || 0,
      type: p.type || null,
      group: p.group || null,
      team: (typeof p.team === 'number') ? p.team : null,
      hand: Array.isArray(p.handIds) ? p.handIds.map(findCardById).filter(Boolean) : [],
    }));
    players = restoredPlayers;
    const nextNum = Math.max(2, Math.min(4, snapshot.numP || restoredPlayers.length || 2));
    setNumPlayers(nextNum, true);
    applyOnlinePlayerNames(players.map(p => p.name));

    current = Number(snapshot.current) || 0;
    onBreak = !!snapshot.onBreak;
    rackShotTaken = (typeof snapshot.rackShotTaken === 'boolean')
      ? snapshot.rackShotTaken
      : (!!snapshot.inMotion || !onBreak);
    turnPocketed = Array.isArray(snapshot.turnPocketed) ? [...snapshot.turnPocketed] : [];
    cueScratch = !!snapshot.cueScratch;
    shotFirstContactBall = Number(snapshot.shotFirstContactBall) || null;
    shotLowestAtStart = Number(snapshot.shotLowestAtStart) || null;
    const nextA = Number(snapshot?.doublesNextShooterByTeam?.[0]);
    const nextB = Number(snapshot?.doublesNextShooterByTeam?.[1]);
    doublesNextShooterByTeam = {
      0: Number.isFinite(nextA) ? nextA : 0,
      1: Number.isFinite(nextB) ? nextB : 1,
    };
    started = !!snapshot.started;
    inMotion = !!snapshot.inMotion;
    canShoot = !!snapshot.canShoot;
    power = Number(snapshot.power) || 0;
    aimAngle = typeof snapshot.aimAngle === 'number' ? snapshot.aimAngle : aimAngle;
    gameOver = !!snapshot.gameOver;
    gameOverTitle = snapshot.gameOverTitle || '';
    gameOverSub = snapshot.gameOverSub || '';
    ballInHand = !!snapshot.ballInHand;

    const effectDefaults = {
      fogOfWar:false, heavyweight:null, lightweight:null,
      confusion:false, confusionMap:null, confusionStripeMap:null, cloaked:null,
      sticky:false, drunk:false, shortsighted:false,
      roidRage:false, coolHands:false, bigBall:false, smallBall:false,
      oilCue:false, reverseSpin:false, mirror:false, magnet:false,
      turbo:false,
      bounceHouseRail:[], deadRail:[], bearTrap:[],
      bearTrapZone:null, bearTrapRevealUntil:0,
      portals:null, icePatch:null, blockedPockets:[],
      bouncer:null, mudPatch:null, wind:0,
      pocketShrink:null, movedPockets:{},
      warpCorners:null, warpMids:null,
    };
    Object.assign(activeEffects, effectDefaults, snapshot.activeEffects || {});
    const warped = normalizeWarpGeometry(getWarpCorners(), getWarpMids());
    activeEffects.warpCorners = warped.corners;
    activeEffects.warpMids = warped.mids;
    syncEffectTimersFromState();

    balls = snapshot.balls.map(b => ({ ...b }));
    cue = snapshot.cue ? { ...snapshot.cue } : cue;
    if (cue && cue._r == null) {
      cue._r = activeEffects.bigBall ? BR * 2 : activeEffects.smallBall ? BR * 0.5 : BR;
    }
    shiftAllBallsInsideWarp();
    normalizePortalsToWarp();

    // Reset interaction overlays when remote state applies.
    cardPhaseActive = false;
    cardPhaseForPlayer = -1;
    cardPhaseMode = 'idle';
    phaseOfferCards = [];
    phaseOfferSelected = new Set();
    phaseHandSelected = new Set();
    phaseAutoDrawnCards = [];
    clearCardDrawAnimation();
    interactionQueue = [];
    tablePlacerActive = false;
    tablePlacerStep = null;
    portalPlaceState = 0;
    portalEntry = null;
    warpPocketResizeStep = null;
    pocketPickerStep = null;
    pocketPickerHover = null;
    ballPickerPreviewNum = null;
    closeSelectionConfirm();
    hideBallPickerHint();
    hidePocketPickerHint();
    hideRailPickerHint();
    document.getElementById('cardOverlay').classList.remove('show');

    if (isOnlineActive()) canShoot = canShoot && isLocalSeatTurn();

    updatePowerUI();
    updateEffectsPanel();
    updateHeader();
    updateDots();

    if (gameOver) {
      document.getElementById('msgTitle').textContent = gameOverTitle || 'GAME OVER';
      document.getElementById('msgSub').textContent = gameOverSub || '';
      document.getElementById('msgBtn').textContent = 'NEW GAME';
      document.getElementById('overlay').classList.add('show');
      setSetupOverlayVisible(false);
    } else {
      document.getElementById('overlay').classList.remove('show');
      setSetupOverlayVisible(!started);
      if (!started) setStatus('Waiting for host to rack up', true);
      else if (ballInHand) setStatus(players[current].name + ' — Place Cue Ball (click to confirm)', true);
      else if (isOnlineActive() && onlineSession.role === 'spectator') setStatus('Spectating: ' + players[current].name + (inMotion ? ' shooting...' : "'s turn"), true);
      else if (isOnlineActive() && !isLocalSeatTurn()) setStatus(inMotion ? ('Watching ' + players[current].name + ' shoot...') : ('Waiting for ' + players[current].name + '...'), true);
      else setStatus(players[current].name + "'s Turn");
    }
  } finally {
    syncingRemoteSnapshot = false;
  }
}

// (activeEffects declared near top of script, after constants)
// Init
setSetupOverlayVisible(true);
drawTable(); redrawSpin();
loop();
