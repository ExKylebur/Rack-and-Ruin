#!/usr/bin/env python3
import argparse
import json
import random
import re
import string
import subprocess
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT_DIR = Path(__file__).resolve().parent.parent
STATE_DIR = Path(__file__).resolve().parent / "state"
ROOMS_FILE = STATE_DIR / "rooms.json"
ROOM_LOCK = threading.Lock()
ROOM_TTL_SECONDS = 30 * 24 * 60 * 60
ROOMS = {}
ALLOW_NAME_RECLAIM = True
TUNNEL_PROCESS = None
TUNNEL_THREAD = None


def now_ts() -> float:
    return time.time()


def make_code(length: int = 6) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(random.choice(alphabet) for _ in range(length))


def make_token(length: int = 24) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(random.choice(alphabet) for _ in range(length))


def clean_rooms() -> bool:
    cutoff = now_ts() - ROOM_TTL_SECONDS
    stale = [code for code, room in ROOMS.items() if room["updated_at"] < cutoff]
    for code in stale:
        ROOMS.pop(code, None)
    return bool(stale)


def save_rooms_unlocked() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "savedAt": now_ts(),
        "rooms": ROOMS,
    }
    tmp = ROOMS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload), encoding="utf-8")
    tmp.replace(ROOMS_FILE)


def load_rooms_unlocked() -> None:
    global ROOMS
    if not ROOMS_FILE.exists():
        ROOMS = {}
        return
    try:
        payload = json.loads(ROOMS_FILE.read_text(encoding="utf-8") or "{}")
    except (json.JSONDecodeError, OSError):
        ROOMS = {}
        return
    raw_rooms = payload.get("rooms")
    if not isinstance(raw_rooms, dict):
        ROOMS = {}
        return
    rooms = {}
    for raw_code, room in raw_rooms.items():
        code = str(raw_code or "").strip().upper()
        if not code or not isinstance(room, dict):
            continue
        players = room.get("players")
        state = room.get("state")
        if not isinstance(players, list) or not isinstance(state, dict):
            continue
        if "version" not in state:
            state["version"] = 0
        if "snapshot" not in state:
            state["snapshot"] = None
        if "updated_by" not in state:
            state["updated_by"] = None
        if "reason" not in state:
            state["reason"] = None
        if "updated_at" not in room:
            room["updated_at"] = now_ts()
        if "spectators" not in room or not isinstance(room["spectators"], list):
            room["spectators"] = []
        room["code"] = code
        rooms[code] = room
    ROOMS = rooms


def players_public(room: dict) -> list:
    return [{"seat": p["seat"], "name": p["name"]} for p in room["players"]]


def find_player(room: dict, token: str):
    for p in room["players"]:
        if p["token"] == token:
            return p
    return None


def find_spectator(room: dict, token: str):
    for s in room.get("spectators", []):
        if s["token"] == token:
            return s
    return None


def find_identity(room: dict, token: str):
    p = find_player(room, token)
    if p:
        return {"role": "player", "entry": p}
    s = find_spectator(room, token)
    if s:
        return {"role": "spectator", "entry": s}
    return None


def _extract_url(text: str) -> str:
    m = re.search(r"https?://[A-Za-z0-9.\-_:]+", text or "")
    return m.group(0) if m else ""


def start_localhost_run_tunnel(port: int) -> bool:
    global TUNNEL_PROCESS
    global TUNNEL_THREAD
    if TUNNEL_PROCESS and TUNNEL_PROCESS.poll() is None:
        return True
    cmd = [
        "ssh",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "ServerAliveInterval=30",
        "-R",
        f"80:localhost:{port}",
        "nokey@localhost.run",
    ]
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except OSError:
        return False
    TUNNEL_PROCESS = proc

    def _pump():
        if not proc.stdout:
            return
        for line in proc.stdout:
            ln = line.rstrip("\n")
            if ln:
                print("[tunnel] " + ln)
            url = _extract_url(ln)
            if url and "localhost" not in url and "127.0.0.1" not in url:
                RackRuinHandler.public_base_url = url
                print("[tunnel] Public invite URL: " + url)

    TUNNEL_THREAD = threading.Thread(target=_pump, daemon=True)
    TUNNEL_THREAD.start()
    return True


def tunnel_running() -> bool:
    return bool(TUNNEL_PROCESS and TUNNEL_PROCESS.poll() is None)


class RackRuinHandler(SimpleHTTPRequestHandler):
    server_version = "RackRuinOnline/1.0"
    public_base_url = ""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT_DIR), **kwargs)

    def _normalized_public_base(self) -> str:
        raw = (self.public_base_url or "").strip()
        if not raw:
            return ""
        if "://" not in raw:
            raw = "https://" + raw
        return raw.rstrip("/")

    @staticmethod
    def _host_without_port(host: str) -> str:
        h = (host or "").strip()
        if h.startswith("["):
            end = h.find("]")
            if end > 0:
                return h[1:end].lower()
        return h.split(":", 1)[0].lower()

    @classmethod
    def _is_loopback_host(cls, host: str) -> bool:
        h = cls._host_without_port(host)
        return h in {"localhost", "127.0.0.1", "::1"} or h.startswith("127.")

    def _request_base_url(self) -> str:
        host = (self.headers.get("X-Forwarded-Host") or self.headers.get("Host") or "").strip()
        if not host or self._is_loopback_host(host):
            return ""
        proto = (self.headers.get("X-Forwarded-Proto") or "http").split(",", 1)[0].strip().lower()
        if proto not in {"http", "https"}:
            proto = "https"
        return (proto + "://" + host).rstrip("/")

    def _effective_public_base(self) -> str:
        configured = self._normalized_public_base()
        if configured:
            return configured
        return self._request_base_url()

    @classmethod
    def _is_loopback_base(cls, base: str) -> bool:
        try:
            parsed = urlparse(base or "")
            host = parsed.hostname or ""
        except Exception:
            host = ""
        return cls._is_loopback_host(host)

    def _with_server_meta(self, payload: dict) -> dict:
        meta = dict(payload)
        meta["publicBaseUrl"] = self._effective_public_base()
        return meta

    def _send_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError:
            return {}

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/server-info":
            self._send_json(self._with_server_meta({"ok": True}))
            return
        if parsed.path == "/api/state":
            self._handle_state_get(parsed)
            return
        if parsed.path == "/":
            self.path = "/PLAY%20ME.html"
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/create-room":
            self._handle_create_room()
            return
        if parsed.path == "/api/start-tunnel":
            self._handle_start_tunnel()
            return
        if parsed.path == "/api/join-room":
            self._handle_join_room()
            return
        if parsed.path == "/api/reconnect":
            self._handle_reconnect()
            return
        if parsed.path == "/api/update-state":
            self._handle_update_state()
            return
        self._send_json({"ok": False, "error": "Unknown endpoint"}, status=404)

    def _handle_start_tunnel(self):
        with ROOM_LOCK:
            existing = self._effective_public_base()
            if existing and not self._is_loopback_base(existing):
                self._send_json(self._with_server_meta({
                    "ok": True,
                    "started": False,
                    "pending": False,
                    "publicBaseUrl": existing,
                }))
                return
        ok = start_localhost_run_tunnel(self.server.server_port)
        if not ok:
            self._send_json({"ok": False, "error": "Could not start SSH tunnel. Ensure ssh is installed and outbound SSH is allowed."}, status=500)
            return
        deadline = now_ts() + 12
        while now_ts() < deadline:
            base = self._effective_public_base()
            if base and not self._is_loopback_base(base):
                self._send_json(self._with_server_meta({
                    "ok": True,
                    "started": True,
                    "pending": False,
                    "publicBaseUrl": base,
                }))
                return
            time.sleep(0.25)
        self._send_json(self._with_server_meta({
            "ok": True,
            "started": tunnel_running(),
            "pending": True,
        }))

    def _handle_create_room(self):
        payload = self._read_json()
        name = (payload.get("name") or "Player 1").strip()[:32] or "Player 1"
        requested_code = (payload.get("code") or "").strip().upper()
        with ROOM_LOCK:
            clean_rooms()
            if requested_code:
                if not re.fullmatch(r"[A-Z0-9]{4,10}", requested_code):
                    self._send_json({"ok": False, "error": "Room code must be 4-10 letters/numbers"}, status=400)
                    return
                if requested_code in ROOMS:
                    self._send_json({"ok": False, "error": "Room code already in use"}, status=409)
                    return
                code = requested_code
            else:
                code = make_code()
                while code in ROOMS:
                    code = make_code()
            token = make_token()
            room = {
                "code": code,
                "players": [{"seat": 0, "name": name, "token": token}],
                "spectators": [],
                "state": {"version": 0, "snapshot": None, "updated_by": None, "reason": None},
                "updated_at": now_ts(),
            }
            ROOMS[code] = room
            save_rooms_unlocked()
            self._send_json(self._with_server_meta({
                "ok": True,
                "code": code,
                "token": token,
                "seat": 0,
                "role": "player",
                "version": 0,
                "players": players_public(room),
                "spectatorCount": len(room["spectators"]),
            }))

    def _handle_join_room(self):
        payload = self._read_json()
        code = (payload.get("code") or "").strip().upper()
        name = (payload.get("name") or "Player").strip()[:32] or "Player"
        if not code:
            self._send_json({"ok": False, "error": "Room code is required"}, status=400)
            return
        with ROOM_LOCK:
            clean_rooms()
            room = ROOMS.get(code)
            if not room:
                self._send_json({"ok": False, "error": "Room not found"}, status=404)
                return
            token = make_token()
            reclaimed = False
            if len(room["players"]) < 2:
                seat = len(room["players"])
                role = "player"
                room["players"].append({"seat": seat, "name": name, "token": token})
                room["state"]["updated_by"] = seat
                room["state"]["reason"] = "player_join"
            else:
                seat_match = None
                if ALLOW_NAME_RECLAIM:
                    lowered = name.strip().lower()
                    for p in room["players"]:
                        if (p.get("name") or "").strip().lower() == lowered:
                            seat_match = p
                            break
                if seat_match:
                    seat = seat_match["seat"]
                    role = "player"
                    seat_match["token"] = token
                    room["state"]["updated_by"] = seat
                    room["state"]["reason"] = "player_reclaim"
                    reclaimed = True
                else:
                    seat = -1
                    role = "spectator"
                    room.setdefault("spectators", []).append({"name": name, "token": token})
                    room["state"]["updated_by"] = None
                    room["state"]["reason"] = "spectator_join"
            room["state"]["version"] += 1
            room["updated_at"] = now_ts()
            save_rooms_unlocked()
            state = room["state"]
            self._send_json(self._with_server_meta({
                "ok": True,
                "code": code,
                "token": token,
                "seat": seat,
                "role": role,
                "reclaimed": reclaimed,
                "version": state["version"],
                "snapshot": state["snapshot"],
                "players": players_public(room),
                "spectatorCount": len(room.get("spectators", [])),
            }))

    def _handle_update_state(self):
        payload = self._read_json()
        code = (payload.get("code") or "").strip().upper()
        token = payload.get("token") or ""
        snapshot = payload.get("snapshot")
        reason = payload.get("reason") or "update"
        if not code or not token:
            self._send_json({"ok": False, "error": "code and token are required"}, status=400)
            return
        with ROOM_LOCK:
            clean_rooms()
            room = ROOMS.get(code)
            if not room:
                self._send_json({"ok": False, "error": "Room not found"}, status=404)
                return
            identity = find_identity(room, token)
            if not identity:
                self._send_json({"ok": False, "error": "Invalid token"}, status=403)
                return
            if identity["role"] != "player":
                self._send_json({"ok": False, "error": "Spectators cannot update game state"}, status=403)
                return
            player = identity["entry"]
            state = room["state"]
            state["version"] += 1
            state["snapshot"] = snapshot
            state["updated_by"] = player["seat"]
            state["reason"] = reason
            room["updated_at"] = now_ts()
            save_rooms_unlocked()
            self._send_json(self._with_server_meta({
                "ok": True,
                "version": state["version"],
                "updatedBy": state["updated_by"],
                "players": players_public(room),
                "spectatorCount": len(room.get("spectators", [])),
            }))

    def _handle_reconnect(self):
        payload = self._read_json()
        code = (payload.get("code") or "").strip().upper()
        token = payload.get("token") or ""
        if not code or not token:
            self._send_json({"ok": False, "error": "code and token are required"}, status=400)
            return
        with ROOM_LOCK:
            clean_rooms()
            room = ROOMS.get(code)
            if not room:
                self._send_json({"ok": False, "error": "Room not found"}, status=404)
                return
            identity = find_identity(room, token)
            if not identity:
                self._send_json({"ok": False, "error": "Invalid token"}, status=403)
                return
            role = identity["role"]
            seat = identity["entry"]["seat"] if role == "player" else -1
            state = room["state"]
            room["updated_at"] = now_ts()
            save_rooms_unlocked()
            self._send_json(self._with_server_meta({
                "ok": True,
                "code": room["code"],
                "token": token,
                "seat": seat,
                "role": role,
                "version": state["version"],
                "snapshot": state["snapshot"],
                "players": players_public(room),
                "spectatorCount": len(room.get("spectators", [])),
            }))

    def _handle_state_get(self, parsed):
        qs = parse_qs(parsed.query)
        code = (qs.get("code", [""])[0] or "").strip().upper()
        token = qs.get("token", [""])[0] or ""
        since_raw = qs.get("since", ["0"])[0]
        timeout_raw = qs.get("timeout", ["20"])[0]
        try:
            since = int(since_raw)
        except ValueError:
            since = 0
        try:
            timeout = max(1, min(25, int(timeout_raw)))
        except ValueError:
            timeout = 20
        if not code or not token:
            self._send_json({"ok": False, "error": "code and token are required"}, status=400)
            return

        deadline = now_ts() + timeout
        while True:
            with ROOM_LOCK:
                dirty = clean_rooms()
                if dirty:
                    save_rooms_unlocked()
                room = ROOMS.get(code)
                if not room:
                    self._send_json({"ok": False, "error": "Room not found"}, status=404)
                    return
                identity = find_identity(room, token)
                if not identity:
                    self._send_json({"ok": False, "error": "Invalid token"}, status=403)
                    return
                role = identity["role"]
                seat = identity["entry"]["seat"] if role == "player" else -1
                state = room["state"]
                version = state["version"]
                if version > since:
                    self._send_json(self._with_server_meta({
                        "ok": True,
                        "version": version,
                        "role": role,
                        "seat": seat,
                        "updatedBy": state["updated_by"],
                        "reason": state["reason"],
                        "snapshot": state["snapshot"],
                        "players": players_public(room),
                        "spectatorCount": len(room.get("spectators", [])),
                    }))
                    return
                players = players_public(room)
                spectator_count = len(room.get("spectators", []))
            if now_ts() >= deadline:
                self._send_json(self._with_server_meta({
                    "ok": True,
                    "version": since,
                    "noChange": True,
                    "players": players,
                    "spectatorCount": spectator_count,
                }))
                return
            time.sleep(0.25)


def main():
    global ROOM_TTL_SECONDS
    global ALLOW_NAME_RECLAIM
    global TUNNEL_PROCESS
    parser = argparse.ArgumentParser(description="Rack & Ruin online multiplayer server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", default=8000, type=int)
    parser.add_argument("--room-ttl-hours", default=24 * 30, type=float, help="How long inactive rooms are kept")
    parser.add_argument("--allow-name-reclaim", action="store_true", default=True, help="Allow players to reclaim a seat by rejoining with same name")
    parser.add_argument("--no-name-reclaim", action="store_false", dest="allow_name_reclaim")
    parser.add_argument("--public-base-url", default="", help="Public HTTPS base URL used for invite links")
    parser.add_argument("--auto-public-tunnel", action="store_true", help="Open localhost.run SSH tunnel and auto-set public invite URL")
    args = parser.parse_args()

    ROOM_TTL_SECONDS = max(3600, int(args.room_ttl_hours * 3600))
    ALLOW_NAME_RECLAIM = bool(args.allow_name_reclaim)
    RackRuinHandler.public_base_url = (args.public_base_url or "").strip()
    with ROOM_LOCK:
        load_rooms_unlocked()
        if clean_rooms():
            save_rooms_unlocked()
    server = ThreadingHTTPServer((args.host, args.port), RackRuinHandler)
    print(f"Serving Rack & Ruin at http://{args.host}:{args.port}")
    print("Open http://localhost:%d/PLAY%%20ME.html" % args.port)
    if RackRuinHandler.public_base_url:
        print("Public invite base URL: %s" % RackRuinHandler.public_base_url)
    elif args.auto_public_tunnel:
        ok = start_localhost_run_tunnel(args.port)
        if ok:
            print("Auto tunnel started via localhost.run (waiting for public URL...)")
        else:
            print("Auto tunnel failed to start (ssh unavailable).")
    print("Loaded rooms: %d" % len(ROOMS))
    print("Room TTL: %.1f hours" % (ROOM_TTL_SECONDS / 3600.0))
    print("Seat reclaim by name: %s" % ("ON" if ALLOW_NAME_RECLAIM else "OFF"))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if TUNNEL_PROCESS and TUNNEL_PROCESS.poll() is None:
            TUNNEL_PROCESS.terminate()
        server.server_close()


if __name__ == "__main__":
    main()
